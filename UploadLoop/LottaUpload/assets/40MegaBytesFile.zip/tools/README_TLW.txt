A simple website tool containing commonly used links.

Also any locally required URL's for QA, DEV, or resources. 

Updated by SBS 20180308 @ 14:00