TLD ~ Test Automation 

20180718 ~ 13:30
Save large zip file in tools path for bug 1405. 


20180606 ~ 15:00
* Starting Sprint 42
1 ~ Clean up some of the miss named elements in the test automation. 
2 ~ Take over the API testing automation from Frank.  
3 ~ Cleaned up the Login tests,  combined duplicate student and admin code, and renamed tests

20180522 ~ 15:15
* Starting Sprint 40 
1 ~ updated Utility code to use the StopWatch feature instead of threading.thread.sleep(x).  This is much more stable and I'll be replacing it every where in th code. 

20180416 ~ 1345
* Exam, Quiz, Upload, and Retake work just fine if one or two of these Course/Section groups are assigned and not started. 
* Updated logging off code for the course tests. 

20180315 ~ 0900
* Reversed order of previous notes to be chronologically descending.
* Created new branch feature/lessons1 == Adding Lessons to student experience tests.

20180314 ~ 1030

* Ready for PR:
* As before admins are logged in and out.
* Student account log in then the Image, Bio, and GitHUB details are removed.
* Student profile data is updated.
* Updated data is then validated via Epoch Ticks as being unique.

20180308 ~ 1515

* Verified as of this time the Utility and Admin Login parts are the same
* Updated or created a 'Tools' path for the tools.
* Working Student experience testing.

20180305
* Updated Read me file in the Utility tree.
* Branched to be Feature/Student to add student tests.
