#Requires -Version 5.0
####################################################
####################################################
# Coder Camps LMS powershell command line build script
# This will build the .NET Core solution 
#
# This script and its companions sit within the /CC.LMS.Build folder of the source controlled solution
# Relative paths are determined by the workspace which should either be supplied directly or pulled from environmental variables
#
# Jenkins: http://ccjenkins.northcentralus.cloudapp.azure.com:8080/
#
#####################################################
#####################################################
param (
    # build workspace configuration
    [string]$workspaceFolder = $ENV:WORKSPACE,
    [string]$buildNumber = $ENV:BUILD_NUMBER,
    
    # dotnet build configuration        
    [string]$msBuild = "",    
    [string]$solutionPath = "",
    [switch]$enforceStrictStyleCopRules = $true    
)


####################################################
#  DO NOT EDIT BELOW THIS LINE
#  DO NOT EDIT BELOW THIS LINE
#  DO NOT EDIT BELOW THIS LINE
####################################################
# if not supplied set the workspace to just above this folder assuming this folder 
# is the build folder (where the scripts should be by convention)
####################################################
####################################################
$LastExitCode = -1
if($workspaceFolder -eq "" -and $PSScriptRoot.ToLower().EndsWith("cc.lms.build")){
    $workspaceFolder = Split-Path -Path $PSScriptRoot -Parent    
    $workspaceFolder = Split-Path -Path $workspaceFolder -Parent  
}

if(!(test-path -path $workspaceFolder)){    
    write-host "Invalid Workspace folder. $workspaceFolder does not exist." -forgroundcolor "red"
    exit $LastExitCode
}
####################################################
#folder configuration 
####################################################


#build folders
if($buildNumber -eq ""){
    $buildNumber = (Get-Date).ToUniversalTime().ToString("yyyyMMddHHmmss")
}

#build logs
$buildLogsFolder = join-path -Path $workspaceFolder -ChildPath 'build-logs'
if(!(test-path -path $buildLogsFolder)){    
    $r = new-item $buildLogsFolder -itemtype directory 
}
$buildLogsFolder = join-path -Path $buildLogsFolder -Childpath $buildNumber
if(!(test-path -path $buildLogsFolder)){    
    $r = new-item $buildLogsFolder -itemtype directory 
}


#Now and original location
$date = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")
$oldLocation = get-location
set-location $workspaceFolder


####################################################
# MSBuild location
####################################################
if($msBuild -eq ""){
    $msBuildAltLocations = @()
    $msBuildAltLocations += "C:\Program Files (x86)\Microsoft Visual Studio\2017\Professional\MSBuild\15.0\Bin\msbuild.exe"
    $msBuildAltLocations += "C:\Program Files (x86)\Microsoft Visual Studio\2017\Community\MSBuild\15.0\Bin\msbuild.exe"
    $msBuildAltLocations += "C:\Program Files (x86)\Microsoft Visual Studio\2017\Enterprise\MSBuild\15.0\Bin\msbuild.exe"
    $msBuildAltLocations += "C:\Program Files (x86)\Microsoft Visual Studio\2017\BuildTools\MSBuild\15.0\Bin\msbuild.exe"

    foreach($path in $msBuildAltLocations){
        if(Test-Path $path){
            $msBuild = $path
            break
        }
    }
}

####################################################
#.NET: Perform the build
####################################################
 
$primaryLmsRuleSet = join-path $workspaceFolder -ChildPath "LMS.ruleset"
$primaryLmsRuleSetBackup = Join-Path $PSScriptRoot -ChildPath "LMS.ruleset.backup"
$strictLmsRuleSet = Join-Path $PSScriptRoot -ChildPath "LMS.strict.ruleset"

#set strict style cop rule set if required
if($enforceStrictStyleCopRules){
    # replace default LMS file with strict settings file
    # copy default file to temp path       
    copy-item $primaryLmsRuleSet $primaryLmsRuleSetBackup
    remove-item $primaryLmsRuleSet
    copy-item $strictLmsRuleSet $primaryLmsRuleSet
}

$logFile = join-path $buildLogsFolder -ChildPath "dotnet-build.txt" 


Add-Content $logFile "#########################################################" -PassThru
Add-Content $logFile "#MsBuild             /target:rebuild                     " -PassThru
Add-Content $logFile "#Date:               $date"                                -PassThru
Add-Content $logFile "#Workspace:          $workspaceFolder"                     -PassThru
Add-Content $logFile "#Sln path:           $solutionPath"                        -PassThru
Add-Content $logFile "#########################################################" -PassThru


$output = 0
try{
    if($msBuild -eq ""){
        throw "No valid MSBuild.exe path found"
    }

    & $msBuild "$solutionPath" /target:rebuild /p:Configuration=debug | Add-Content $logFile -PassThru

    $grepResults = get-content $logFile | Select-String -pattern "Compilation Failed" -quiet
    if($grepResults){ 
        Add-Content $logFile "######Match on 'compilation failed'########"  -PassThru
        $output = -1
    }

    $grepResults = get-content $logFile | Select-String -pattern "[123456789].*[0]? Error\(s\)" -quiet
    if($grepResults){ 
        Add-Content $logFile "######Match on 'error pattern'######" -PassThru
        $output = -1
    }
}
catch [Exception]
{
    Add-Content $logFile $_.Exception.Message -PassThru
    $output = -1
}
Add-Content $logFile ""
Add-Content $logFile "" 


if($enforceStrictStyleCopRules){
    # undo strict style settings file
    remove-item $primaryLmsRuleSet
    copy-item $primaryLmsRuleSetBackup $primaryLmsRuleSet
    remove-item $primaryLmsRuleSetBackup
}

set-location $oldLocation
if($output -eq -1){
    Add-Content $logFile "FAILED: .NET Solution Build" -PassThru
    $LastExitCode = -1
    exit $LastExitCode    
}    

####################################################
#Operation Complete
####################################################
Add-Content $logFile "COMPLETE: .NET Solution Build" -PassThru
$LastExitCode = 0
exit $LastExitCode