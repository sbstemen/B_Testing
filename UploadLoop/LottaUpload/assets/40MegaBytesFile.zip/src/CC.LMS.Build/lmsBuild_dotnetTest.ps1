#Requires -Version 5.0
####################################################
####################################################
# Coder Camps LMS powershell command line build script
# This will execute the .NET Core solution unit testsw
#
# This script and its companions sit within the /CC.LMS.Build folder of the source controlled solution
# Relative paths are determined by the workspace which should either be supplied directly or pulled from environmental variables
#
# Jenkins: http://ccjenkins.northcentralus.cloudapp.azure.com:8080/
#
#####################################################
#####################################################
param (
    # build workspace configuration
    [string]$workspaceFolder = $ENV:WORKSPACE,
    [string]$buildNumber = $ENV:BUILD_NUMBER,
    
    # dotnet build configuration    
    [string]$dotnetConfiguration = "release",
    [string]$dotnetFramework = "netcoreapp2.0",
    [string]$dotnetTestProjectRegex = "**/*Tests.csproj"    
)


####################################################
#  DO NOT EDIT BELOW THIS LINE
#  DO NOT EDIT BELOW THIS LINE
#  DO NOT EDIT BELOW THIS LINE
####################################################
# if not supplied set the workspace to just above this folder assuming this folder 
# is the build folder (where the scripts should be by convention)
####################################################
####################################################

$LastExitCode = -1
if ($workspaceFolder -eq "" -and $PSScriptRoot.ToLower().EndsWith("cc.lms.build")) {
    $workspaceFolder = Split-Path -Path $PSScriptRoot -Parent    
    $workspaceFolder = Split-Path -Path $workspaceFolder -Parent    
}


if (!(test-path -path $workspaceFolder)) {    
    write-host "Invalid Workspace folder. $workspaceFolder does not exist." -forgroundcolor "red"
    exit $LastExitCode
}
####################################################
#folder configuration 
####################################################

#build folders
if ($buildNumber -eq "") {
    $buildNumber = (Get-Date).ToUniversalTime().ToString("yyyyMMddHHmmss")
}

#build logs
$buildLogsFolder = join-path -Path $workspaceFolder -ChildPath 'build-logs'
if (!(test-path -path $buildLogsFolder)) {    
    $r = new-item $buildLogsFolder -itemtype directory 
}
$buildLogsFolder = join-path -Path $buildLogsFolder -Childpath $buildNumber
if (!(test-path -path $buildLogsFolder)) {    
    $r = new-item $buildLogsFolder -itemtype directory 
}

$date = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")
$oldLocation = get-location
set-location $workspaceFolder

####################################################
#.NET: Perform Unit Tests
####################################################

$logFile = join-path $buildLogsFolder -ChildPath "dotnet-unittest.txt"     
Add-Content $logFile "#######################################################" -PassThru
Add-Content $logFile "#Date:               $date"                   -PassThru      
Add-Content $logFile "#Workspace:          $workspaceFolder"        -PassThru
Add-Content $logFile "#.NET Configuration: $dotnetConfiguration"    -PassThru
Add-Content $logFile "#.NET Framework:     $dotnetFramework"        -PassThru
Add-Content $logFile "#Project Selector:   $dotnetTestProjectRegex" -PassThru
Add-Content $logFile "#######################################################" -PassThru

$output = 0
$testProjs = ls $dotnetTestProjectRegex  -Recurse   
foreach ($testProj in $testProjs) {       
    try {
        dotnet test $testProj --configuration $dotnetConfiguration --framework $dotnetFramework | Add-Content $logFile -PassThru
    
        $grepResults = get-content $logFile | Select-String -pattern "Total tests:.*Failed: [123456789].*" -quiet
        if ($grepResults) { 
            $output = -1
        }
    }
    catch {
        $output = -1
    }
    Add-Content $logFile ""  -PassThru
    Add-Content $logFile ""  -PassThru
}   

set-location $oldLocation
if ($output -eq -1) {
    Add-Content $logFile "FAILED: .NET Solution Unit Tests" -PassThru
    exit $LastExitCode    
}   

####################################################
#Operation Complete
####################################################
Add-Content $logFile "COMPLETE: .NET Solution Unit Tests" -PassThru
set-location $oldLocation
$LastExitCode = 0
exit $LastExitCode