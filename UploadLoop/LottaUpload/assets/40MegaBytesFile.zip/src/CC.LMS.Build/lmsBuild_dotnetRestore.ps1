#Requires -Version 5.0
####################################################
####################################################
# Coder Camps LMS powershell command line build script
# This will perform a nuget package restore of the dotnet core solutionE
#
# This script and its companions sit within the /CC.LMS.Build folder of the source controlled solution
# Relative paths are determined by the workspace which should either be supplied directly or pulled from environmental variables
#
# Jenkins: http://ccjenkins.northcentralus.cloudapp.azure.com:8080/
#
#####################################################
#####################################################
param (
    # build workspace configuration
    [string]$workspaceFolder = $ENV:WORKSPACE,
    [string]$buildNumber = $ENV:BUILD_NUMBER,
    
    # dotnet build configuration    
    # dotnet build configuration    
    [string]$msBuildPath = "",
	[string]$solutionPath="",
    [string]$nugetExe = ""
)


####################################################
#  DO NOT EDIT BELOW THIS LINE
#  DO NOT EDIT BELOW THIS LINE
#  DO NOT EDIT BELOW THIS LINE
####################################################
# if not supplied set the workspace to just above this folder assuming this folder 
# is the build folder (where the scripts should be by convention)
####################################################
####################################################
$LastExitCode = -1
if($workspaceFolder -eq "" -and $PSScriptRoot.ToLower().EndsWith("cc.lms.build")){
    $workspaceFolder = Split-Path -Path $PSScriptRoot -Parent    
    $workspaceFolder = Split-Path -Path $workspaceFolder -Parent  
}

if(!(test-path -path $workspaceFolder)){    
    write-host "Invalid Workspace folder. $workspaceFolder does not exist." -forgroundcolor "red"
    exit $LastExitCode
}

####################################################
#folder configuration 
####################################################


#build folders
if($buildNumber -eq ""){
    $buildNumber = (Get-Date).ToUniversalTime().ToString("yyyyMMddHHmmss")
}

#build log
$buildLogsFolder = join-path -Path $workspaceFolder -ChildPath 'build-logs'
if(!(test-path -path $buildLogsFolder)){    
    $r = new-item $buildLogsFolder -itemtype directory 
}
$buildLogsFolder = join-path -Path $buildLogsFolder -Childpath $buildNumber
if(!(test-path -path $buildLogsFolder)){    
    $r = new-item $buildLogsFolder -itemtype directory 
}

#Now and original location
$date = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")
$oldLocation = get-location
set-location $workspaceFolder

####################################################
# MSBuild location
####################################################
if($msBuildPath -eq ""){
    $msBuildAltLocations = @()
    $msBuildAltLocations += "C:\Program Files (x86)\Microsoft Visual Studio\2017\Professional\MSBuild\15.0\Bin"
	$msBuildAltLocations += "C:\Program Files (x86)\Microsoft Visual Studio\2017\Community\MSBuild\15.0\Bin"
    $msBuildAltLocations += "C:\Program Files (x86)\Microsoft Visual Studio\2017\Enterprise\MSBuild\15.0\Bin"
    $msBuildAltLocations += "C:\Program Files (x86)\Microsoft Visual Studio\2017\BuildTools\MSBuild\15.0\Bin"

    foreach($path in $msBuildAltLocations){
        if(Test-Path $path){
            write-host $path
            $msBuildPath = $path
            break
        }
    }
}


####################################################
#Log and Nuget exe locations
####################################################
$logFile = join-path $buildLogsFolder -ChildPath "dotnet-restore.txt"
if($nugetExe -eq ""){
    $nugetExe = Join-Path $PSScriptRoot -ChildPath "nuget.exe"
}



Add-Content $logFile "###############################"  -PassThru
Add-Content $logFile "#Date:          $date"            -PassThru
Add-Content $logFile "#Workspace:     $workspaceFolder" -PassThru
Add-Content $logFile "#nuget          restore    "      -PassThru
Add-Content $logFile "###############################"  -PassThru

set-location "$workspaceFolder"


$output = 0
try{
    if($msBuildPath -eq ""){
        throw "No valid MSBuild.exe path found"
    }

    #do the restore
    & $nugetExe restore "$solutionPath" -MSBuildPath "$msBuildPath" | Add-Content $logFile -PassThru
    
    $grepResults = get-content $logFile | Select-String -pattern  '.*fail.*' -quiet
    if($grepResults){ 
        $output = -1
    }
    $grepResults = get-content $logFile | Select-String -pattern  '.*FAIL.*' -quiet
    if($grepResults){ 
        $output = -1
    }
}
catch [Exception]{
    write-host $_.Exception.Message
    $output = -1
}
    
set-location $oldLocation
if($output -eq -1){
    Add-Content $logFile "FAILED: Nuget Package Restore" -PassThru
    exit $LastExitCode    
}    
Add-Content $logFile "COMPLETE: Nuget Package Restore" -PassThru



####################################################
#Operation Complete
####################################################

$LastExitCode = $output
exit $LastExitCode