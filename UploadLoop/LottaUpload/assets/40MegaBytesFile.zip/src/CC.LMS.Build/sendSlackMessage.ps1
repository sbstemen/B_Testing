﻿#Requires -Version 5.0
####################################################
####################################################
# Coder Camps LMS powershell command line build script
# This will send a message to a slack channel
#
# This script and its companions sit within the /CC.LMS.Build folder of the source controlled solution
# Relative paths are determined by the workspace which should either be supplied directly or pulled from environmental variables
#
# Jenkins: http://ccjenkins.northcentralus.cloudapp.azure.com:8080/
#
#####################################################
#####################################################
param (
    # build workspace configuration
    [string]$token = "",
    [string]$channel = "",
    [string]$message = ""
)

Import-Module PSSlack 

write-host $message
Send-SlackMessage -Token "$token" `
    -Channel "$channel" `
    -Text $message `
    -AsUser -Username '@jenkins'