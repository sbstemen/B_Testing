﻿// <copyright file="NewSectionProcess.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace CC.LMS.NewSection
{
  using System;
  using System.Data.SqlClient;
  using System.Drawing;
  using System.IO;
  using OpenQA.Selenium;
  using OpenQA.Selenium.Interactions;
  using OpenQA.Selenium.Support.UI;
  using Utility;
  using SeleniumExtras.WaitHelpers;
  using SeleniumExtras;
  using SeleniumExtras.PageObjects;

  /// <summary>
  /// Class to hold methods used to create a new LMS section
  /// </summary>
  internal class NewSectionProcess
  {
    /// <summary>
    /// Opens the Chrome Web browser for future actions
    /// </summary>
    /// <param name="webDriver">WebDriver object</param>
    /// <param name="utility">Helper Utility object</param>
    /// <param name="adminAccount">Account object for Administrator account</param>
    /// <param name="resultWas">A Pass or Fail counter object</param>
    /// <returns>IWebDriver object</returns>
    public IWebDriver BrowserReady(IWebDriver webDriver, Utilities utility, UserData adminAccount, PassFailCount resultWas)
    {
      bool testPassed = false;
      string findThis = "Sign in with Microsoft";
      string pageText = string.Empty;
      Size viewPortSize = new Size(1650, 1000);
      string startPage = @"https://www.google.com/";
      utility.RandomPause(1);
      webDriver.Navigate().GoToUrl(startPage);
      utility.RandomPause(1);
      webDriver.Manage().Window.Size = viewPortSize;
      utility.RandomPause(1);
      webDriver.Navigate().GoToUrl(adminAccount.ClientUrl);
      utility.RandomPause(3);
      pageText = webDriver.PageSource;
      testPassed = utility.PageIsReady(webDriver, pageText, findThis);
      if (testPassed)
      {
        resultWas.PassCount++;
      }
      else
      {
        resultWas.FailCount++;
      }

      return webDriver;
    }

    /// <summary>
    /// Performs the login action when account is used.
    /// </summary>
    /// <param name="webDriver">WebDriver object</param>
    /// <param name="utility">Helper Utility object</param>
    /// <param name="logPath">Path to be use for logging errors</param>
    /// <param name="adminAccount">Account to be used for authentication</param>
    /// <param name="resultWas">A Pass or Fail counter object</param>
    /// <returns>IWebDriver Object</returns>
    public IWebDriver LogInn(IWebDriver webDriver, Utilities utility, string logPath, UserData adminAccount, PassFailCount resultWas)
    {
      bool testPassed = false;
      string findThis = "tel:+1-855-755-2267";
      string pageText = string.Empty;
      utility.RandomPause(1);
      webDriver.FindElement(By.Id("Username")).SendKeys(adminAccount.LogInAlias);
      utility.RandomPause(1);
      webDriver.FindElement(By.Id("Password")).SendKeys(adminAccount.Password);
      utility.RandomPause(1);
      webDriver.FindElement(By.ClassName("cc-btn-sign-in")).Click();
      utility.RandomPause(5);
      pageText = webDriver.PageSource;
      testPassed = utility.PageIsReady(webDriver, pageText, findThis);
      if (testPassed)
      {
        resultWas.PassCount++;
      }
      else
      {
        resultWas.FailCount++;
      }

      return webDriver;
    }

    /// <summary>
    /// Enters the data to create the section
    /// </summary>
    /// <param name="webDriver">WebDriver object</param>
    /// <param name="utility">Helper Utility object</param>
    /// <param name="sectionData">Section Data object</param>
    /// <param name="result">A Pass or Fail counter object</param>
    /// <returns>IWebDriver object</returns>
    public IWebDriver CreateNewSections(IWebDriver webDriver, Utilities utility, SectionData sectionData, PassFailCount result)
    {
      string startingDate = DateTime.Now.AddDays(-2).ToString("MM/dd/yyyy");

      string endingDateIs = DateTime.Now.AddDays(18).ToString("MM/dd/yyyy");

      utility.RandomPause(1);

      var sectionSearchBox = webDriver.FindElement(By.CssSelector("div.pull-right input.form-control.cc-panel-header-lg"));

      sectionSearchBox.SendKeys("x");

      IWebElement openSectionCreationButton = webDriver.FindElement(By.LinkText("Click here to create a new section"));

      openSectionCreationButton.Click();

      utility.RandomPause(3);

      IWebElement courseCodeInput = webDriver.FindElement(By.CssSelector("div.Select-placeholder"));

      Actions builder = new Actions(webDriver);

      builder.MoveToElement(courseCodeInput).Click().SendKeys(sectionData.CourseCode).SendKeys(Keys.Tab).Perform();

      utility.RandomPause(1);

      webDriver.FindElement(By.Id("startDate")).SendKeys(startingDate);

      utility.RandomPause(1);

      webDriver.FindElement(By.Id("endDate")).SendKeys(endingDateIs);

      utility.RandomPause(2);

       // Make an On Demand Section
      if (sectionData.EnrollmentType == 1)
      {
        var ddlDownArrow = webDriver.FindElements(By.ClassName("Select-arrow-zone"));

        ddlDownArrow[2].Click();

        var findOnDemand = webDriver.FindElements(By.ClassName("Select-multi-value-wrapper"));

        // findOnDemand[2].SendKeys(Keys.ArrowDown);  350 over 60 down
        // findOnDemand[2].Click();
        builder.MoveToElement(findOnDemand[2]).MoveByOffset(0, -10).Click();

        // builder.MoveToElement(findOnDemand[2]).SendKeys(Keys.ArrowDown).SendKeys(Keys.Enter).Perform();
      }

      var toSaveSection = webDriver.FindElements(By.CssSelector("div.cc-admin-section-detail-wrapper button"));

      toSaveSection[0].Click();

      utility.RandomPause(1);

      return webDriver;
    }

    /// <summary>
    /// After creating the section we extract the id Number displayed
    /// </summary>
    /// <param name="webDriver">WebDriver object</param>
    /// <param name="utility">Helper Utility object</param>
    /// <param name="sectionData">Section Data object</param>
    /// <param name="result">A Pass or Fail counter object</param>
    /// <returns>IWebDriver object.</returns>
    public IWebDriver GetSectionNumber(IWebDriver webDriver, Utilities utility, SectionData sectionData, PassFailCount result)
    {
      utility.RandomPause(1);

      int truncateStartValue = sectionData.CourseCode.Length + 3;

      int truncationEndValue = 5;

      var wait = new WebDriverWait(webDriver, new TimeSpan(0, 0, 30));

      var element = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id("name")));

      var textBoxElement = webDriver.FindElement(By.Id("name"));

      sectionData.SectionNameInFull = textBoxElement.GetAttribute("value");

      utility.MakeLogEntry("FULL New Section name == " + sectionData.SectionNameInFull);

      sectionData.SectionNumString = utility.TruncationTool(sectionData.SectionNameInFull, truncateStartValue, truncationEndValue);

      utility.MakeLogEntry("Section Number in string form only == " + sectionData.SectionNumString);

      sectionData.SectionNumInt = Convert.ToInt32(sectionData.SectionNumString);

      utility.MakeLogEntry("NOW it's a number the newest section is == " + sectionData.SectionNumString);

      return webDriver;
    }

    /// <summary>
    /// Compares the last created section id in the Db, with the last created id from web page.
    /// </summary>
    /// <param name="sectionData">Section Data object</param>
    /// <returns>Bool did they match</returns>
    public bool SectionInDb(SectionData sectionData)
    {
      bool dataUiMatch = false;
      int sectionNumberFromDb = 0;
      string filePath = "..\\..\\..\\..\\";
      string fileName = "qa.ssql";
      string logInWith = "qa_automation;";
      string sqlPwd = this.ReadSqlFile(filePath, fileName);
      string sqlConnn =
        "SERVER=lms-qa.database.windows.net;" +
        "DATABASE=lms-qa-primary;" +
        "USER ID=" + logInWith +
        "PASSWORD=" + sqlPwd;

      string sqlQuery = "SELECT Top 1 S.Id FROM LMS.Section AS S Order By Id DESC;";

      using (SqlConnection connect = new SqlConnection(sqlConnn))
      {
        SqlCommand command = new SqlCommand(sqlQuery, connect);
        connect.Open();
        using (SqlDataReader readMe = command.ExecuteReader())
        {
          while (readMe.Read())
          {
            sectionNumberFromDb = Convert.ToInt32(readMe.GetValue(0));
          }
        }

        if (sectionNumberFromDb == sectionData.SectionNumInt)
        {
          dataUiMatch = true;
        }

        return dataUiMatch;
      }
    }

    /// <summary>
    /// Reads a local file using StreamReader needed to complete the SQL query
    /// </summary>
    /// <param name="filePath">Path to the file to be read.</param>
    /// <param name="fileName">Name of the file to be read.</param>
    /// <returns>String object</returns>
    public string ReadSqlFile(string filePath, string fileName)
    {
      string outCome = string.Empty;
      string concatination = filePath + fileName;
      string line = string.Empty;
      int counter = 0;

      using (StreamReader sr = new StreamReader(concatination))
      {
        while ((line = sr.ReadLine()) != null)
        {
          outCome = line.ToString();
          counter++;
        }
      }

      return outCome;
    }

    /// <summary>
    /// Used to log out of an account and checks account is no longer authenticated
    /// </summary>
    /// <param name="webDriver">WebDriver object</param>
    /// <param name="utility">Helper Utility object</param>
    /// <returns>IWebDriver object</returns>
    public IWebDriver LogOff(IWebDriver webDriver, Utilities utility)
    {
      utility.RandomPause(3);

      webDriver.FindElement(By.CssSelector(".nav.navbar-nav.navbar-right>li:last-child>a")).Click();

      utility.RandomPause(1);

      webDriver.FindElement(By.Id("qa-dropdown-logout")).Click();

      utility.RandomPause(1);

      return webDriver;
    }
  }
}
