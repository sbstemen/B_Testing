﻿// <copyright file="NewSection.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace CC.LMS.NewSection
{
  using System;
  using System.IO;
  using Microsoft.VisualStudio.TestTools.UnitTesting;
  using OpenQA.Selenium;
  using OpenQA.Selenium.Chrome;
  using Utility;

  /// <summary>
  /// Creates a new LMS section
  /// </summary>
  [TestClass]
  public class NewSection
  {
    // private static string passWord = Properties.Settings.Default.Password;
    private static string testName = Properties.Settings.Default.TestName;
    private static string runDateTime = DateTime.Now.ToString("-MM-dd-HHmm");
    private static string logPath = Properties.Settings.Default.LogPath + testName + runDateTime;
    private static string chromePath = Directory.GetCurrentDirectory() + "\\assets\\";
    private Utilities utility = new Utilities(logPath);
    private PassFailCount results = new PassFailCount();
    private UserData adminUser = new UserData();
    private UserData assignedUser = new UserData();
    private SectionData sectionData = new SectionData();
    private NewSectionProcess makeSection = new NewSectionProcess();

    /// <summary>
    /// Initializes Account objects for test
    /// </summary>
    [TestInitialize]
    public void TestSetUp()
    {
      this.results.PassCount = this.results.PassCount + 1;
      this.adminUser.LogInAlias = Properties.Settings.Default.WOZAdmin;
      this.adminUser.Password = Properties.Settings.Default.Password;
      this.adminUser.ClientUrl = Properties.Settings.Default.WOZUniversity;
      var newLine = Environment.NewLine;
      this.sectionData.CourseCode = Properties.Settings.Default.CourseCode;
      this.sectionData.EnrollmentType = Properties.Settings.Default.EnrollmentTypeValue;

      if (!Directory.Exists(logPath))
      {
        Directory.CreateDirectory(logPath);
        this.utility.MakeLogEntry("LogON start > " + DateTime.UtcNow.Ticks.ToString() + newLine);
      }
      else
      {
        this.utility.MakeLogEntry("LogON start > " + DateTime.UtcNow.Ticks.ToString() + newLine);
      }
    }

    /// <summary>
    /// Test Actions that create the new LMS section
    /// </summary>
    [TestMethod]
    public void CreateNewSection()
    {
      using (IWebDriver webDriver = new ChromeDriver(chromePath))
      {
        bool sectionCreatedAndInDb = false;

        this.makeSection.BrowserReady(webDriver, this.utility, this.adminUser, this.results);

        this.makeSection.LogInn(webDriver, this.utility, logPath, this.adminUser, this.results);

        this.makeSection.CreateNewSections(webDriver, this.utility, this.sectionData, this.results);

        this.makeSection.GetSectionNumber(webDriver, this.utility, this.sectionData, this.results);

        sectionCreatedAndInDb = this.makeSection.SectionInDb(this.sectionData);

        if (this.results.FailCount <= 0 && sectionCreatedAndInDb)
        {
          this.utility.MakeLogEntry("PASS PASS PASS");
        }
        else
        {
          this.utility.MakeLogEntry("FAIL FAIL the count was " + this.results.FailCount);
        }

        this.makeSection.LogOff(webDriver, this.utility);
      }
    }
  }
}
