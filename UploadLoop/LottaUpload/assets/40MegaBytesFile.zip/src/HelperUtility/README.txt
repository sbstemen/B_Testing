Helper or Utility code

2018-03-03:
Updated the UserData.cs file to become an object with fields used by WOZ accounts. 

2018-03-05:
Updated Read me file and branched to add student tests. 
