﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
// -- SBS ~ 20180531
// Copyright (c) 2016-18
// Project: Utility and Tools
// *************************************************************

namespace Utility
{
  using System;

  /// <summary>
  /// SectionData is object for both input to the create and results from db returned
  /// </summary>
  public class SectionData
  {
    /// <summary>
    /// Gets or sets the string value of the full section name, Course Code - Section## - start Data
    /// </summary>
    /// <value>SectionNameInFull</value>
    public string SectionNameInFull { get; set; }

    /// <summary>
    /// Gets or sets the Section numbers as a string value.
    /// </summary>
    /// <value>SectionString</value>
    public string SectionNumString { get; set; }

    /// <summary>
    /// Gets or sets Section Integer Value
    /// </summary>
    /// <value>SectionInt</value>
    public int SectionNumInt { get; set; }

    /// <summary>
    /// Gets or sets the Course Code you entered to get the desired section.
    /// </summary>
    /// <value>CourseCode</value>
    public string CourseCode { get; set; }

    /// <summary>
    /// Gets or sets course name from db
    /// </summary>
    /// <value>CourseName</value>
    public string CourseName { get; set; }

    /// <summary>
    /// Gets or sets Course Version ID value INTEGER
    /// </summary>
    /// <value>CourseVersionId</value>
    public int CourseVersionId { get; set; }

    /// <summary>
    /// Gets or sets Enrollment Type where 0 - Traditional and 1 - On Demand
    /// </summary>
    /// <value>EnrollmentType</value>
    public int EnrollmentType { get; set; }
  }
}
