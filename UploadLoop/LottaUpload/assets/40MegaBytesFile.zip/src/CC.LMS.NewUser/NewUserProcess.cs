﻿// <copyright file="NewUserProcess.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace CC.LMS.NewUser
{
  using System;
  using System.Drawing;
  using System.IO;
  using Microsoft.VisualStudio.TestTools.UnitTesting;
  using OpenQA.Selenium;
  using OpenQA.Selenium.Chrome;
  using Utility;

  /// <summary>
  /// Class to perform the actions while making new users
  /// </summary>
  internal class NewUserProcess
  {
    /// <summary>
    /// Oens the chrome web browser for future actions
    /// </summary>
    /// <param name="webDriver">WebDriver Object</param>
    /// <param name="utility">Helper Utility Object</param>
    /// <param name="schoolURL">String for the School Client URL</param>
    /// <param name="resultWas">A Pass or Fail counter object</param>
    /// <returns>IWebDriver object</returns>
    public IWebDriver BrowserReady(IWebDriver webDriver, Utilities utility, string schoolURL, PassFailCount resultWas)
    {
      bool testPassed = false;
      string findThis = "Sign in with Microsoft";
      string pageText = string.Empty;
      Size viewPortSize = new Size(1650, 1000);
      webDriver.Navigate().GoToUrl("https://www.google.com/");
      webDriver.Manage().Window.Size = viewPortSize;
      utility.RandomPause(.5);
      webDriver.Navigate().GoToUrl(schoolURL);
      utility.RandomPause(3);
      pageText = webDriver.PageSource;
      utility.RandomPause(1);
      testPassed = utility.PageIsReady(webDriver, pageText, findThis);
      if (testPassed)
      {
        resultWas.PassCount++;
      }
      else
      {
        resultWas.FailCount++;
      }

      return webDriver;
    }

    /// <summary>
    /// Performs the login action for account provided
    /// </summary>
    /// <param name="webDriver">WebDriver Object</param>
    /// <param name="utility">Helper Utility Object</param>
    /// <param name="logPath">Path to be used for logging errors</param>
    /// <param name="userInfo">Object holding user detais</param>
    /// <param name="resultWas">A Pass or Fail counter object</param>
    /// <returns>IWebDriver object</returns>
    public IWebDriver Login(IWebDriver webDriver, Utilities utility, string logPath, UserData userInfo, PassFailCount resultWas)
    {
      bool testPassed = false;
      string pageText = string.Empty;

      webDriver.FindElement(By.Id("Username")).SendKeys(userInfo.LogInAlias);
      utility.RandomPause(1);
      webDriver.FindElement(By.Id("Password")).SendKeys(userInfo.Password);
      utility.RandomPause(1);
      webDriver.FindElement(By.ClassName("cc-btn-sign-in")).Click();
      utility.RandomPause(2);
      pageText = webDriver.PageSource;
      testPassed = utility.PageIsReady(webDriver, pageText, userInfo.LoginVerifyTxt);
      if (testPassed)
      {
        resultWas.PassCount++;
      }
      else
      {
        pageText = webDriver.PageSource;
        testPassed = utility.PageIsReady(webDriver, pageText, userInfo.FirstLoginVerify);
        if (testPassed)
        {
          resultWas.PassCount++;
        }
        else if (!testPassed)
        {
          resultWas.FailCount++;
        }
      }

      return webDriver;
    }

    /// <summary>
    /// Method for filling in the user object with random data for creating unique users
    /// </summary>
    /// <param name="utility">Helper Utility object</param>
    /// <param name="logPath">Path to be used for logging errors</param>
    /// <param name="newAccount">User Data object</param>
    /// <param name="resultWas">A Pass or Fail counter object</param>
    /// <param name="iteration">Iteration count when creating mutliple users</param>
    /// <param name="custom">Bool are these custom users or randomly created; true=Custom names</param>
    /// <param name="namePreFix">String, prefix used for customer names</param>
    /// <returns>A User Object, used to complete the testing</returns>
    public UserData FillUserDetails(Utilities utility, string logPath, UserData newAccount, PassFailCount resultWas, int iteration, bool custom, string namePreFix)
    {
      string tempName = namePreFix + iteration.ToString();
      string theUniqueValue = string.Empty;
      newAccount.EpochTicks = DateTime.Now.Ticks.ToString();
      theUniqueValue = utility.Reverse(newAccount.EpochTicks);
      theUniqueValue = utility.TruncationTool(theUniqueValue, 5);

      if (custom)
      {
      newAccount.Email = tempName + "@SkyK9.Com";
      newAccount.FirstName = tempName;
      newAccount.LastName = tempName;
      newAccount.LogInAlias = tempName;
      }
      else
      {
       newAccount.Email = "EM" + theUniqueValue + "@SkyK9.Com";
       newAccount.FirstName = "AutoFirst";
       newAccount.LastName = "AutoLast" + theUniqueValue;
       newAccount.LogInAlias = "LIn" + theUniqueValue;
      }

      newAccount.SISidValue = "SIS" + theUniqueValue;
      newAccount.CRMidValue = "CRM" + theUniqueValue;
      newAccount.FirstLogLink = "ReplaceMe";
      newAccount.Password = "123456";
      newAccount.FirstLoginVerify = Properties.Settings.Default.StudentSearchVerify1st;
      newAccount.LoginVerifyTxt = Properties.Settings.Default.StudentSearchVerify2nd;

      if (newAccount.FirstLogLink == "ReplaceMe")
      {
        resultWas.PassCount++;
      }
      else
      {
        resultWas.FailCount++;
      }

      return newAccount;
    }

    /// <summary>
    /// Opens the Modal Window used for entering new user data.
    /// </summary>
    /// <param name="webDriver">WebDriver object</param>
    /// <param name="utility">Helper Utility Object</param>
    /// <param name="logPath">Path for logging errors.</param>
    /// <param name="resultWas">A pass or fail counter object.</param>
    /// <returns>IWebDriver Object</returns>
    public IWebDriver OpenCreateWindow(IWebDriver webDriver, Utilities utility, string logPath, PassFailCount resultWas)
    {
      string justRandomstring = DateTime.Now.Ticks.ToString();
      IWebElement search4Users = webDriver.FindElement(By.Id("qa-user-search-input"));
      search4Users.SendKeys(justRandomstring);
      utility.RandomPause(1);
      IWebElement registrationClick = webDriver.FindElement(By.Id("qa-register-new-user-link"));
      registrationClick.Click();
      utility.RandomPause(1);
      return webDriver;
    }

    /// <summary>
    /// Fills in the open Modal window with the data in the UserData object.
    /// </summary>
    /// <param name="webDriver">WebDriver Object</param>
    /// <param name="utility">Helper Utility Object</param>
    /// <param name="newAccount">User Data object filled out from previous method</param>
    /// <param name="logPath">Path for logging errors</param>
    /// <param name="resultWas">A pass or fail counter object.</param>
    /// <returns>IWebDriver Object</returns>
    public IWebDriver FillUserForm(IWebDriver webDriver, Utilities utility, UserData newAccount, string logPath, PassFailCount resultWas)
    {
      webDriver.FindElement(By.Id("firstName")).SendKeys(newAccount.FirstName);

      webDriver.FindElement(By.Id("lastName")).SendKeys(newAccount.LastName);

      webDriver.FindElement(By.Id("sisId")).SendKeys(newAccount.SISidValue);

      webDriver.FindElement(By.Id("crmId")).SendKeys(newAccount.CRMidValue);

      webDriver.FindElement(By.Id("email")).SendKeys(newAccount.Email);

      utility.RandomPause(3);

      webDriver.FindElement(By.Id("qa-register-user-modal-save")).Click();

      return webDriver;
    }

    /// <summary>
    /// Searches for the new user to appear, re-searches every few seconds.
    /// </summary>
    /// <param name="webDriver">WebDriver object</param>
    /// <param name="utility">Helper Utility Object</param>
    /// <param name="newAccount">New user account data object</param>
    /// <param name="logPath">Path to record logged errors.</param>
    /// <param name="resultWas">A pass or fail counter object.</param>
    /// <returns>IWebDriver object</returns>
    public IWebDriver WaitSearchNewUser(IWebDriver webDriver, Utilities utility, UserData newAccount, string logPath, PassFailCount resultWas)
    {
      bool passed = false;
      string searchFor = newAccount.LastName;
      string webResult = webDriver.PageSource;
      passed = utility.PageIsReady(webDriver, webResult, searchFor);

      if (passed)
      {
        resultWas.PassCount++;
      }
      else if (!passed)
      {
        resultWas.FailCount++;
      }

      return webDriver;
    }

    /// <summary>
    /// Copies the new users Invite link instead of parsing an email
    /// </summary>
    /// <param name="webDriver">WebDriver Object</param>
    /// <param name="utility">Helper Utility Object</param>
    /// <param name="newAccount">New user account data object</param>
    /// <param name="logPath">Path to record errors</param>
    /// <param name="resultWas">A pass or fail counter object</param>
    /// <returns>IWebeDriver object</returns>
    public IWebDriver GetInvitedLink(IWebDriver webDriver, Utilities utility, UserData newAccount, string logPath, PassFailCount resultWas)
    {
      utility.RandomPause(3);

      string newestUser = newAccount.LastName;

      newAccount.FirstLogLink = string.Empty;

      IWebElement search4Users = webDriver.FindElement(By.Id("qa-user-search-input"));

      search4Users.Clear();

      utility.RandomPause(1);

      search4Users.SendKeys(newestUser);

      utility.RandomPause(1);

      webDriver.FindElement(By.ClassName("cc-admin-users")).Click();

      utility.RandomPause(5);

      IJavaScriptExecutor pageScroll = webDriver as IJavaScriptExecutor;

      pageScroll.ExecuteScript("window.scrollBy(0,350);");

      utility.RandomPause(6);

      webDriver.FindElement(By.Id("qa-registration-status-copy-link")).Click();

      utility.RandomPause(5);

      newAccount.FirstLogLink = webDriver.FindElement(By.Id("registration-link")).GetAttribute("value");

      utility.RandomPause(1);

      utility.MakeLogEntry("Login First Time link Data");

      utility.MakeLogEntry("**" + newAccount.FirstLogLink.ToString() + "**");

      utility.MakeLogEntry("User was / is == " + newAccount.LastName);

      if (newAccount.FirstLogLink != "ReplaceMe")
      {
        resultWas.PassCount++;
      }
      else
      {
        resultWas.FailCount++;
      }

      return webDriver;
    }

    /// <summary>
    /// Performs the initial account creation, and accepts the terms of service, verified in test
    /// </summary>
    /// <param name="webDriver">WebDriver object</param>
    /// <param name="utility">Helper Utility object</param>
    /// <param name="newAccount">New Account user data object</param>
    /// <param name="logPath">Path to record error logging</param>
    /// <param name="resultWas">A pass or fail counter object.</param>
    /// <returns>IWebDriver object</returns>
    public IWebDriver FirstContact(IWebDriver webDriver, Utilities utility, UserData newAccount, string logPath, PassFailCount resultWas)
    {
      utility.RandomPause(3);

      webDriver.Navigate().GoToUrl(newAccount.FirstLogLink.ToString());

      utility.RandomPause(3);

      webDriver.FindElement(By.Id("Username")).SendKeys(newAccount.LogInAlias);

      utility.RandomPause(1);

      webDriver.FindElement(By.Id("Security_Password")).SendKeys(newAccount.Password);

      webDriver.FindElement(By.Id("Security_ConfirmPassword")).SendKeys(newAccount.Password);

      utility.RandomPause(1);

      webDriver.FindElement(By.CssSelector(".btn.btn-primary")).Click();

      utility.RandomPause(5);

      string pageText = webDriver.PageSource;
      string searchText = "314159265358979";
      int pass = 0;
      int fail = 0;

      utility.PageWeWanted(utility, pageText, "TOS~Test",  searchText, ref pass, ref fail);
      if (pass == 1)
      {
        resultWas.PassCount++;
      }
      else
      {
        resultWas.FailCount++;
      }

      webDriver.FindElement(By.Id("labelToSAcceptanceCheckbox@i")).Click();

      utility.RandomPause(1);

      IJavaScriptExecutor pageScroll = webDriver as IJavaScriptExecutor;

      pageScroll.ExecuteScript("window.scrollBy(0,150);");

      webDriver.FindElement(By.Id("acceptButton")).Click();

      utility.RandomPause(5);

      pageText = webDriver.PageSource;

      searchText = "You have not been enrolled in any courses";

      utility.PageWeWanted(utility, pageText, "Final~Test", newAccount.LoginVerifyTxt, ref pass, ref fail);
      if (pass >= 1)
      {
        resultWas.PassCount++;
      }
      else
      {
        resultWas.FailCount++;
      }

      return webDriver;
    }

    /// <summary>
    /// Used to log off any user
    /// </summary>
    /// <param name="webDriver">WebDriver object</param>
    /// <param name="utility">Helper Utility object</param>
    /// <returns>IWebDriver object</returns>
    public IWebDriver LogOff(IWebDriver webDriver, Utilities utility)
    {
      utility.RandomPause(3);

      webDriver.FindElement(By.CssSelector(".nav.navbar-nav.navbar-right>li:last-child>a")).Click();

      utility.RandomPause(1);

      webDriver.FindElement(By.Id("qa-dropdown-logout")).Click();

      utility.RandomPause(1);

      return webDriver;
    }
  }
}