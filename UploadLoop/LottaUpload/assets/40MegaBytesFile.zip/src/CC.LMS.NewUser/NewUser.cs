﻿// <copyright file="NewUser.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace CC.LMS.NewUser
{
  using System;
  using System.Drawing;
  using System.IO;
  using Microsoft.VisualStudio.TestTools.UnitTesting;
  using OpenQA.Selenium;
  using OpenQA.Selenium.Chrome;
  using Utility;

  /// <summary>
  /// Performs the create new user test.
  /// </summary>
  [TestClass]
  public class NewUser
  {
    private static string namePreFix = Properties.Settings.Default.NamePreFixx;
    private static string passWord = Properties.Settings.Default.Password;
    private static string wozLmsSitePath = Properties.Settings.Default.WOZUniversity;
    private static string testName = Properties.Settings.Default.TestName;
    private static string runDateTime = DateTime.Now.ToString("-MM-dd-HHmm");
    private static string logPath = Properties.Settings.Default.LogPath + testName + runDateTime;
    private static string chromePath = Directory.GetCurrentDirectory() + "\\assets\\";
    private static int stopLoop = Properties.Settings.Default.StopCount;
    private static int iteration = 0;
    private static bool custom = Properties.Settings.Default.CustomName;
    private Utilities utility = new Utilities(logPath);
    private PassFailCount results = new PassFailCount();
    private UserData adminUser = new UserData();
    private UserData newUser = new UserData();
    private NewUserProcess makeUser = new NewUserProcess();

    /// <summary>
    /// Initializes objects used in the testing process
    /// </summary>
    [TestInitialize]
    public void TestCount()
    {
      this.results.PassCount = this.results.PassCount + 1;
      this.adminUser.LogInAlias = Properties.Settings.Default.WOZAdmin;
      this.adminUser.Password = Properties.Settings.Default.Password;
      this.adminUser.ClientUrl = Properties.Settings.Default.WOZUniversity;
      this.adminUser.LoginVerifyTxt = Properties.Settings.Default.AdminSearchVerify;
      var newLine = Environment.NewLine;

      if (!Directory.Exists(logPath))
      {
        Directory.CreateDirectory(logPath);
        this.utility.MakeLogEntry("LogON start > " + DateTime.UtcNow.Ticks.ToString() + newLine);
      }
      else
      {
        this.utility.MakeLogEntry("LogON start > " + DateTime.UtcNow.Ticks.ToString() + newLine);
      }
    }

    /// <summary>
    /// Test to create a new user can be modified via the config file
    /// </summary>
    [TestMethod]
    public void CreateNewUser()
    {
      do
      {
        using (IWebDriver webDriver = new ChromeDriver(chromePath))
        {
          this.makeUser.BrowserReady(webDriver, this.utility, wozLmsSitePath, this.results);

          this.makeUser.Login(webDriver, this.utility, logPath, this.adminUser, this.results);

          this.makeUser.FillUserDetails(this.utility, logPath, this.newUser, this.results, iteration, custom, namePreFix);

          this.makeUser.OpenCreateWindow(webDriver, this.utility, logPath, this.results);

          this.makeUser.FillUserForm(webDriver, this.utility, this.newUser, logPath, this.results);

          this.makeUser.WaitSearchNewUser(webDriver, this.utility, this.newUser, logPath, this.results);

          if (this.results.FailCount > 0)
          {
            this.utility.MakeLogEntry("Blew UP! ! FAILED FAILED");
            this.utility.MakeLogEntry("When we waited for the user to show up as created it failed.");
            this.utility.MakeLogEntry("We exited this test no need to go deeper, exit code 1 fail 1");
            Environment.ExitCode = 1;
          }

          this.makeUser.GetInvitedLink(webDriver, this.utility, this.newUser, logPath, this.results);

          this.makeUser.LogOff(webDriver, this.utility);

          this.makeUser.FirstContact(webDriver, this.utility, this.newUser, logPath, this.results);

          this.utility.RandomPause(3);

          if (this.results.FailCount == 0)
          {
            this.utility.MakeLogEntry("PASSED ~ PASSED ~ PASSED");
            this.utility.MakeLogEntry("New User is == " + this.newUser.LogInAlias);
          }
          else
          {
            this.utility.MakeLogEntry("VERIFIED FAILED In the end there was a failure");
          }

          this.makeUser.LogOff(webDriver, this.utility);
        }

        iteration++;
      }
      while (iteration < stopLoop);
    }
  }
}
