﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class Environment
    {
        /// <summary>
        /// Initialize the environment settings to use for the integration tests.
        /// </summary>
        /// <param name="testContext">The test context.</param>
        [AssemblyInitialize]
        public static void AssemblyInitialize(TestContext testContext)
        {
            LoadEnvironmentConnectionConfiguration(testContext);
            LoadEndpointTestConfiguration(testContext);
            LoadLoadTestConfiguration(testContext);
            LoadEndToEndTestConfiguration(testContext);
        }

        private const string ENVIRONMENT_NAME_KEY = "environmentName";

        private const string ENVIRONMENT_BASE_URI_KEY = "environmentBaseUri";

        private const string ENVIRONMENT_AUTH_TOKEN_KEY = "environmentAuthToken";

        private const string ENABLE_ENDPOINT_TESTS_KEY = "enableEndpointTests";

        private const string ENABLE_LOAD_TESTS_KEY = "enableLoadTests";
        private const string NUM_REQUESTS_PER_LOAD_TEST_KEY = "numRequestsPerLoadTest";

        private const string ENABLE_E2E_TESTS_KEY = "enableEndToEndTests";

        private static string environment;

        public static string BASE_URI { get; private set; }

        public static string AUTH_TOKEN { get; private set; }

        public static bool ENABLE_ENDPOINT_TESTS { get; private set; }

        public static bool ENABLE_LOAD_TESTS { get; private set; }

        public static int NUM_REQUESTS_PER_LOAD_TEST { get; private set; }

        public static bool ENABLE_E2E_TESTS { get; private set; }

        private static void LoadEnvironmentConnectionConfiguration(TestContext testContext)
        {
            // load the environment name
            if (testContext.Properties.ContainsKey(ENVIRONMENT_NAME_KEY))
            {
                string targetEnvironmentName = testContext.Properties[ENVIRONMENT_NAME_KEY].ToString();

                Console.WriteLine($"The current environment name is '{targetEnvironmentName}'.");

                environment = targetEnvironmentName;
            }
            else
            {
                Console.WriteLine($"No name was specified for the current environment.");
            }

            // load the environment base URI
            if (testContext.Properties.ContainsKey(ENVIRONMENT_BASE_URI_KEY))
            {
                string targetEnvironmentBaseUri = testContext.Properties[ENVIRONMENT_BASE_URI_KEY].ToString();

                if (string.IsNullOrWhiteSpace(targetEnvironmentBaseUri))
                {
                    throw new InvalidOperationException($"Invalid base URI was specified for the environment.  The base URI may not be null, empty, nor whitespace.");
                }

                Console.WriteLine($"Using environment base URI '{targetEnvironmentBaseUri}'.");

                BASE_URI = targetEnvironmentBaseUri;
            }
            else
            {
                throw new InvalidOperationException($"No base URI for the environment was specified in the test context.");
            }

            // load the environment authentication token
            if (testContext.Properties.ContainsKey(ENVIRONMENT_AUTH_TOKEN_KEY))
            {
                string targetEnvironmentAuthToken = testContext.Properties[ENVIRONMENT_AUTH_TOKEN_KEY].ToString();

                if (string.IsNullOrWhiteSpace(targetEnvironmentAuthToken))
                {
                    throw new InvalidOperationException($"Invalid authentication token was specified for the environment.  The authentication token may not be null, empty, nor whitespace.");
                }

                AUTH_TOKEN = targetEnvironmentAuthToken;
            }
            else
            {
                throw new InvalidOperationException($"No authentication token for the environment was specified in the test context.");
            }
        }

        private static void LoadEndpointTestConfiguration(TestContext testContext)
        {
            // load the property that determines whether endpoint tests are enabled
            if (testContext.Properties.ContainsKey(ENABLE_ENDPOINT_TESTS_KEY))
            {
                string enableEndpointTestsValue = testContext.Properties[ENABLE_ENDPOINT_TESTS_KEY].ToString();

                if (!bool.TryParse(enableEndpointTestsValue, out bool enableEndpointTests))
                {
                    throw new InvalidOperationException($"The test context property '{ENABLE_ENDPOINT_TESTS_KEY}' must be a valid boolean value, but instead the value is '{enableEndpointTestsValue}'.");
                }
                else
                {
                    ENABLE_ENDPOINT_TESTS = enableEndpointTests;
                }

                Console.WriteLine($"Test context property '{ENABLE_ENDPOINT_TESTS_KEY}' found.  Value = {ENABLE_ENDPOINT_TESTS.ToString()}.");
            }
            else
            {
                // by default, load tests are not enabled
                ENABLE_ENDPOINT_TESTS = false;

                Console.WriteLine($"Test context property '{ENABLE_ENDPOINT_TESTS_KEY}' not found.  Default value = {ENABLE_ENDPOINT_TESTS}.");
            }
        }

        private static void LoadLoadTestConfiguration(TestContext testContext)
        {
            // load the property that determines whether load tests are enabled
            if (testContext.Properties.ContainsKey(ENABLE_LOAD_TESTS_KEY))
            {
                string enableLoadTestsValue = testContext.Properties[ENABLE_LOAD_TESTS_KEY].ToString();

                if (!bool.TryParse(enableLoadTestsValue, out bool enableLoadTests))
                {
                    throw new InvalidOperationException($"The test context property '{ENABLE_LOAD_TESTS_KEY}' must be a valid boolean value, but instead the value is '{enableLoadTestsValue}'.");
                }
                else
                {
                    ENABLE_LOAD_TESTS = enableLoadTests;
                }

                Console.WriteLine($"Test context property '{ENABLE_LOAD_TESTS_KEY}' found.  Value = {ENABLE_LOAD_TESTS.ToString()}.");
            }
            else
            {
                // by default, load tests are not enabled
                ENABLE_LOAD_TESTS = false;

                Console.WriteLine($"Test context property '{ENABLE_LOAD_TESTS_KEY}' not found.  Default value = {ENABLE_LOAD_TESTS}.");
            }

            // load the property that specifies the number of requests per load test
            if (testContext.Properties.ContainsKey(NUM_REQUESTS_PER_LOAD_TEST_KEY))
            {
                string numRequestsPerLoadTestValue = testContext.Properties[NUM_REQUESTS_PER_LOAD_TEST_KEY].ToString();

                if (!int.TryParse(numRequestsPerLoadTestValue, out int numRequestsPerLoadTest))
                {
                    throw new InvalidOperationException($"The test context property '{NUM_REQUESTS_PER_LOAD_TEST_KEY}' must be a valid integer value, but instead the value is '{numRequestsPerLoadTestValue}'.");
                }
                else
                {
                    NUM_REQUESTS_PER_LOAD_TEST = numRequestsPerLoadTest;
                }

                Console.WriteLine($"Test context property '{NUM_REQUESTS_PER_LOAD_TEST_KEY}' found.  Value = {NUM_REQUESTS_PER_LOAD_TEST}.");
            }
            else
            {
                NUM_REQUESTS_PER_LOAD_TEST = 25;

                Console.WriteLine($"Test context property '{NUM_REQUESTS_PER_LOAD_TEST_KEY}' not found.  Default value = {NUM_REQUESTS_PER_LOAD_TEST}.");
            }
        }

        private static void LoadEndToEndTestConfiguration(TestContext testContext)
        {
            // load the property that determines whether end-to-end tests are enabled
            if (testContext.Properties.ContainsKey(ENABLE_E2E_TESTS_KEY))
            {
                string enableEndToEndTestsValue = testContext.Properties[ENABLE_E2E_TESTS_KEY].ToString();

                if (!bool.TryParse(enableEndToEndTestsValue, out bool enableEndToEndTests))
                {
                    throw new InvalidOperationException($"The test context property '{ENABLE_E2E_TESTS_KEY}' must be a valid boolean value, but instead the value is '{enableEndToEndTestsValue}'.");
                }
                else
                {
                    ENABLE_E2E_TESTS = enableEndToEndTests;
                }

                Console.WriteLine($"Test context property '{ENABLE_E2E_TESTS_KEY}' found.  Value = {ENABLE_E2E_TESTS.ToString()}.");
            }
            else
            {
                // by default, end-to-end tests are not enabled
                ENABLE_E2E_TESTS = false;

                Console.WriteLine($"Test context property '{ENABLE_E2E_TESTS_KEY}' not found.  Default value = {ENABLE_E2E_TESTS}.");
            }
        }
    }
}
