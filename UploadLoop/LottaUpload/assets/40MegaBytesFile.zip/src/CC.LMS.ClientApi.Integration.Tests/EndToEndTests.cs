﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Json;
    using System.Threading.Tasks;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Courses;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Newtonsoft.Json.Linq;

    [TestClass]
    public class EndToEndTests
    {
        [ClassInitialize]
        public static void ClassInitialize(TestContext testContext)
        {
            if (!Environment.ENABLE_E2E_TESTS)
            {
                Assert.Inconclusive("End-to-end tests are currently disabled.  End-to-end tests may be enabled via the runsettings configuration.");
            }
        }

        [TestMethod]
        public async Task TestEnrollNewUsers()
        {
            // 0. load the data that will be used
            string jsonData = File.ReadAllText($".\\Data\\EndToEnd\\{nameof(TestEnrollNewUsers)}.json");
            JObject jsonObject = JObject.Parse(jsonData);

            Console.WriteLine($"RAW TEST DATA:\n{jsonObject.ToString()}");

            List<EnrollmentMetadata> newStudentUsers = new List<EnrollmentMetadata>();
            List<InstructorMetadata> newInstructorUsers = new List<InstructorMetadata>();

            foreach (JObject jsonElement in jsonObject["newStudentUsers"] as JArray)
            {
                newStudentUsers.Add(EnrollmentMetadata.Load(jsonElement));
            }

            foreach (JObject jsonElement in jsonObject["newInstructorUsers"] as JArray)
            {
                newInstructorUsers.Add(InstructorMetadata.Load(jsonElement));
            }

            SectionMetadata newSection = SectionMetadata.Load(jsonObject["newSection"] as JObject);
            CohortMetadata newCohort = CohortMetadata.Load(jsonObject["newCohort"] as JObject);

            // 1a. determine if any of the student users already exist
            foreach (UserMetadata newStudentUser in newStudentUsers)
            {
                UserMetadata existingStudentUser = await TestHelpers.SearchForSingleUserByEmailAddress(newStudentUser.EmailAddress).ConfigureAwait(false);

                if (existingStudentUser != null)
                {
                    Assert.Inconclusive($"The student user with e-mail address '{newStudentUser.EmailAddress}' already exists.");
                }
            }

            // 1b. determine if any of the instructor users already exists
            foreach (UserMetadata newInstructorUser in newInstructorUsers)
            {
                UserMetadata existingInstructorUser = await TestHelpers.SearchForSingleUserByEmailAddress(newInstructorUser.EmailAddress).ConfigureAwait(false);

                if (existingInstructorUser != null)
                {
                    Assert.Inconclusive($"The instructor user with e-mail address '{newInstructorUser.EmailAddress}' already exists.");
                }
            }

            // 1c. ensure that the course exists and is accessible
            EndpointResult courseRetrievalResult = await new RetrieveCourseByCourseCodeEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                newSection.CourseCode).CallEndpoint(null, null).ConfigureAwait(false);

            if (courseRetrievalResult.ResponseBody as JsonObject == null)
            {
                Assert.Inconclusive($"The course with course code '{newSection.CourseCode}' does not exist.");
            }

            // 2a. create the student users
            List<EnrollmentMetadata> createdStudentUsers = new List<EnrollmentMetadata>();

            foreach (EnrollmentMetadata newStudentUser in newStudentUsers)
            {
                createdStudentUsers.Add(new EnrollmentMetadata(await TestHelpers.CreateNewUser(newStudentUser).ConfigureAwait(false))
                {
                    EnrollmentDateUTC = newStudentUser.EnrollmentDateUTC,
                });
            }

            // 2b. create the instructor users
            List<InstructorMetadata> createdInstructorUsers = new List<InstructorMetadata>();

            foreach (InstructorMetadata newInstructorUser in newInstructorUsers)
            {
                createdInstructorUsers.Add(new InstructorMetadata(await TestHelpers.CreateNewUser(newInstructorUser).ConfigureAwait(false))
                {
                    Permissions = newInstructorUser.Permissions,
                });
            }

            // 5. create the section
            SectionMetadata createdSection = await TestHelpers.CreateNewSection(newSection).ConfigureAwait(false);

            // 6. create the cohort
            CohortMetadata createdCohort = await TestHelpers.CreateNewCohort(newCohort).ConfigureAwait(false);

            // 7. add the students to the cohort
            foreach (EnrollmentMetadata createdStudentUser in createdStudentUsers)
            {
                await TestHelpers.CreateNewCohortUser(createdCohort.CohortId, createdStudentUser.ExeterId);
            }

            // 8. enroll the students in the section
            foreach (EnrollmentMetadata createdStudentUser in createdStudentUsers)
            {
                await TestHelpers.CreateNewEnrollment(
                    createdSection.SectionId,
                    createdStudentUser.ExeterId,
                    createdStudentUser.EnrollmentDateUTC).ConfigureAwait(false);
            }

            // 9. add the instructors to the section
            foreach (InstructorMetadata createdInstructorUser in createdInstructorUsers)
            {
                await TestHelpers.CreateNewInstructor(
                    createdSection.SectionId,
                    createdInstructorUser.ExeterId,
                    createdInstructorUser.Permissions).ConfigureAwait(false);
            }
        }
    }
}
