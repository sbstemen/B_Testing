﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints
{
    using System;
    using System.Collections.Generic;
    using System.Json;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Common.Exceptions;
    using Microsoft.AspNetCore.WebUtilities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Newtonsoft.Json.Linq;

    internal abstract class BaseEndpoint
    {
        private readonly HttpClient _httpClient;

        public abstract HttpMethod Method { get; }

        public abstract string Endpoint { get; }

        public abstract List<ContentParameterSpecification> AcceptedContentParameters { get; }

        public virtual Type AcceptedArrayContentType { get; }

        public virtual List<QueryParameterSpecification> AcceptedQueryParameters => null;

        public virtual HashSet<HttpStatusCode> SuccessHttpResponseStatusCodes => new HashSet<HttpStatusCode>()
        {
            HttpStatusCode.OK,
        };

        public virtual HashSet<HttpStatusCode> InconclusiveHttpResponseStatusCodes => null;

        public abstract bool WaitOnTransaction { get; }

        protected BaseEndpoint(string baseUriString, string authorizationToken)
        {
            if (string.IsNullOrWhiteSpace(baseUriString))
            {
                throw new ArgumentException("Invalid base URI string.", nameof(baseUriString));
            }

            // initialize the HTTP client
            this._httpClient = new HttpClient()
            {
                BaseAddress = new Uri(baseUriString),
            };

            // initialize the default HTTP request headers
            if (!string.IsNullOrWhiteSpace(authorizationToken))
            {
                this._httpClient.DefaultRequestHeaders.Add(nameof(HttpRequestHeader.Authorization), $"Bearer {authorizationToken}");
            }

            this._httpClient.DefaultRequestHeaders.Add(nameof(HttpRequestHeader.ContentType), "application/json");
        }

        public Task<EndpointResult> CallEndpoint(List<ContentParameter> contentParameters, List<QueryParameter> queryParameters, bool throwOnError = true)
        {
            if (this.AcceptedArrayContentType != null)
            {
                throw new InvalidOperationException("Endpoint cannot accept content parameters when the endpoint accepts an array as its content.");
            }

            // convert the request payload to JSON
            StringContent content = this.FormatContentParameters(contentParameters);

            return this.CallEndpoint(content, queryParameters, throwOnError);
        }

        public Task<EndpointResult> CallEndpoint<TArrayContent>(List<TArrayContent> array, List<QueryParameter> queryParameters, bool throwOnError = true)
        {
            if (this.AcceptedContentParameters != null)
            {
                throw new InvalidOperationException("Endpoint cannot accept an array as content when it accepts content parameters.");
            }

            // convert the request payload to JSON
            StringContent content = this.FormatArrayContent<TArrayContent>(array);

            return this.CallEndpoint(content, queryParameters, throwOnError);
        }

        private Task<EndpointResult> CallEndpoint(StringContent content, List<QueryParameter> queryParameters, bool throwOnError = true)
        {
            // format the query parameters
            Dictionary<string, string> queryParameterDictionary = this.FormatQueryParameters(queryParameters);

            // generate the URI
            string uri = queryParameterDictionary == null ? this.Endpoint : QueryHelpers.AddQueryString(this.Endpoint, queryParameterDictionary);

            // call the endpoint
            return this.CallEndpoint(uri, content, throwOnError);
        }

        private async Task<EndpointResult> CallEndpoint(string uri, StringContent content, bool throwOnError = true)
        {
            HttpResponseMessage response = await this.InvokeHttpMethod(uri, content).ConfigureAwait(false);

            // process the response
            HttpStatusCode statusCode = response.StatusCode;
            string body = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (InconclusiveHttpResponseStatusCodes?.Contains(statusCode) ?? false)
            {
                if (throwOnError)
                {
                    Assert.Inconclusive($"The result of the JSON request is inconclusive!\nStatusCode = {statusCode}\nBody = {body}");
                }
                else
                {
                    return new EndpointResult(statusCode, null, null, body);
                }
            }

            if (!SuccessHttpResponseStatusCodes.Contains(statusCode))
            {
                if (throwOnError)
                {
                    string errorMessage = $"The result of the JSON request is unsuccessful!\nStatusCode = {statusCode}\nBody = {body}";

                    if (statusCode == HttpStatusCode.Unauthorized)
                    {
                        throw new UnauthorizedAccessException(errorMessage);
                    }
                    else if (statusCode == HttpStatusCode.BadRequest)
                    {
                        throw new BadRequestException(body);
                    }
                    else
                    {
                        throw new Exception(errorMessage);
                    }
                }
                else
                {
                    return new EndpointResult(statusCode, null, null, body);
                }
            }
            else
            {
                if (throwOnError)
                {
                    Console.WriteLine($"The result of the JSON request is successful!\nStatus Code = {statusCode}\nBody = {body}");
                }
            }

            JsonValue responseBody = string.IsNullOrWhiteSpace(body) ? null : JsonValue.Parse(body);

            // wait on transaction?
            TransactionMetadata transactionMetadata = null;

            if (this.WaitOnTransaction)
            {
                transactionMetadata = await this.AwaitTransactionComplete(this.GetTransactionId(responseBody as JsonObject));
            }

            // return the endpoint result
            return new EndpointResult(statusCode, responseBody, transactionMetadata);
        }

        private async Task<HttpResponseMessage> InvokeHttpMethod(string uri, HttpContent content)
        {
            HttpResponseMessage response;

            if (this.Method == HttpMethod.Get)
            {
                if (content != null)
                {
                    throw new InvalidOperationException("HTTP method GET does not support request content.");
                }

                response = await this._httpClient.GetAsync(uri).ConfigureAwait(false);
            }
            else if (this.Method == HttpMethod.Post)
            {
                response = await this._httpClient.PostAsync(uri, content).ConfigureAwait(false);
            }
            else if (this.Method == HttpMethod.Put)
            {
                response = await this._httpClient.PutAsync(uri, content).ConfigureAwait(false);
            }
            else if (this.Method == HttpMethod.Delete)
            {
                if (content != null)
                {
                    throw new InvalidOperationException("HTTP method DELETE does not support a request payload.");
                }

                response = await this._httpClient.DeleteAsync(uri).ConfigureAwait(false);
            }
            else
            {
                throw new InvalidOperationException("Unsupported HTTP method.");
            }

            return response;
        }

        private StringContent FormatContentParameters(List<ContentParameter> contentParameters)
        {
            // verify that the required parameters are specified
            if ((this.AcceptedContentParameters?.Count ?? 0) > 0)
            {
                foreach (ContentParameterSpecification specification in this.AcceptedContentParameters)
                {
                    if (specification.IsRequired)
                    {
                        // the content parameter may be null
                       ContentParameter requiredContentParameter = contentParameters
                            ?.Where(x =>
                                x.ParameterName == specification.ParameterName &&
                                (x.ParameterValue?.GetType() ?? specification.ParameterType) == specification.ParameterType)
                            .SingleOrDefault();

                        if (requiredContentParameter == null)
                        {
                            throw new InvalidOperationException($"Missing required parameter '{specification.ParameterName}', of type '{specification.ParameterType.FullName}'.");
                        }
                    }
                }
            }

            // null content was specified
            if (contentParameters == null)
            {
                return null;
            }

            string json;

            if ((contentParameters?.Count ?? 0) > 0)
            {
                if ((this.AcceptedContentParameters?.Count ?? 0) == 0)
                {
                    throw new InvalidOperationException("Parameters were specified for an endpoint that accepts no parameters.");
                }

                // verify that the specified parameters are accepted as part of this endpoint
                foreach (ContentParameter parameter in contentParameters)
                {
                    if (parameter.ParameterValue == null)
                    {
                        continue;
                    }

                    if (!this.AcceptedContentParameters.Any(x => x.ParameterName == parameter.ParameterName && x.ParameterType == parameter.ParameterValue.GetType()))
                    {
                        throw new InvalidOperationException($"Specified invalid parameter '{parameter.ParameterName}', of type '{parameter.ParameterValue.GetType()}'.");
                    }
                }

                // JSONify the parameters
                JObject jsonObject = new JObject();

                foreach (ContentParameter parameter in contentParameters)
                {
                    if (parameter.ParameterValue == null)
                    {
                        jsonObject.Add(parameter.ParameterName, null);

                        continue;
                    }

                    // convert date time to UNIX time format
                    object value = parameter.ParameterValue.GetType() == typeof(DateTime) ?
                        ((DateTime)parameter.ParameterValue).EpochMilliseconds() :
                        parameter.ParameterValue;

                    jsonObject.Add(parameter.ParameterName, JToken.FromObject(value));
                }

                json = jsonObject.ToString();
            }
            else
            {
                json = new JObject().ToString();
            }

            return GetJsonContent(json);
        }

        private StringContent FormatArrayContent<TArrayContent>(List<TArrayContent> array)
        {
            StringContent content = null;

            // verify that the array content is accepted by the endpoint
            if (this.AcceptedArrayContentType != typeof(TArrayContent))
            {
                throw new InvalidOperationException($"The specified array content type '{typeof(TArrayContent).FullName}' is not accepted by the endpoint.  The array content type '{this.AcceptedArrayContentType.FullName}' is accepted by the endpoint.");
            }

            // JSONify the array
            JArray jsonArray = new JArray();

            foreach (TArrayContent arrayContent in array)
            {
                JObject jsonObject = JObject.FromObject(arrayContent);

                jsonArray.Add(jsonObject);
            }

            string json = jsonArray.ToString();

            content = GetJsonContent(json);

            return content;
        }

        private Dictionary<string, string> FormatQueryParameters(List<QueryParameter> queryParameters)
        {
            Dictionary<string, string> queryParameterDictionary = null;

            // verify that the required query parameters are specified
            if ((this.AcceptedQueryParameters?.Count ?? 0) > 0)
            {
                foreach (QueryParameterSpecification specification in this.AcceptedQueryParameters)
                {
                    if (specification.IsRequired)
                    {
                        if (queryParameters?.Where(x => x.ParameterName == specification.ParameterName).SingleOrDefault() == null)
                        {
                            throw new InvalidOperationException($"Missing required query parameter '{specification.ParameterName}'.");
                        }
                    }
                }
            }

            if ((queryParameters?.Count ?? 0) > 0)
            {
                if ((this.AcceptedQueryParameters?.Count ?? 0) == 0)
                {
                    throw new InvalidOperationException("Query parameters were specified for an endpoint that accepts no query parameters.");
                }

                // verify that the specified query parameters are accepted as part of this endpoint
                foreach (QueryParameter parameter in queryParameters)
                {
                    if (!this.AcceptedQueryParameters.Any(x => x.ParameterName == parameter.ParameterName))
                    {
                        throw new InvalidOperationException($"Specified invalid query parameter '{parameter.ParameterName}'.");
                    }
                }

                queryParameterDictionary = new Dictionary<string, string>();

                foreach (QueryParameter parameter in queryParameters)
                {
                    queryParameterDictionary.Add(parameter.ParameterName, parameter.ParameterValue);
                }
            }

            return queryParameterDictionary;
        }

        private string GetTransactionId(JsonObject json)
        {
            return json.TryGetValue("transactionId", out JsonValue transactionId) ? transactionId : throw new InvalidOperationException("Transaction identifier not found in HTTP response body.");
        }

        private async Task<TransactionMetadata> AwaitTransactionComplete(string transactionId)
        {
            int maxAttempts = 30;
            TimeSpan checkInterval = TimeSpan.FromSeconds(2);

            int i = 0;
            while (i < maxAttempts)
            {
                (string id, TransactionStatus status, string message, JsonObject resource) = await GetTransactionStatus(transactionId);

                if (status > TransactionStatus.Processing)
                {
                    return new TransactionMetadata(id, status, message, resource);
                }

                Thread.Sleep(checkInterval);

                i++;
            }

            Assert.Fail("The transaction timed out");
            return new TransactionMetadata(string.Empty, TransactionStatus.Default, string.Empty, JsonObject.Parse(string.Empty) as JsonObject);
        }

        private async Task<TransactionMetadata> GetTransactionStatus(string transactionId)
        {
            try
            {
                HttpResponseMessage response = await this._httpClient.GetAsync($"/v1/transactions/{transactionId}");

                string body = await response.Content.ReadAsStringAsync();
                JsonObject json = JsonValue.Parse(body) as JsonObject;

                JsonValue id;
                if (!json.TryGetValue("transactionId", out id))
                {
                    throw new MissingFieldException("The transaction response did not contain an identifier.");
                }

                JsonValue status;
                if (!json.TryGetValue("status", out status))
                {
                    throw new MissingFieldException("The transaction response did not contain a status");
                }

                JsonValue message;
                json.TryGetValue("message", out message);

                JsonValue resource;
                json.TryGetValue("resource", out resource);

                return new TransactionMetadata(id, (TransactionStatus)Convert.ToInt32(status.ToString()), message, JsonObject.Parse(resource) as JsonObject);
            }
            catch (InvalidCastException e)
            {
                throw new Exception("The transaction response did not match the expected shape.", e);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private StringContent GetJsonContent(string json)
        {
            return new StringContent(json, Encoding.UTF8, "application/json");
        }
    }
}
