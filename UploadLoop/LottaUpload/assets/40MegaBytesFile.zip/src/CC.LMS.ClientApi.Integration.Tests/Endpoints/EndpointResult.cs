﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints
{
    using System.Json;
    using System.Net;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal class EndpointResult
    {
        public HttpStatusCode StatusCode { get; }

        public JsonValue ResponseBody { get; }

        public TransactionMetadata TransactionMetadata { get; }

        public string ErrorResponseBody { get; }

        public EndpointResult(
            HttpStatusCode statusCode,
            JsonValue responseBody,
            TransactionMetadata transactionMetadata,
            string errorResponseBody = null)
        {
            this.StatusCode = statusCode;
            this.ResponseBody = responseBody;
            this.TransactionMetadata = transactionMetadata;
            this.ErrorResponseBody = errorResponseBody;
        }
    }
}
