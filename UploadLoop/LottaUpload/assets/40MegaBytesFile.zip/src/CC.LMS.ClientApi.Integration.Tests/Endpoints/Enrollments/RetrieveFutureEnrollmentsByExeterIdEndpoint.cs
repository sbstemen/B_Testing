﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Enrollments
{
    using System.Collections.Generic;

    internal partial class RetrieveFutureEnrollmentsByExeterIdEndpoint : RetrievalEndpoint
    {
        public static class QueryParameterNames
        {
            public const string COURSE_CODE = "courseCode";
            public const string SECTION_START_DATE = "sectionStartDateUTC";
        }

        private readonly int _exeterId;

        public override string Endpoint => $"/v1/enrollments/future/users/{this._exeterId}";

        public override List<QueryParameterSpecification> AcceptedQueryParameters => new List<QueryParameterSpecification>()
        {
            new QueryParameterSpecification(QueryParameterNames.COURSE_CODE, false),
            new QueryParameterSpecification(QueryParameterNames.SECTION_START_DATE, false),
        };

        public RetrieveFutureEnrollmentsByExeterIdEndpoint(
            string baseUriString,
            string authorizationToken,
            int exeterId)
            : base(baseUriString, authorizationToken)
        {
            this._exeterId = exeterId;
        }
    }
}
