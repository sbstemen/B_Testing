﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Enrollments
{
    internal class RetrieveFutureEnrollmentByIdEndpoint : RetrievalEndpoint
    {
        private readonly int _futureEnrollmentId;

        public override string Endpoint => $"/v1/enrollments/future/{this._futureEnrollmentId}";

        public RetrieveFutureEnrollmentByIdEndpoint(
            string baseUriString,
            string authorizationToken,
            int futureEnrollmentId)
            : base(baseUriString, authorizationToken)
        {
            this._futureEnrollmentId = futureEnrollmentId;
        }
    }
}
