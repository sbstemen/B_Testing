﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Enrollments
{
    using System.Collections.Generic;

    internal partial class RetrieveFutureEnrollmentsBySectionStartDateEndpoint : RetrievalEndpoint
    {
        public static class QueryParameterNames
        {
            public const string COURSE_CODE = "courseCode";
            public const string EXETER_ID = "exeterId";
        }

        private readonly long _sectionStartDateUTC;

        public override string Endpoint => $"/v1/enrollments/future/dates/{this._sectionStartDateUTC}";

        public override List<QueryParameterSpecification> AcceptedQueryParameters => new List<QueryParameterSpecification>()
        {
            new QueryParameterSpecification(QueryParameterNames.COURSE_CODE, false),
            new QueryParameterSpecification(QueryParameterNames.EXETER_ID, false),
        };

        public RetrieveFutureEnrollmentsBySectionStartDateEndpoint(
            string baseUriString,
            string authorizationToken,
            long sectionStartDateUTC)
            : base(baseUriString, authorizationToken)
        {
            this._sectionStartDateUTC = sectionStartDateUTC;
        }
    }
}
