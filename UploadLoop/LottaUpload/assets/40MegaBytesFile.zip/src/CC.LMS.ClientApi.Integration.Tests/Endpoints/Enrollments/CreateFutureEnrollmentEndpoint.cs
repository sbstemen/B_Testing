﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Enrollments
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;

    internal partial class CreateFutureEnrollmentEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string COURSE_CODE = "courseCode";
            public const string EXETER_ID = "exeterId";
            public const string SECTION_START_DATE = "sectionStartDateUTC";
        }

        public override HttpMethod Method => HttpMethod.Post;

        public override string Endpoint => $"/v1/enrollments/future";

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.COURSE_CODE, typeof(string), true),
            new ContentParameterSpecification(ContentParameterNames.EXETER_ID, typeof(int), true),
            new ContentParameterSpecification(ContentParameterNames.SECTION_START_DATE, typeof(DateTime), true),
        };

        public CreateFutureEnrollmentEndpoint(
            string baseUriString,
            string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
