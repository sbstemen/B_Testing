﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Enrollments
{
    using System.Collections.Generic;

    internal partial class RetrieveFutureEnrollmentsByCourseCodeEndpoint : RetrievalEndpoint
    {
        public static class QueryParameterNames
        {
            public const string EXETER_ID = "exeterId";
            public const string SECTION_START_DATE = "sectionStartDateUTC";
        }

        private readonly string _courseCode;

        public override string Endpoint => $"/v1/enrollments/future/courses/{this._courseCode}";

        public override List<QueryParameterSpecification> AcceptedQueryParameters => new List<QueryParameterSpecification>()
        {
            new QueryParameterSpecification(QueryParameterNames.EXETER_ID, false),
            new QueryParameterSpecification(QueryParameterNames.SECTION_START_DATE, false),
        };

        public RetrieveFutureEnrollmentsByCourseCodeEndpoint(
            string baseUriString,
            string authorizationToken,
            string courseCode)
            : base(baseUriString, authorizationToken)
        {
            this._courseCode = courseCode;
        }
    }
}
