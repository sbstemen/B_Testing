﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Enrollments
{
    using System.Collections.Generic;

    internal partial class RetrieveFutureEnrollmentsBySectionStartDateEndpoint : RetrievalEndpoint
    {
        public static List<QueryParameter> GetQueryParameters(
            string courseCode,
            int exeterId)
        {
            return new List<QueryParameter>()
            {
                new QueryParameter(QueryParameterNames.COURSE_CODE, courseCode),
                new QueryParameter(QueryParameterNames.EXETER_ID, exeterId),
            };
        }
    }
}
