﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Enrollments
{
    using System;
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal partial class SearchEnrollmentProgressEndpoint
    {
        private static readonly DateTimeRange PAST_YEAR;

        static SearchEnrollmentProgressEndpoint()
        {
            DateTime utcNow = DateTime.UtcNow;

            PAST_YEAR = new DateTimeRange()
            {
                Start = utcNow - TimeSpan.FromDays(365),
                End = utcNow,
            };
        }

        public static List<ContentParameter> GetContentParametersWithCourseCodes(List<string> courseCodes)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.COURSE_CODES, courseCodes),
                new ContentParameter(ContentParameterNames.SECTION_START_DATE_RANGE, PAST_YEAR),
            };
        }

        public static List<ContentParameter> GetContentParametersWithSectionIds(List<int> sectionIds)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.SECTION_IDS, sectionIds),
                new ContentParameter(ContentParameterNames.SECTION_START_DATE_RANGE, PAST_YEAR),
            };
        }

        public static List<ContentParameter> GetContentParametersWithEnrollmentStati(List<CourseEnrollmentStatus> enrollmentStati)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.ENROLLMENT_STATI, enrollmentStati),
                new ContentParameter(ContentParameterNames.SECTION_START_DATE_RANGE, PAST_YEAR),
            };
        }

        public static List<ContentParameter> GetContentParametersWithSectionStartDateRange(DateTimeRange sectionStartDateRangeUTC)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.SECTION_START_DATE_RANGE, sectionStartDateRangeUTC),
            };
        }

        public static List<ContentParameter> GetContentParametersWithEnrollmentDateRange(DateTimeRange enrollmentDateRangeUTC)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.ENROLLMENT_DATE_RANGE, enrollmentDateRangeUTC),
            };
        }
    }
}
