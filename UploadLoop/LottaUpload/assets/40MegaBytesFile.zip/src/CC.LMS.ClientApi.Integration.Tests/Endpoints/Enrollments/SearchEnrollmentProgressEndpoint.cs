﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Enrollments
{
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal partial class SearchEnrollmentProgressEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string COURSE_CODES = "courseCodes";
            public const string SECTION_IDS = "sectionIds";
            public const string SECTION_START_DATE_RANGE = "sectionStartDateRangeUTC";
            public const string ENROLLMENT_DATE_RANGE = "enrollmentDateRangeUTC";
            public const string ENROLLMENT_STATI = "enrollmentStati";
        }

        public override HttpMethod Method => HttpMethod.Post;

        public override string Endpoint => "/v1/enrollments/progress";

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.COURSE_CODES, typeof(List<string>), false),
            new ContentParameterSpecification(ContentParameterNames.SECTION_IDS, typeof(List<int>), false),
            new ContentParameterSpecification(ContentParameterNames.SECTION_START_DATE_RANGE, typeof(DateTimeRange), false),
            new ContentParameterSpecification(ContentParameterNames.ENROLLMENT_DATE_RANGE, typeof(DateTimeRange), false),
            new ContentParameterSpecification(ContentParameterNames.ENROLLMENT_STATI, typeof(List<CourseEnrollmentStatus>), false),
        };

        public override HashSet<HttpStatusCode> InconclusiveHttpResponseStatusCodes => new HashSet<HttpStatusCode>()
        {
            HttpStatusCode.NotFound,
        };

        public override bool WaitOnTransaction => false;

        public SearchEnrollmentProgressEndpoint(
            string baseUriString,
            string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
