﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Enrollments
{
    using System;
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class CreateFutureEnrollmentEndpoint
    {
        public static List<ContentParameter> GetCreateFutureEnrollmentContentParameters(
            string courseCode,
            int exeterId,
            DateTime sectionStartDateUTC)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.COURSE_CODE, courseCode),
                new ContentParameter(ContentParameterNames.EXETER_ID, exeterId),
                new ContentParameter(ContentParameterNames.SECTION_START_DATE, sectionStartDateUTC),
            };
        }
    }
}
