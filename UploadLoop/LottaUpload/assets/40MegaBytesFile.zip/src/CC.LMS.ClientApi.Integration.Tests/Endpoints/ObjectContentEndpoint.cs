﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints
{
    using System;

    internal abstract class ObjectContentEndpoint : BaseEndpoint
    {
        public override Type AcceptedArrayContentType => null;

        public override bool WaitOnTransaction => true;

        protected ObjectContentEndpoint(string baseUriString, string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
