﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints
{
    using System;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal class QueryParameter
    {
        public string ParameterName { get; }

        public string ParameterValue { get; }

        public QueryParameter(string parameterName, int parameterValue)
        {
            this.ParameterName = parameterName;
            this.ParameterValue = parameterValue.ToString();
        }

        public QueryParameter(string parameterName, string parameterValue)
        {
            this.ParameterName = parameterName;
            this.ParameterValue = parameterValue;
        }

        public QueryParameter(string parameterName, DateTime parameterValue)
        {
            this.ParameterName = parameterName;
            this.ParameterValue = parameterValue.EpochMilliseconds().ToString();
        }
    }
}
