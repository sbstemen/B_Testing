﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class UpdateInstructorEndpoint
    {
        public static List<ContentParameter> GetUpdateInstructorStatusContentParameters(bool isActive)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.IS_ACTIVE, isActive),
            };
        }

        public static List<ContentParameter> GetUpdateInstructorStatusAndPermissionsContentParameters(
            bool isActive,
            List<InstructorPermissions> permissions)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.IS_ACTIVE, isActive),
                new ContentParameter(ContentParameterNames.PERMISSIONS, permissions),
            };
        }
    }
}
