﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    using System.Collections.Generic;
    using System.Net.Http;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal partial class UpdateInstructorEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string IS_ACTIVE = "isActive";
            public const string PERMISSIONS = "permissions";
        }

        private readonly int _sectionId;
        private readonly int _instructorId;

        public override HttpMethod Method => HttpMethod.Put;

        public override string Endpoint => $"/v1/sections/{this._sectionId}/instructors/{this._instructorId}";

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.IS_ACTIVE, typeof(bool), false),
            new ContentParameterSpecification(ContentParameterNames.PERMISSIONS, typeof(List<InstructorPermissions>), false),
        };

        public UpdateInstructorEndpoint(
            string baseUriString,
            string authorizationToken,
            int sectionId,
            int instructorId)
            : base(baseUriString, authorizationToken)
        {
            this._sectionId = sectionId;
            this._instructorId = instructorId;
        }
    }
}
