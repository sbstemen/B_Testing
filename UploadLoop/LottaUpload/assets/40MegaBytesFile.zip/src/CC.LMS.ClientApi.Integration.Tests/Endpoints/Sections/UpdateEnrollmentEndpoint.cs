﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal partial class UpdateEnrollmentEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string ENROLLMENT_STATUS = "enrollmentStatus";
            public const string ENROLLMENT_DATE = "enrollmentDateUTC";
            public const string REMOVAL_DATE = "removalDateUTC";
        }

        private readonly int _sectionId;
        private readonly int _enrollmentId;

        public override HttpMethod Method => HttpMethod.Put;

        public override string Endpoint => $"/v1/sections/{this._sectionId}/enrollments/{this._enrollmentId}";

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.ENROLLMENT_STATUS, typeof(CourseEnrollmentStatus), false),
            new ContentParameterSpecification(ContentParameterNames.ENROLLMENT_DATE, typeof(DateTime), false),
            new ContentParameterSpecification(ContentParameterNames.REMOVAL_DATE, typeof(DateTime), false),
        };

        public UpdateEnrollmentEndpoint(
            string baseUriString,
            string authorizationToken,
            int sectionId,
            int enrollmentId)
            : base(baseUriString, authorizationToken)
        {
            this._sectionId = sectionId;
            this._enrollmentId = enrollmentId;
        }
    }
}
