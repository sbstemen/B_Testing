﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal partial class CreateSectionEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string COURSE_CODE = "courseCode";
            public const string START_DATE = "startDateUTC";
            public const string END_DATE = "endDateUTC";
            public const string IS_OPEN = "isOpen";
            public const string MAX_STUDENTS = "maxStudents";
            public const string TIME_ZONE = "timeZone";
            public const string ORIGIN = "origin";
            public const string ENROLLMENT_TYPE = "enrollmentType";
            public const string COMMENTS = "comments";
        }

        public override HttpMethod Method => HttpMethod.Post;

        public override string Endpoint => "/v1/sections";

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.COURSE_CODE, typeof(string), true),
            new ContentParameterSpecification(ContentParameterNames.START_DATE, typeof(DateTime), true),
            new ContentParameterSpecification(ContentParameterNames.END_DATE, typeof(DateTime), true),
            new ContentParameterSpecification(ContentParameterNames.IS_OPEN, typeof(bool), true),
            new ContentParameterSpecification(ContentParameterNames.MAX_STUDENTS, typeof(int), true),
            new ContentParameterSpecification(ContentParameterNames.TIME_ZONE, typeof(string), true),
            new ContentParameterSpecification(ContentParameterNames.ORIGIN, typeof(OriginType), false),
            new ContentParameterSpecification(ContentParameterNames.ENROLLMENT_TYPE, typeof(SectionEnrollmentType), false),
            new ContentParameterSpecification(ContentParameterNames.COMMENTS, typeof(string), false),
        };

        public CreateSectionEndpoint(string baseUriString, string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
