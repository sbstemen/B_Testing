﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal partial class UpdateSectionEndpoint : ObjectContentEndpoint
    {
        // Origin should never be updated
        public static class ContentParameterNames
        {
            public const string START_DATE = "startDateUTC";
            public const string END_DATE = "endDateUTC";
            public const string IS_OPEN = "isOpen";
            public const string MAX_STUDENTS = "maxStudents";
            public const string TIME_ZONE_ID = "timeZoneId";
            public const string ENROLLMENT_TYPE = "enrollmentType";
            public const string COMMENTS = "comments";
            public const string ORIGIN = "origin";
        }

        private readonly int _sectionId;

        public override HttpMethod Method => HttpMethod.Put;

        public override string Endpoint => $"/v1/sections/{this._sectionId}";

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.START_DATE, typeof(DateTime), false),
            new ContentParameterSpecification(ContentParameterNames.END_DATE, typeof(DateTime), false),
            new ContentParameterSpecification(ContentParameterNames.IS_OPEN, typeof(bool), false),
            new ContentParameterSpecification(ContentParameterNames.MAX_STUDENTS, typeof(int), false),
            new ContentParameterSpecification(ContentParameterNames.TIME_ZONE_ID, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.ENROLLMENT_TYPE, typeof(SectionEnrollmentType), false),
            new ContentParameterSpecification(ContentParameterNames.COMMENTS, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.ORIGIN, typeof(OriginType), false),
        };

        public UpdateSectionEndpoint(
            string baseUriString,
            string authorizationToken,
            int sectionId)
            : base(baseUriString, authorizationToken)
        {
            this._sectionId = sectionId;
        }
    }
}
