﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class SearchSectionsEndpoint
    {
        public static List<QueryParameter> GetSearchSectionsBySectionIdQueryParameters(int sectionId)
        {
            return new List<QueryParameter>()
            {
                new QueryParameter(QueryParameterNames.SECTION_ID, sectionId.ToString()),
            };
        }

        public static List<QueryParameter> GetSearchSectionsByCourseCodeQueryParameters(string courseCode)
        {
            return new List<QueryParameter>()
            {
                new QueryParameter(QueryParameterNames.COURSE_CODE, courseCode),
            };
        }

        public static List<QueryParameter> GetSearchSectionsByOriginQueryParameters(OriginType origin)
        {
            return new List<QueryParameter>()
            {
                new QueryParameter(QueryParameterNames.ORIGIN, origin.ToString()),
            };
        }

        public static List<QueryParameter> GetSearchSectionsByEnrollmentTypeQueryParameters(SectionEnrollmentType enrollmentType)
        {
            return new List<QueryParameter>()
            {
                new QueryParameter(QueryParameterNames.ENROLLMENT_TYPE, enrollmentType.ToString()),
            };
        }

        public static List<QueryParameter> GetSearchSectionsByCommentsQueryParameters(string comments)
        {
            return new List<QueryParameter>()
            {
                new QueryParameter(QueryParameterNames.COMMENTS, comments),
            };
        }
    }
}
