﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class UpdateEnrollmentEndpoint
    {
        public static List<ContentParameter> GetUpdateEnrollmentStatusContentParameters(
            CourseEnrollmentStatus courseEnrollmentStatus)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.ENROLLMENT_STATUS, courseEnrollmentStatus),
            };
        }
    }
}
