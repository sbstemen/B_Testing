﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    using System.Collections.Generic;

    internal partial class SearchSectionsEndpoint : RetrievalEndpoint
    {
        public static class QueryParameterNames
        {
            public const string SECTION_ID = "sectionId";
            public const string START_DATE = "startDateUTC";
            public const string END_DATE = "endDateUTC";
            public const string ACTIVE_ON_DATE = "activeOnDateUTC";
            public const string COURSE_CODE = "courseCode";
            public const string IS_OPEN = "isOpen";
            public const string ORIGIN = "origin";
            public const string ENROLLMENT_TYPE = "enrollmentType";
            public const string COMMENTS = "comments";
        }

        public override string Endpoint => "/v1/sections";

        public override List<QueryParameterSpecification> AcceptedQueryParameters => new List<QueryParameterSpecification>()
        {
            new QueryParameterSpecification(QueryParameterNames.SECTION_ID, false),
            new QueryParameterSpecification(QueryParameterNames.START_DATE, false),
            new QueryParameterSpecification(QueryParameterNames.END_DATE, false),
            new QueryParameterSpecification(QueryParameterNames.ACTIVE_ON_DATE, false),
            new QueryParameterSpecification(QueryParameterNames.COURSE_CODE, false),
            new QueryParameterSpecification(QueryParameterNames.IS_OPEN, false),
            new QueryParameterSpecification(QueryParameterNames.ORIGIN, false),
            new QueryParameterSpecification(QueryParameterNames.ENROLLMENT_TYPE, false),
            new QueryParameterSpecification(QueryParameterNames.COMMENTS, false),
        };

        public SearchSectionsEndpoint(string baseUriString, string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
