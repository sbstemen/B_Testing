﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    using System;
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class CreateEnrollmentEndpoint
    {
        public static List<ContentParameter> GetCreateEnrollmentContentParameters(int exeterId, DateTime enrollmentDateUTC)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.EXETER_ID, exeterId),
                new ContentParameter(ContentParameterNames.ENROLLMENT_DATE, enrollmentDateUTC),
            };
        }
    }
}
