﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    internal class RetrieveEnrollmentsBySectionEndpoint : RetrievalEndpoint
    {
        private readonly int _sectionId;

        public override string Endpoint => $"/v1/sections/{this._sectionId}/enrollments";

        public RetrieveEnrollmentsBySectionEndpoint(
            string baseUriString,
            string authorizationToken,
            int sectionId)
            : base(baseUriString, authorizationToken)
        {
            this._sectionId = sectionId;
        }
    }
}
