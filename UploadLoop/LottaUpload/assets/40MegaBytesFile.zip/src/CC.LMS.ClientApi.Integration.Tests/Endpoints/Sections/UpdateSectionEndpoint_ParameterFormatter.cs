﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class UpdateSectionEndpoint
    {
        public static List<ContentParameter> GetUpdateSectionContentParameters(
            bool isOpen,
            int maxStudents)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.IS_OPEN, isOpen),
                new ContentParameter(ContentParameterNames.MAX_STUDENTS, maxStudents),
            };
        }

        public static List<ContentParameter> GetUpdateSectionContentParametersWithEnrollmentType(
            SectionEnrollmentType enrollmentType)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.ENROLLMENT_TYPE, enrollmentType),
            };
        }

        public static List<ContentParameter> GetUpdateSectionContentParametersWithComments(
            string comments)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.COMMENTS, comments),
            };
        }

        public static List<ContentParameter> GetUpdateSectionContentParametersWithOriginType(OriginType origin)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.ORIGIN, origin),
            };
        }
    }
}
