﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;

    internal partial class CreateEnrollmentEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string EXETER_ID = "exeterId";
            public const string ENROLLMENT_DATE = "enrollmentDateUTC";
        }

        private readonly int _sectionId;

        public override HttpMethod Method => HttpMethod.Post;

        public override string Endpoint => $"/v1/sections/{this._sectionId}/enrollments";

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.EXETER_ID, typeof(int), true),
            new ContentParameterSpecification(ContentParameterNames.ENROLLMENT_DATE, typeof(DateTime), true),
        };

        public CreateEnrollmentEndpoint(string baseUriString, string authorizationToken, int sectionId)
            : base(baseUriString, authorizationToken)
        {
            this._sectionId = sectionId;
        }
    }
}
