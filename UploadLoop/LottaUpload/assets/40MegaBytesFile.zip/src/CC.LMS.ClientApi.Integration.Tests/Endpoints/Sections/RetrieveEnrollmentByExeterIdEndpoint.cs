﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    internal class RetrieveEnrollmentByExeterIdEndpoint : RetrievalEndpoint
    {
        private readonly int _sectionId;
        private readonly int _exeterId;

        public override string Endpoint => $"/v1/sections/{this._sectionId}/users/{this._exeterId}";

        public RetrieveEnrollmentByExeterIdEndpoint(
            string baseUriString,
            string authorizationToken,
            int sectionId,
            int exeterId)
            : base(baseUriString, authorizationToken)
        {
            this._sectionId = sectionId;
            this._exeterId = exeterId;
        }
    }
}
