﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    using System.Collections.Generic;
    using System.Net.Http;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal partial class CreateInstructorEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string EXETER_ID = "exeterId";
            public const string PERMISSIONS = "permissions";
        }

        private readonly int _sectionId;

        public override HttpMethod Method => HttpMethod.Post;

        public override string Endpoint => $"/v1/sections/{this._sectionId}/instructors";

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.EXETER_ID, typeof(int), true),
            new ContentParameterSpecification(ContentParameterNames.PERMISSIONS, typeof(List<InstructorPermissions>), false),
        };

        public CreateInstructorEndpoint(string baseUriString, string authorizationToken, int sectionId)
            : base(baseUriString, authorizationToken)
        {
            this._sectionId = sectionId;
        }
    }
}
