﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections
{
    using System;
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class CreateSectionEndpoint
    {
        public static List<ContentParameter> GetCreateSectionContentParameters(
            string courseCode,
            DateTime startDateUTC,
            DateTime endDateUTC,
            int maxStudents,
            bool isOpen,
            TimeZoneInfo timeZoneInfo,
            SectionEnrollmentType enrollmentType)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.COURSE_CODE, courseCode),
                new ContentParameter(ContentParameterNames.START_DATE, startDateUTC),
                new ContentParameter(ContentParameterNames.END_DATE, endDateUTC),
                new ContentParameter(ContentParameterNames.IS_OPEN, isOpen),
                new ContentParameter(ContentParameterNames.MAX_STUDENTS, maxStudents),
                new ContentParameter(ContentParameterNames.TIME_ZONE, timeZoneInfo.StandardName),
                new ContentParameter(ContentParameterNames.ENROLLMENT_TYPE, enrollmentType),
            };
        }

        public static List<ContentParameter> GetCreateSectionContentParametersWithOriginType(
            string courseCode,
            DateTime startDateUTC,
            DateTime endDateUTC,
            int maxStudents,
            bool isOpen,
            TimeZoneInfo timeZoneInfo,
            OriginType origin)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.COURSE_CODE, courseCode),
                new ContentParameter(ContentParameterNames.START_DATE, startDateUTC),
                new ContentParameter(ContentParameterNames.END_DATE, endDateUTC),
                new ContentParameter(ContentParameterNames.IS_OPEN, isOpen),
                new ContentParameter(ContentParameterNames.MAX_STUDENTS, maxStudents),
                new ContentParameter(ContentParameterNames.TIME_ZONE, timeZoneInfo.StandardName),
                new ContentParameter(ContentParameterNames.ORIGIN, origin),
            };
        }

        public static List<ContentParameter> GetCreateSectionContentParametersWithEnrollmentType(
            string courseCode,
            DateTime startDateUTC,
            DateTime endDateUTC,
            int maxStudents,
            bool isOpen,
            TimeZoneInfo timeZoneInfo,
            SectionEnrollmentType enrollmentType)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.COURSE_CODE, courseCode),
                new ContentParameter(ContentParameterNames.START_DATE, startDateUTC),
                new ContentParameter(ContentParameterNames.END_DATE, endDateUTC),
                new ContentParameter(ContentParameterNames.IS_OPEN, isOpen),
                new ContentParameter(ContentParameterNames.MAX_STUDENTS, maxStudents),
                new ContentParameter(ContentParameterNames.TIME_ZONE, timeZoneInfo.StandardName),
                new ContentParameter(ContentParameterNames.ENROLLMENT_TYPE, enrollmentType),
            };
        }

        public static List<ContentParameter> GetCreateSectionContentParametersWithComments(
            string courseCode,
            DateTime startDateUTC,
            DateTime endDateUTC,
            int maxStudents,
            bool isOpen,
            TimeZoneInfo timeZoneInfo,
            string comments)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.COURSE_CODE, courseCode),
                new ContentParameter(ContentParameterNames.START_DATE, startDateUTC),
                new ContentParameter(ContentParameterNames.END_DATE, endDateUTC),
                new ContentParameter(ContentParameterNames.IS_OPEN, isOpen),
                new ContentParameter(ContentParameterNames.MAX_STUDENTS, maxStudents),
                new ContentParameter(ContentParameterNames.TIME_ZONE, timeZoneInfo.StandardName),
                new ContentParameter(ContentParameterNames.COMMENTS, comments),
            };
        }
    }
}
