﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class SearchUsersEndpoint
    {
        public static List<QueryParameter> GetSearchUsersByFirstNameQueryParameters(string firstNameSearchText)
        {
            return new List<QueryParameter>()
            {
                new QueryParameter(QueryParameterNames.FIRST_NAME, firstNameSearchText),
            };
        }

        public static List<QueryParameter> GetSearchUsersByLastNameQueryParameters(string lastNameSearchText)
        {
            return new List<QueryParameter>()
            {
                new QueryParameter(QueryParameterNames.LAST_NAME, lastNameSearchText),
            };
        }

        public static List<QueryParameter> GetSearchUsersByEmailAddressQueryParameters(string emailAddressSearchText)
        {
            return new List<QueryParameter>()
            {
                new QueryParameter(QueryParameterNames.EMAIL_ADDRESS, emailAddressSearchText),
            };
        }

        public static List<QueryParameter> GetSearchUsersByAllQueryParameters(
            string firstNameSearchText,
            string lastNameSearchText,
            string emailAddressSearchText)
        {
            return new List<QueryParameter>()
            {
                new QueryParameter(QueryParameterNames.FIRST_NAME, firstNameSearchText),
                new QueryParameter(QueryParameterNames.LAST_NAME, lastNameSearchText),
                new QueryParameter(QueryParameterNames.EMAIL_ADDRESS, emailAddressSearchText),
            };
        }
    }
}
