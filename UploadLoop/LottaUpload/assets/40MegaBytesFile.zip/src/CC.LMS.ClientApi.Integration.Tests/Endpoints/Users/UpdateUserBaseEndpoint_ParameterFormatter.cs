﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class UpdateUserBaseEndpoint
    {
        public static List<ContentParameter> GetUpdateUserEmailAddressContentParameters(string emailAddress)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.EMAIL_ADDRESS, emailAddress),
                new ContentParameter(ContentParameterNames.ADDRESS1, "123 ABC St."),
                new ContentParameter(ContentParameterNames.ADDRESS2, null),
                new ContentParameter(ContentParameterNames.CITY, "Houston"),
                new ContentParameter(ContentParameterNames.STATE, "TX"),
                new ContentParameter(ContentParameterNames.COUNTRY, "USA"),
                new ContentParameter(ContentParameterNames.POSTAL_CODE, "77499"),
                new ContentParameter(ContentParameterNames.PHONE_NUMBER_PRIMARY, "7130000000"),
                new ContentParameter(ContentParameterNames.PHONE_NUMBER_SECONDARY, "7130000000"),
            };
        }

        public static List<ContentParameter> GetUpdateUserCompanyContentParameters(string company)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.COMPANY, company),
            };
        }

        public static List<ContentParameter> GetContentParametersWithOrigin(OriginType origin)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.ORIGIN, origin),
            };
        }

        public static List<ContentParameter> GetContentParametersWithCampaign(string campaign)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.CAMPAIGN, campaign),
            };
        }

        public static List<ContentParameter> GetContentParametersWithComments(string comments)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.COMMENTS, comments),
            };
        }
    }
}
