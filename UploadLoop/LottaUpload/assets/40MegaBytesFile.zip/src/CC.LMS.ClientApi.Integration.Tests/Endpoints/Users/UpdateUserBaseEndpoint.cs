﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    using System.Collections.Generic;
    using System.Net.Http;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal abstract partial class UpdateUserBaseEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string FIRST_NAME = "firstName";
            public const string LAST_NAME = "lastName";
            public const string EMAIL_ADDRESS = "emailAddress";
            public const string ADDRESS1 = "address1";
            public const string ADDRESS2 = "address2";
            public const string CITY = "city";
            public const string STATE = "state";
            public const string COUNTRY = "country";
            public const string POSTAL_CODE = "postalCode";
            public const string PHONE_NUMBER_PRIMARY = "phoneNumberPrimary";
            public const string PHONE_NUMBER_SECONDARY = "phoneNumberSecondary";
            public const string LINKED_IN_URL = "linkedInUrl";
            public const string BLOG_URL = "blogUrl";
            public const string GITHUB_URL = "githubUrl";
            public const string TWITTER_HANDLE = "twitterHandle";
            public const string BIO = "bio";
            public const string EMPLOYMENT_HISTORY = "employmentHistory";
            public const string EDUCATION_HISTORY = "educationHistory";
            public const string COMPANY = "company";
            public const string JOB_TITLE = "jobTitle";
            public const string PROFILE_IMAGE_URL = "profileImageUrl";
            public const string PROFILE_MINI_IMAGE_URL = "profileMiniImageUrl";
            public const string ORIGIN = "origin";      // used to verify that the origin may not be updated
            public const string CAMPAIGN = "campaign";  // used to verify that the campaign may not be updated
            public const string COMMENTS = "comments";
        }

        public override HttpMethod Method => HttpMethod.Put;

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.FIRST_NAME, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.LAST_NAME, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.EMAIL_ADDRESS, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.ADDRESS1, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.ADDRESS2, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.CITY, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.STATE, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.COUNTRY, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.POSTAL_CODE, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.PHONE_NUMBER_PRIMARY, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.PHONE_NUMBER_SECONDARY, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.LINKED_IN_URL, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.BLOG_URL, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.GITHUB_URL, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.TWITTER_HANDLE, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.BIO, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.EMPLOYMENT_HISTORY, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.EDUCATION_HISTORY, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.COMPANY, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.JOB_TITLE, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.PROFILE_IMAGE_URL, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.PROFILE_MINI_IMAGE_URL, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.ORIGIN, typeof(OriginType), false),
            new ContentParameterSpecification(ContentParameterNames.CAMPAIGN, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.COMMENTS, typeof(string), false),
        };

        protected UpdateUserBaseEndpoint(
            string baseUriString,
            string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
