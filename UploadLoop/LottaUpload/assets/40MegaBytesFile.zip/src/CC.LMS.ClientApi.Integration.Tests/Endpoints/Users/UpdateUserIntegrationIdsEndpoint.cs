﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal class UpdateUserIntegrationIdsEndpoint : ArrayContentEndpoint
    {
        private readonly int _exeterId;

        public override HttpMethod Method => HttpMethod.Put;

        public override string Endpoint => $"/v1/users/{this._exeterId}/ids";

        public override Type AcceptedArrayContentType => typeof(IntegrationId);

        public UpdateUserIntegrationIdsEndpoint(
            string baseUriString,
            string authorizationToken,
            int exeterId)
            : base(baseUriString, authorizationToken)
        {
            this._exeterId = exeterId;
        }
    }
}
