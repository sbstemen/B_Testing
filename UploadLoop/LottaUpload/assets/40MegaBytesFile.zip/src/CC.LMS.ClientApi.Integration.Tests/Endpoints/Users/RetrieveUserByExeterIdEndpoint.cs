﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    internal class RetrieveUserByExeterIdEndpoint : RetrievalEndpoint
    {
        private readonly int _exeterId;

        public override string Endpoint => $"/v1/users/{this._exeterId}";

        public RetrieveUserByExeterIdEndpoint(string baseUriString, string authorizationToken, int exeterId)
            : base(baseUriString, authorizationToken)
        {
            this._exeterId = exeterId;
        }
    }
}
