﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    using System;
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class CreateUserAdvisorshipByExeterIdEndpoint
    {
        public static List<ContentParameter> GetContentParameters(
            int studentExeterId,
            DateTime assignmentDateUTC,
            AdvisorRole advisorRole)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.STUDENT_EXETER_ID, studentExeterId),
                new ContentParameter(ContentParameterNames.ASSIGNMENT_DATE, assignmentDateUTC),
                new ContentParameter(ContentParameterNames.ADVISOR_ROLE, advisorRole),
            };
        }

        public static List<ContentParameter> GetContentParametersWithLastMeetingDate(
            int studentExeterId,
            DateTime assignmentDateUTC,
            DateTime lastMeetingDateUTC,
            AdvisorRole advisorRole)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.STUDENT_EXETER_ID, studentExeterId),
                new ContentParameter(ContentParameterNames.ASSIGNMENT_DATE, assignmentDateUTC),
                new ContentParameter(ContentParameterNames.LAST_MEETING_DATE, lastMeetingDateUTC),
                new ContentParameter(ContentParameterNames.ADVISOR_ROLE, advisorRole),
            };
        }
    }
}
