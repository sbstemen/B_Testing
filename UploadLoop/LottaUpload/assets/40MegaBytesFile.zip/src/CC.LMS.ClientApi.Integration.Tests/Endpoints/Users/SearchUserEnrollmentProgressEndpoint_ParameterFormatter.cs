﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    using System;
    using System.Collections.Generic;

    internal partial class SearchUserEnrollmentProgressEndpoint : ObjectContentEndpoint
    {
        public static List<ContentParameter> GetContentParameters(List<string> courseCodes)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.COURSE_CODES, courseCodes),
            };
        }

        public static List<ContentParameter> GetContentParameters(List<int> sectionIds)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.SECTION_IDS, sectionIds),
            };
        }

        public static List<ContentParameter> GetContentParameters(
            List<string> courseCodes,
            List<int> sectionIds)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.COURSE_CODES, courseCodes),
                new ContentParameter(ContentParameterNames.SECTION_IDS, sectionIds),
            };
        }

        public static List<ContentParameter> GetContentParameters(bool active)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.ACTIVE, active),
            };
        }

        public static List<ContentParameter> GetContentParameters(DateTime activeAsOfDateUTC)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.ACTIVE_AS_OF_DATE_UTC, activeAsOfDateUTC),
            };
        }
    }
}
