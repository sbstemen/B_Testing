﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    internal partial class CreateUserAdvisorshipByIntegrationIdEndpoint : CreateUserAdvisorshipBaseEndpoint
    {
        private readonly int _idType;
        private readonly string _idValue;

        public override string Endpoint => $"/v1/users/ids/{this._idType}/value/{this._idValue}/advisorships";

        public CreateUserAdvisorshipByIntegrationIdEndpoint(
            string baseUriString,
            string authorizationToken,
            int idType,
            string idValue)
            : base(baseUriString, authorizationToken)
        {
            this._idType = idType;
            this._idValue = idValue;
        }
    }
}
