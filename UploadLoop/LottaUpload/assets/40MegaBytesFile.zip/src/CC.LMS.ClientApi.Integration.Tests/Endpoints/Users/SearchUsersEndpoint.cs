﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    using System.Collections.Generic;

    internal partial class SearchUsersEndpoint : RetrievalEndpoint
    {
        public static class QueryParameterNames
        {
            public const string FIRST_NAME = "firstName";
            public const string LAST_NAME = "lastName";
            public const string EMAIL_ADDRESS = "emailAddress";
            public const string INCLUDE_IDS = "includeUserOrganizationIds";
        }

        public override string Endpoint => "/v1/users";

        public override List<QueryParameterSpecification> AcceptedQueryParameters => new List<QueryParameterSpecification>()
        {
            new QueryParameterSpecification(QueryParameterNames.FIRST_NAME, false),
            new QueryParameterSpecification(QueryParameterNames.LAST_NAME, false),
            new QueryParameterSpecification(QueryParameterNames.EMAIL_ADDRESS, false),
            new QueryParameterSpecification(QueryParameterNames.INCLUDE_IDS, false),
        };

        public SearchUsersEndpoint(string baseUriString, string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
