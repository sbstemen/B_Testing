﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class CreateUserEndpoint
    {
        public static List<ContentParameter> GetCreateUserContentParameters(
            string firstName,
            string lastName,
            string emailAddress)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.FIRST_NAME, firstName),
                new ContentParameter(ContentParameterNames.LAST_NAME, lastName),
                new ContentParameter(ContentParameterNames.EMAIL_ADDRESS, emailAddress),
                new ContentParameter(ContentParameterNames.SUPPRESS_REGISTRATION_EMAIL, true),
            };
        }

        public static List<ContentParameter> GetCreateUserContentParameters(
            string firstName,
            string lastName,
            string emailAddress,
            List<IntegrationId> integrationIds)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.FIRST_NAME, firstName),
                new ContentParameter(ContentParameterNames.LAST_NAME, lastName),
                new ContentParameter(ContentParameterNames.EMAIL_ADDRESS, emailAddress),
                new ContentParameter(ContentParameterNames.ADDRESS1, "123 ABC St."),
                new ContentParameter(ContentParameterNames.ADDRESS2, null),
                new ContentParameter(ContentParameterNames.CITY, "Houston"),
                new ContentParameter(ContentParameterNames.STATE, "TX"),
                new ContentParameter(ContentParameterNames.COUNTRY, "USA"),
                new ContentParameter(ContentParameterNames.POSTAL_CODE, "77499"),
                new ContentParameter(ContentParameterNames.PHONE_NUMBER_PRIMARY, "7130000000"),
                new ContentParameter(ContentParameterNames.PHONE_NUMBER_SECONDARY, "7130000000"),
                new ContentParameter(ContentParameterNames.INTEGRATION_IDS, integrationIds),
                new ContentParameter(ContentParameterNames.SUPPRESS_REGISTRATION_EMAIL, true),
            };
        }

        public static List<ContentParameter> GetCreateUserContentParameters(
            string firstName,
            string lastName,
            string emailAddress,
            bool suppressRegistrationEmail)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.FIRST_NAME, firstName),
                new ContentParameter(ContentParameterNames.LAST_NAME, lastName),
                new ContentParameter(ContentParameterNames.EMAIL_ADDRESS, emailAddress),
                new ContentParameter(ContentParameterNames.SUPPRESS_REGISTRATION_EMAIL, suppressRegistrationEmail),
            };
        }

        public static List<ContentParameter> GetCreateUserContentParameters(
            string firstName,
            string lastName,
            string emailAddress,
            List<IntegrationId> integrationIds,
            int acceptedToSDocumentId,
            bool suppressRegistrationEmail)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.FIRST_NAME, firstName),
                new ContentParameter(ContentParameterNames.LAST_NAME, lastName),
                new ContentParameter(ContentParameterNames.EMAIL_ADDRESS, emailAddress),
                new ContentParameter(ContentParameterNames.INTEGRATION_IDS, integrationIds),
                new ContentParameter(ContentParameterNames.ACCEPTED_TOS_DOCUMENT_ID, acceptedToSDocumentId),
                new ContentParameter(ContentParameterNames.SUPPRESS_REGISTRATION_EMAIL, suppressRegistrationEmail),
            };
        }

        public static List<ContentParameter> GetContentParametersWithOriginCampaignComments(
            string firstName,
            string lastName,
            string emailAddress,
            OriginType origin,
            string campaign,
            string comments)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.FIRST_NAME, firstName),
                new ContentParameter(ContentParameterNames.LAST_NAME, lastName),
                new ContentParameter(ContentParameterNames.EMAIL_ADDRESS, emailAddress),
                new ContentParameter(ContentParameterNames.ORIGIN, origin),
                new ContentParameter(ContentParameterNames.CAMPAIGN, campaign),
                new ContentParameter(ContentParameterNames.COMMENTS, comments),
                new ContentParameter(ContentParameterNames.SUPPRESS_REGISTRATION_EMAIL, true),
            };
        }

        public static List<ContentParameter> GetContentParametersWithCampaignComments(
            string firstName,
            string lastName,
            string emailAddress,
            string campaign,
            string comments)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.FIRST_NAME, firstName),
                new ContentParameter(ContentParameterNames.LAST_NAME, lastName),
                new ContentParameter(ContentParameterNames.EMAIL_ADDRESS, emailAddress),
                new ContentParameter(ContentParameterNames.CAMPAIGN, campaign),
                new ContentParameter(ContentParameterNames.COMMENTS, comments),
                new ContentParameter(ContentParameterNames.SUPPRESS_REGISTRATION_EMAIL, true),
            };
        }
    }
}
