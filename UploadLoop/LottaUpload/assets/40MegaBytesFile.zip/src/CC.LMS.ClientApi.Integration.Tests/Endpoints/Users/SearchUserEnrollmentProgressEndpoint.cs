﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;

    internal partial class SearchUserEnrollmentProgressEndpoint : ObjectContentEndpoint
    {
        private readonly int _userId;

        public static class ContentParameterNames
        {
            public const string COURSE_CODES = "courseCodes";
            public const string SECTION_IDS = "sectionIds";
            public const string ACTIVE = "active";
            public const string ACTIVE_AS_OF_DATE_UTC = "activeAsOfDateUTC";
        }

        public override HttpMethod Method => HttpMethod.Post;

        public override string Endpoint => $"/v1/users/{this._userId}/enrollments";

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.COURSE_CODES, typeof(List<string>), false),
            new ContentParameterSpecification(ContentParameterNames.SECTION_IDS, typeof(List<int>), false),
            new ContentParameterSpecification(ContentParameterNames.ACTIVE, typeof(bool), false),
            new ContentParameterSpecification(ContentParameterNames.ACTIVE_AS_OF_DATE_UTC, typeof(DateTime), false),
        };

        public override bool WaitOnTransaction => false;

        public SearchUserEnrollmentProgressEndpoint(
            string baseUriString,
            string authorizationToken,
            int userId)
            : base(baseUriString, authorizationToken)
        {
            this._userId = userId;
        }
    }
}
