﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal abstract class CreateUserAdvisorshipBaseEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string STUDENT_EXETER_ID = "studentExeterId";
            public const string STUDENT_ID_TYPE = "studentIdType";
            public const string STUDENT_ID_VALUE = "studentIdValue";
            public const string ASSIGNMENT_DATE = "assignmentDateUTC";
            public const string LAST_MEETING_DATE = "lastMeetingDateUTC";
            public const string ADVISOR_ROLE = "advisorRole";
        }

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.STUDENT_EXETER_ID, typeof(int), false),
            new ContentParameterSpecification(ContentParameterNames.STUDENT_ID_TYPE, typeof(int), false),
            new ContentParameterSpecification(ContentParameterNames.STUDENT_ID_VALUE, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.ASSIGNMENT_DATE, typeof(DateTime), true),
            new ContentParameterSpecification(ContentParameterNames.LAST_MEETING_DATE, typeof(DateTime), false),
            new ContentParameterSpecification(ContentParameterNames.ADVISOR_ROLE, typeof(AdvisorRole), true),
        };

        public override HttpMethod Method => HttpMethod.Post;

        protected CreateUserAdvisorshipBaseEndpoint(
            string baseUriString,
            string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
