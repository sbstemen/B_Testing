﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    internal class RetrieveUserAdvisorshipsByIntegrationIdEndpoint : RetrievalEndpoint
    {
        private readonly int _idType;
        private readonly string _idValue;

        public override string Endpoint => $"/v1/users/ids/{this._idType}/value/{this._idValue}/advisorships";

        public RetrieveUserAdvisorshipsByIntegrationIdEndpoint(
            string baseUriString,
            string authorizationToken,
            int idType,
            string idValue)
            : base(baseUriString, authorizationToken)
        {
            this._idType = idType;
            this._idValue = idValue;
        }
    }
}
