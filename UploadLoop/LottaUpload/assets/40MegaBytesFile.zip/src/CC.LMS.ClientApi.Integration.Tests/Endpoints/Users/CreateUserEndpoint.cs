﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Users
{
    using System.Collections.Generic;
    using System.Net.Http;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal partial class CreateUserEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string FIRST_NAME = "firstName";
            public const string LAST_NAME = "lastName";
            public const string EMAIL_ADDRESS = "emailAddress";
            public const string ADDRESS1 = "address1";
            public const string ADDRESS2 = "address2";
            public const string CITY = "city";
            public const string STATE = "state";
            public const string COUNTRY = "country";
            public const string POSTAL_CODE = "postalCode";
            public const string PHONE_NUMBER_PRIMARY = "phoneNumberPrimary";
            public const string PHONE_NUMBER_SECONDARY = "phoneNumberSecondary";
            public const string INTEGRATION_IDS = "integrationIds";
            public const string ACCEPTED_TOS_DOCUMENT_ID = "acceptedTermsOfServiceDocumentId";
            public const string SUPPRESS_REGISTRATION_EMAIL = "suppressRegistrationEmail";
            public const string ORIGIN = "origin";
            public const string CAMPAIGN = "campaign";
            public const string COMMENTS = "comments";
        }

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.FIRST_NAME, typeof(string), true),
            new ContentParameterSpecification(ContentParameterNames.LAST_NAME, typeof(string), true),
            new ContentParameterSpecification(ContentParameterNames.EMAIL_ADDRESS, typeof(string), true),
            new ContentParameterSpecification(ContentParameterNames.ADDRESS1, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.ADDRESS2, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.CITY, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.STATE, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.COUNTRY, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.POSTAL_CODE, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.PHONE_NUMBER_PRIMARY, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.PHONE_NUMBER_SECONDARY, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.INTEGRATION_IDS, typeof(List<IntegrationId>), false),
            new ContentParameterSpecification(ContentParameterNames.ACCEPTED_TOS_DOCUMENT_ID, typeof(int), false),
            new ContentParameterSpecification(ContentParameterNames.SUPPRESS_REGISTRATION_EMAIL, typeof(bool), false),
            new ContentParameterSpecification(ContentParameterNames.ORIGIN, typeof(OriginType), false),
            new ContentParameterSpecification(ContentParameterNames.CAMPAIGN, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.COMMENTS, typeof(string), false),
        };

        public override HttpMethod Method => HttpMethod.Post;

        public override string Endpoint => "/v1/users";

        public CreateUserEndpoint(string baseUriString, string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
