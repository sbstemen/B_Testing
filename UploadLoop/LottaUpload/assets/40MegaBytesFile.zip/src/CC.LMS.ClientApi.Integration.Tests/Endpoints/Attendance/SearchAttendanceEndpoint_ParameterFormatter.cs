﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Attendance
{
    using System;
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class SearchAttendanceEndpoint
    {
        public static List<ContentParameter> GetSearchAttendanceByCourseCodesContentParameters(
            DateTime attendanceDate,
            List<string> courseCodes)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.ATTENDANCE_DATE, attendanceDate),
                new ContentParameter(ContentParameterNames.COURSE_CODES, courseCodes),
            };
        }

        public static List<ContentParameter> GetSearchAttendanceByIntegrationIdsContentParameters(
            DateTime attendanceDate,
            List<IntegrationId> integrationIds)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.ATTENDANCE_DATE, attendanceDate),
                new ContentParameter(ContentParameterNames.INTEGRATION_IDS, integrationIds),
            };
        }
    }
}
