﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.ToS
{
    using System.Collections.Generic;
    using System.Net;

    internal class RetrieveActiveToSEndpoint : RetrievalEndpoint
    {
        public override string Endpoint => "/v1/tos";

        public override HashSet<HttpStatusCode> InconclusiveHttpResponseStatusCodes => new HashSet<HttpStatusCode>()
        {
            HttpStatusCode.NotFound,
        };

        public override bool WaitOnTransaction => false;

        public RetrieveActiveToSEndpoint(string baseUriString, string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
