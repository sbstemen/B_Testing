﻿// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints
{
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;

    internal abstract class RetrievalEndpoint : BaseEndpoint
    {
        public override HttpMethod Method => HttpMethod.Get;

        public override List<ContentParameterSpecification> AcceptedContentParameters => null;

        public override HashSet<HttpStatusCode> InconclusiveHttpResponseStatusCodes => new HashSet<HttpStatusCode>()
        {
            HttpStatusCode.NotFound,
        };

        public override bool WaitOnTransaction => false;

        protected RetrievalEndpoint(string baseUriString, string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
