﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints
{
    using System.Collections.Generic;

    internal abstract class ArrayContentEndpoint : BaseEndpoint
    {
        public override List<ContentParameterSpecification> AcceptedContentParameters => null;

        public override bool WaitOnTransaction => true;

        public ArrayContentEndpoint(
            string baseUriString,
            string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
