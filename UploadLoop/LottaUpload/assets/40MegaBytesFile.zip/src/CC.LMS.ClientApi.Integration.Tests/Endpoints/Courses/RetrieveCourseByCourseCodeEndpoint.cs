﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Courses
{
    internal class RetrieveCourseByCourseCodeEndpoint : RetrievalEndpoint
    {
        private readonly string _courseCode;

        public override string Endpoint => $"/v1/courses/{this._courseCode}";

        public RetrieveCourseByCourseCodeEndpoint(
            string baseUriString,
            string authorizationToken,
            string courseCode)
            : base(baseUriString, authorizationToken)
        {
            this._courseCode = courseCode;
        }
    }
}
