﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Cohorts
{
    using System;
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class UpdateCohortEndpoint
    {
        public static List<ContentParameter> GetUpdateCohortDescriptionContentParameters(string description)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.DESCRIPTION, description),
            };
        }
    }
}
