﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Cohorts
{
    using System;
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class CreateCohortEndpoint
    {
        public static List<ContentParameter> GetCreateCohortContentParameters(
            string cohortName,
            string cohortDescription,
            DateTime startDateUTC,
            DateTime endDateUTC)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.NAME, cohortName),
                new ContentParameter(ContentParameterNames.DESCRIPTION, cohortDescription),
                new ContentParameter(ContentParameterNames.START_DATE, startDateUTC),
                new ContentParameter(ContentParameterNames.END_DATE, endDateUTC),
            };
        }
    }
}
