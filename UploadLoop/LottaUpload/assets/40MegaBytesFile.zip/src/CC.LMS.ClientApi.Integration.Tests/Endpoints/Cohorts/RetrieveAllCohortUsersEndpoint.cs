﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Cohorts
{
    internal class RetrieveAllCohortUsersEndpoint : RetrievalEndpoint
    {
        private readonly int _cohortId;

        public override string Endpoint => $"/v1/cohorts/{this._cohortId}/users";

        public RetrieveAllCohortUsersEndpoint(
            string baseUriString,
            string authorizationToken,
            int cohortId)
            : base(baseUriString, authorizationToken)
        {
            this._cohortId = cohortId;
        }
    }
}
