﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Cohorts
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;

    internal partial class UpdateCohortEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string NAME = "name";
            public const string DESCRIPTION = "description";
            public const string START_DATE = "startDateUTC";
            public const string END_DATE = "endDateUTC";
        }

        private readonly int _cohortId;

        public override HttpMethod Method => HttpMethod.Put;

        public override string Endpoint => $"/v1/cohorts/{this._cohortId}";

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.NAME, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.DESCRIPTION, typeof(string), false),
            new ContentParameterSpecification(ContentParameterNames.START_DATE, typeof(DateTime), false),
            new ContentParameterSpecification(ContentParameterNames.END_DATE, typeof(DateTime), false),
        };

        public UpdateCohortEndpoint(
            string baseUriString,
            string authorizationToken,
            int cohortId)
            : base(baseUriString, authorizationToken)
        {
            this._cohortId = cohortId;
        }
    }
}
