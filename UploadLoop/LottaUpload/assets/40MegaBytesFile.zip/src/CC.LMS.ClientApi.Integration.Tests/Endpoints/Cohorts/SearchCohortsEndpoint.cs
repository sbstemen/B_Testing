﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Cohorts
{
    using System.Collections.Generic;

    internal partial class SearchCohortsEndpoint : RetrievalEndpoint
    {
        public static class QueryParameterNames
        {
            public const string COHORT_ID = "cohortId";
            public const string START_DATE = "startDateUTC";
            public const string END_DATE = "endDateUTC";
            public const string ACTIVE_ON_DATE = "activeOnDateUTC";
            public const string NAME = "name";
        }

        public override string Endpoint => "/v1/cohorts";

        public override List<QueryParameterSpecification> AcceptedQueryParameters => new List<QueryParameterSpecification>()
        {
            new QueryParameterSpecification(QueryParameterNames.COHORT_ID, false),
            new QueryParameterSpecification(QueryParameterNames.START_DATE, false),
            new QueryParameterSpecification(QueryParameterNames.END_DATE, false),
            new QueryParameterSpecification(QueryParameterNames.ACTIVE_ON_DATE, false),
            new QueryParameterSpecification(QueryParameterNames.NAME, false),
        };

        public SearchCohortsEndpoint(string baseUriString, string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
