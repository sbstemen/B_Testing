﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Cohorts
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;

    internal partial class CreateCohortEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string NAME = "name";
            public const string DESCRIPTION = "description";
            public const string START_DATE = "startDateUTC";
            public const string END_DATE = "endDateUTC";
        }

        public override HttpMethod Method => HttpMethod.Post;

        public override string Endpoint => "/v1/cohorts";

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.NAME, typeof(string), true),
            new ContentParameterSpecification(ContentParameterNames.DESCRIPTION, typeof(string), true),
            new ContentParameterSpecification(ContentParameterNames.START_DATE, typeof(DateTime), true),
            new ContentParameterSpecification(ContentParameterNames.END_DATE, typeof(DateTime), true),
        };

        public CreateCohortEndpoint(string baseUriString, string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
