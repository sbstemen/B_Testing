﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Cohorts
{
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;

    internal class DeleteCohortUserByExeterIdEndpoint : ObjectContentEndpoint
    {
        private readonly int _cohortId;
        private readonly int _exeterId;

        public override HttpMethod Method => HttpMethod.Delete;

        public override string Endpoint => $"/v1/cohorts/{this._cohortId}/users/{this._exeterId}";

        public override List<ContentParameterSpecification> AcceptedContentParameters => null;

        public override HashSet<HttpStatusCode> InconclusiveHttpResponseStatusCodes => new HashSet<HttpStatusCode>()
        {
            HttpStatusCode.NotFound,
        };

        public DeleteCohortUserByExeterIdEndpoint(
            string baseUriString,
            string authorizationToken,
            int cohortId,
            int exeterId)
            : base(baseUriString, authorizationToken)
        {
            this._cohortId = cohortId;
            this._exeterId = exeterId;
        }
    }
}
