﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Cohorts
{
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;

    internal class DeleteCohortUserByIntegrationIdEndpoint : ObjectContentEndpoint
    {
        private readonly int _cohortId;
        private readonly int _idType;
        private readonly string _idValue;

        public override HttpMethod Method => HttpMethod.Delete;

        public override string Endpoint => $"/v1/cohorts/{this._cohortId}/users/ids/{this._idType}/value/{this._idValue}";

        public override List<ContentParameterSpecification> AcceptedContentParameters => null;

        public override HashSet<HttpStatusCode> InconclusiveHttpResponseStatusCodes => new HashSet<HttpStatusCode>()
        {
            HttpStatusCode.NotFound,
        };

        public DeleteCohortUserByIntegrationIdEndpoint(
            string baseUriString,
            string authorizationToken,
            int cohortId,
            int idType,
            string idValue)
            : base(baseUriString, authorizationToken)
        {
            this._cohortId = cohortId;
            this._idType = idType;
            this._idValue = idValue;
        }
    }
}
