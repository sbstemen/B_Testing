﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Cohorts
{
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class SearchCohortsEndpoint
    {
        public static List<QueryParameter> GetSearchCohortsByCohortIdQueryParameters(int cohortId)
        {
            return new List<QueryParameter>()
            {
                new QueryParameter(QueryParameterNames.COHORT_ID, cohortId),
            };
        }

        public static List<QueryParameter> GetSearchCohortsByNameQueryParameters(string name)
        {
            return new List<QueryParameter>()
            {
                new QueryParameter(QueryParameterNames.NAME, name),
            };
        }
    }
}
