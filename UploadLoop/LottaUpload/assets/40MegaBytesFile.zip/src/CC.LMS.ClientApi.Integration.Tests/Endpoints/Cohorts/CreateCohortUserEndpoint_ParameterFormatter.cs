﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Cohorts
{
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class CreateCohortUserEndpoint
    {
        public static List<ContentParameter> GetCreateCohortUserContentParameters(int exeterId)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(CreateCohortUserEndpoint.ContentParameterNames.EXETER_ID, exeterId),
            };
        }

        public static List<ContentParameter> GetCreateCohortUserContentParameters(int idType, string idValue)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(CreateCohortUserEndpoint.ContentParameterNames.ID_TYPE, idType),
                new ContentParameter(CreateCohortUserEndpoint.ContentParameterNames.ID_VALUE, idValue),
            };
        }
    }
}
