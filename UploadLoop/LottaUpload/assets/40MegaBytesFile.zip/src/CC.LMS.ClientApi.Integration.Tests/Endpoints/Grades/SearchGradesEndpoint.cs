﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Grades
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal partial class SearchGradesEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string COURSE_CODES = "courseCodes";
            public const string SECTION_IDS = "sectionIds";
            public const string EXETER_IDS = "exeterIds";
            public const string INTEGRATION_IDS = "integrationIds";
            public const string SECTION_START_DATE = "sectionStartDateUTC";
            public const string SECTION_END_DATE = "sectionEndDateUTC";
            public const string SECTION_ACTIVE_ON_DATE = "sectionActiveOnDateUTC";
            public const string GRADES = "grades";
        }

        public override HttpMethod Method => HttpMethod.Post;

        public override string Endpoint => "/v1/grades";

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.COURSE_CODES, typeof(List<string>), false),
            new ContentParameterSpecification(ContentParameterNames.SECTION_IDS, typeof(List<int>), false),
            new ContentParameterSpecification(ContentParameterNames.EXETER_IDS, typeof(List<int>), false),
            new ContentParameterSpecification(ContentParameterNames.INTEGRATION_IDS, typeof(List<IntegrationId>), false),
            new ContentParameterSpecification(ContentParameterNames.SECTION_START_DATE, typeof(DateTime), false),
            new ContentParameterSpecification(ContentParameterNames.SECTION_END_DATE, typeof(DateTime), false),
            new ContentParameterSpecification(ContentParameterNames.SECTION_ACTIVE_ON_DATE, typeof(DateTime), false),
            new ContentParameterSpecification(ContentParameterNames.GRADES, typeof(List<string>), false),
        };

        public override HashSet<HttpStatusCode> InconclusiveHttpResponseStatusCodes => new HashSet<HttpStatusCode>()
        {
            HttpStatusCode.NotFound,
        };

        public override bool WaitOnTransaction => false;

        public SearchGradesEndpoint(string baseUriString, string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
