﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Grades
{
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class SearchGradesEndpoint
    {
        public static List<ContentParameter> GetSearchGradesByCourseCodesContentParameters(List<string> courseCodes)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.COURSE_CODES, courseCodes),
            };
        }

        public static List<ContentParameter> GetSearchGradesByLetterGradesContentParameters(List<string> letterGrades)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.GRADES, letterGrades),
            };
        }

        public static List<ContentParameter> GetSearchGradesBySectionIdsContentParameters(List<int> sectionIds)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.SECTION_IDS, sectionIds),
            };
        }

        public static List<ContentParameter> GetSearchGradesByIntegrationIdsContentParameters(List<IntegrationId> integrationIds)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.INTEGRATION_IDS, integrationIds),
            };
        }

        public static List<ContentParameter> GetSearchGradesByExeterIdsContentParameters(List<int> exeterIds)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.EXETER_IDS, exeterIds),
            };
        }
    }
}
