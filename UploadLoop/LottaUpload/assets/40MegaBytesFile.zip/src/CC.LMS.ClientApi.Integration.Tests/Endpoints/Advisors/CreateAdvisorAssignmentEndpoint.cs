﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Advisors
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal partial class CreateAdvisorAssignmentEndpoint : ObjectContentEndpoint
    {
        public static class ContentParameterNames
        {
            public const string ADVISOR_ID = "advisorId";
            public const string STUDENT_EXETER_ID = "studentExeterId";
            public const string ASSIGNMENT_DATE = "assignmentDateUTC";
            public const string ADVISOR_ROLE = "advisorRole";
            public const string LAST_MEETING_DATE = "lastMeetingDateUTC";
        }

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.ADVISOR_ID, typeof(int), true),
            new ContentParameterSpecification(ContentParameterNames.STUDENT_EXETER_ID, typeof(int), true),
            new ContentParameterSpecification(ContentParameterNames.ASSIGNMENT_DATE, typeof(DateTime), true),
            new ContentParameterSpecification(ContentParameterNames.ADVISOR_ROLE, typeof(AdvisorRole), true),
            new ContentParameterSpecification(ContentParameterNames.LAST_MEETING_DATE, typeof(DateTime), false),
        };

        public override HttpMethod Method => HttpMethod.Post;

        public override string Endpoint => $"/v1/advisors/assignments";

        public CreateAdvisorAssignmentEndpoint(
            string baseUriString,
            string authorizationToken)
            : base(baseUriString, authorizationToken)
        {
        }
    }
}
