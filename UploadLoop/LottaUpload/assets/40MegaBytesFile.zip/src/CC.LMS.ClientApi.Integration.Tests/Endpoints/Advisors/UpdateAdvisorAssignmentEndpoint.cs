﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Advisors
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;

    internal partial class UpdateAdvisorAssignmentEndpoint : ObjectContentEndpoint
    {
        private readonly int _advisorAssignmentId;

        public static class ContentParameterNames
        {
            public const string LAST_MEETING_DATE = "lastMeetingDateUTC";
        }

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.LAST_MEETING_DATE, typeof(DateTime), false),
        };

        public override HttpMethod Method => HttpMethod.Put;

        public override string Endpoint => $"/v1/advisors/assignments/{this._advisorAssignmentId}";

        public UpdateAdvisorAssignmentEndpoint(
            string baseUriString,
            string authorizationToken,
            int advisorAssignmentId)
            : base(baseUriString, authorizationToken)
        {
            this._advisorAssignmentId = advisorAssignmentId;
        }
    }
}
