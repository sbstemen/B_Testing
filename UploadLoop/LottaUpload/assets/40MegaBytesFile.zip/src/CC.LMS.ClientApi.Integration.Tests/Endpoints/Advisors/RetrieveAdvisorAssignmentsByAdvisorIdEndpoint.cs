﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Advisors
{
    internal class RetrieveAdvisorAssignmentsByAdvisorIdEndpoint : RetrievalEndpoint
    {
        private readonly int _advisorId;

        public override string Endpoint => $"/v1/advisors/{this._advisorId}/assignments";

        public RetrieveAdvisorAssignmentsByAdvisorIdEndpoint(
            string baseUriString,
            string authorizationToken,
            int advisorId)
            : base(baseUriString, authorizationToken)
        {
            this._advisorId = advisorId;
        }
    }
}
