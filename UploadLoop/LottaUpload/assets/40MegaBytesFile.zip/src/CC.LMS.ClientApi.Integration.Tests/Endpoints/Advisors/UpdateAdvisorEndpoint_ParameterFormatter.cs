﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Advisors
{
    using System.Collections.Generic;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;

    internal partial class UpdateAdvisorEndpoint
    {
        public static List<ContentParameter> GetContentParameters(List<AdvisorRole> advisorRoles)
        {
            return new List<ContentParameter>()
            {
                new ContentParameter(ContentParameterNames.ADVISOR_ROLES, advisorRoles),
            };
        }
    }
}
