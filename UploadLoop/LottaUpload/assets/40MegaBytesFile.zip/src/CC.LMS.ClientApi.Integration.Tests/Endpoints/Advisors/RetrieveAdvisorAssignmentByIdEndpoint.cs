﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Advisors
{
    internal class RetrieveAdvisorAssignmentByIdEndpoint : RetrievalEndpoint
    {
        private readonly int _advisorAssignmentId;

        public override string Endpoint => $"/v1/advisors/assignments/{this._advisorAssignmentId}";

        public RetrieveAdvisorAssignmentByIdEndpoint(
            string baseUriString,
            string authorizationToken,
            int advisorAssignmentId)
            : base(baseUriString, authorizationToken)
        {
            this._advisorAssignmentId = advisorAssignmentId;
        }
    }
}
