﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints.Advisors
{
    using System.Collections.Generic;
    using System.Net.Http;
    using CC.LMS.ClientApi.Integration.Tests.Common;

    internal partial class UpdateAdvisorEndpoint : ObjectContentEndpoint
    {
        private readonly int _advisorId;

        public static class ContentParameterNames
        {
            public const string ADVISOR_ROLES = "advisorRoles";
        }

        public override List<ContentParameterSpecification> AcceptedContentParameters => new List<ContentParameterSpecification>()
        {
            new ContentParameterSpecification(ContentParameterNames.ADVISOR_ROLES, typeof(List<AdvisorRole>), false),
        };

        public override HttpMethod Method => HttpMethod.Put;

        public override string Endpoint => $"/v1/advisors/{this._advisorId}";

        public UpdateAdvisorEndpoint(
            string baseUriString,
            string authorizationToken,
            int advisorId)
            : base(baseUriString, authorizationToken)
        {
            this._advisorId = advisorId;
        }
    }
}
