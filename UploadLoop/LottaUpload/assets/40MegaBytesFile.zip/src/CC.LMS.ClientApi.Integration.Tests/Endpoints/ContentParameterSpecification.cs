﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Endpoints
{
    using System;

    internal class ContentParameterSpecification
    {
        public string ParameterName { get; }

        public Type ParameterType { get; }

        public bool IsRequired { get; }

        public ContentParameterSpecification(string parameterName, Type parameterType, bool isRequired)
        {
            this.ParameterName = parameterName;
            this.ParameterType = parameterType;
            this.IsRequired = isRequired;
        }
    }
}
