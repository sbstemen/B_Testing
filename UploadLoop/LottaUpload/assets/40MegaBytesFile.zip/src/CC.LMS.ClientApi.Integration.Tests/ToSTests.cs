﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests
{
    using System;
    using System.Json;
    using System.Threading.Tasks;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.ToS;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ToSTests
    {
        [ClassInitialize]
        public static void ClassInitialize(TestContext testContext)
        {
            if (!Environment.ENABLE_ENDPOINT_TESTS)
            {
                Assert.Inconclusive("Endpoint tests are currently disabled.  Endpoint tests may be enabled via the runsettings configuration.");
            }
        }

        [TestMethod]
        public async Task TestRetrieveActiveToS()
        {
            EndpointResult result = await new RetrieveActiveToSEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(null, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            var json = result.ResponseBody as JsonObject;

            Assert.IsTrue(json != null);
            Assert.IsTrue(json.ContainsKey("termsOfServiceDocumentId"));
            Assert.IsTrue(json.ContainsKey("termsOfServiceContent"));

            Console.WriteLine(json.ToString());
        }

        [TestMethod]
        [ExpectedException(typeof(UnauthorizedAccessException))]
        public async Task TestRetrieveActiveToSWithBogusAuthToken()
        {
            string bogusAuthToken = "945863aa027379046b25f652e8186edbf74567df5b0274fa12617367a6d05bce";

            EndpointResult result = await new RetrieveActiveToSEndpoint(
                Environment.BASE_URI,
                bogusAuthToken).CallEndpoint(null, null).ConfigureAwait(false);
        }
    }
}
