﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Json;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class SectionsTests
    {
        private static int DefaultSectionId { get; set; }

        private static UserIdSet DefaultUserIdSet { get; set; }

        private static int DefaultEnrollmentId { get; set; }

        private static int DefaultInstructorId { get; set; }

        private const string VALID_COMMENTS = "Comments";

        private const string UPDATED_COMMENTS = "New Comments";

        private const string INVALID_LENGTH_COMMENTS = "TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments, TestComments";

        private const string INVALID_CHARACTER_COMMENTS = "╘·├█╥";

        [ClassInitialize]
        public static async Task ClassInitialize(TestContext testContext)
        {
            if (!Environment.ENABLE_ENDPOINT_TESTS)
            {
                Assert.Inconclusive("Endpoint tests are currently disabled.  Endpoint tests may be enabled via the runsettings configuration.");
            }

            await Task.WhenAll(InitializeDefaultSection(), InitializeDefaultUser());
            await Task.WhenAll(InitializeDefaultEnrollment(), InitializeDefaultInstructor());
        }

        [TestMethod]
        public async Task TestCreateSection()
        {
            List<ContentParameter> contentParameters = CreateSectionEndpoint.GetCreateSectionContentParameters(
                "CFSG105",
                DateTime.UtcNow.Add(TimeSpan.FromDays(15)),
                DateTime.UtcNow.Add(TimeSpan.FromDays(30)),
                20,
                false,
                TimeZoneInfo.GetSystemTimeZones().First(),
                SectionEnrollmentType.Traditional);

            EndpointResult result = await new CreateSectionEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestCreateOnDemandSection()
        {
            List<ContentParameter> contentParameters = CreateSectionEndpoint.GetCreateSectionContentParametersWithEnrollmentType(
                "CFSG105",
                DateTime.UtcNow.Add(TimeSpan.FromDays(15)),
                DateTime.UtcNow.Add(TimeSpan.FromDays(30)),
                20,
                false,
                TimeZoneInfo.GetSystemTimeZones().First(),
                SectionEnrollmentType.OnDemand);

            EndpointResult result = await new CreateSectionEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

            var createdSection = SectionMetadata.Load(result.TransactionMetadata.Resource);

            Assert.IsTrue(createdSection.EnrollmentType == SectionEnrollmentType.OnDemand);
        }

        [TestMethod]
        public async Task TestCreateClientOriginSection()
        {
            List<ContentParameter> contentParameters = CreateSectionEndpoint.GetCreateSectionContentParametersWithOriginType(
                "CFSG105",
                DateTime.UtcNow.Add(TimeSpan.FromDays(15)),
                DateTime.UtcNow.Add(TimeSpan.FromDays(30)),
                20,
                false,
                TimeZoneInfo.GetSystemTimeZones().First(),
                OriginType.Platform);

            EndpointResult result = await new CreateSectionEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

            var createdSection = SectionMetadata.Load(result.TransactionMetadata.Resource);

            Assert.IsTrue(createdSection.Origin == OriginType.Client);
        }

        [TestMethod]
        public async Task TestCreateCommentsSection()
        {
            List<ContentParameter> contentParameters = CreateSectionEndpoint.GetCreateSectionContentParametersWithComments(
                "CFSG105",
                DateTime.UtcNow.Add(TimeSpan.FromDays(15)),
                DateTime.UtcNow.Add(TimeSpan.FromDays(30)),
                20,
                false,
                TimeZoneInfo.GetSystemTimeZones().First(),
                VALID_COMMENTS);

            EndpointResult result = await new CreateSectionEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

            var createdSection = SectionMetadata.Load(result.TransactionMetadata.Resource);

            Assert.AreEqual(VALID_COMMENTS, createdSection.Comments);
        }

        [TestMethod]
        public async Task TestCreateSectionWithCommentsOverMaxLength()
        {
            List<ContentParameter> contentParameters = CreateSectionEndpoint.GetCreateSectionContentParametersWithComments(
                "CFSG105",
                DateTime.UtcNow.Add(TimeSpan.FromDays(15)),
                DateTime.UtcNow.Add(TimeSpan.FromDays(30)),
                20,
                false,
                TimeZoneInfo.GetSystemTimeZones().First(),
                INVALID_LENGTH_COMMENTS);

            EndpointResult result = await new CreateSectionEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null, false);

            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.BadRequest, result.StatusCode);
        }

        [TestMethod]
        public async Task TestSearchSectionsBySectionId()
        {
            // search for a section by section ID
            List<QueryParameter> queryParameters = SearchSectionsEndpoint.GetSearchSectionsBySectionIdQueryParameters(DefaultSectionId);

            EndpointResult result = await new SearchSectionsEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(null, queryParameters).ConfigureAwait(false);

            // verify that the response is valid JSON
            var json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count > 0)
            {
                Assert.IsTrue(json
                    .Select(x => SectionMetadata.Load(x as JsonObject))
                    .All(x => x.SectionId == DefaultSectionId));
            }
            else
            {
                Assert.Inconclusive("No sections were found when searching by section ID.");
            }
        }

        [TestMethod]
        public async Task TestSearchSectionsByCourseCode()
        {
            // search for sections by course code
            List<QueryParameter> queryParameters = SearchSectionsEndpoint.GetSearchSectionsByCourseCodeQueryParameters("CFSG105");

            EndpointResult result = await new SearchSectionsEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(null, queryParameters).ConfigureAwait(false);

            // verify that the response if valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count > 0)
            {
                Assert.IsTrue(json
                    .Select(x => SectionMetadata.Load(x as JsonObject))
                    .All(x => x.CourseCode == "CFSG105"));
            }
            else
            {
                Assert.Inconclusive("No sections were found when searching by course code.");
            }
        }

        [TestMethod]
        public async Task TestSearchSectionsByEnrollmentTypeOnDemand()
        {
            // search for sections by enrollment type "OnDemand"
            List<QueryParameter> queryParameters = SearchSectionsEndpoint.GetSearchSectionsByEnrollmentTypeQueryParameters(SectionEnrollmentType.OnDemand);

            EndpointResult result = await new SearchSectionsEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(null, queryParameters).ConfigureAwait(false);

            // verify that the response if valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count > 0)
            {
                Assert.IsTrue(json
                    .Select(x => SectionMetadata.Load(x as JsonObject))
                    .All(x => x.EnrollmentType == SectionEnrollmentType.OnDemand));
            }
            else
            {
                Assert.Inconclusive("No sections were found when searching by enrollment type 'OnDemand'.");
            }
        }

        [TestMethod]
        public async Task TestSearchSectionsByComments()
        {
            // search for sections by comments
            List<QueryParameter> queryParameters = SearchSectionsEndpoint.GetSearchSectionsByCommentsQueryParameters(VALID_COMMENTS);

            EndpointResult result = await new SearchSectionsEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(null, queryParameters).ConfigureAwait(false);

            // verify that the response if valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count > 0)
            {
                // Allow both full and partial matches of search string and comments
                Assert.IsTrue(json
                    .Select(x => SectionMetadata.Load(x as JsonObject))
                    .All(x => x.Comments.ToLowerInvariant().Contains(VALID_COMMENTS.ToLowerInvariant())));
            }
            else
            {
                Assert.Inconclusive("No sections were found when searching by comments.");
            }
        }

        [TestMethod]
        public async Task TestSearchSectionsByOriginTypeOfClient()
        {
            // search for sections by comments
            List<QueryParameter> queryParameters = SearchSectionsEndpoint.GetSearchSectionsByOriginQueryParameters(OriginType.Client);

            EndpointResult result = await new SearchSectionsEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(null, queryParameters).ConfigureAwait(false);

            // verify that the response if valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count > 0)
            {
                Assert.IsTrue(json
                    .Select(x => SectionMetadata.Load(x as JsonObject))
                    .All(x => x.Origin == OriginType.Client));
            }
            else
            {
                Assert.Inconclusive("No sections were found when searching by origin type 'client'.");
            }
        }

        [TestMethod]
        public async Task TestRetrieveSectionBySectionId()
        {
            Assert.IsTrue(DefaultSectionId != default(int));

            EndpointResult result = await new RetrieveSectionBySectionIdEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN, DefaultSectionId).CallEndpoint(null, null).ConfigureAwait(false);

            JsonObject json = result.ResponseBody as JsonObject;

            Assert.IsTrue(json != null);
        }

        [TestMethod]
        public async Task TestCreateInstructorWithPermissions()
        {
            Assert.IsTrue(DefaultSectionId != default(int));

            UserIdSet userIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);

            List<ContentParameter> contentParameters = CreateInstructorEndpoint.GetCreateInstructorContentParameters(
                userIdSet.UserId,
                new List<InstructorPermissions>()
                {
                    InstructorPermissions.Ownership,
                    InstructorPermissions.AlterFinalGrade
                });

            EndpointResult result = await new CreateInstructorEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestCreateInstructorWithNullPermissions()
        {
            Assert.IsTrue(DefaultSectionId != default(int));

            UserIdSet userIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);

            List<ContentParameter> contentParameters = CreateInstructorEndpoint.GetCreateInstructorContentParameters(
                userIdSet.UserId,
                null);

            EndpointResult result = await new CreateInstructorEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestCreateInstructorWithMissingPermissions()
        {
            Assert.IsTrue(DefaultSectionId != default(int));

            UserIdSet userIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);

            List<ContentParameter> contentParameters = CreateInstructorEndpoint.GetCreateInstructorContentParameters(userIdSet.UserId);

            EndpointResult result = await new CreateInstructorEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestUpdateInstructorWithPermissions()
        {
            Assert.IsTrue(DefaultSectionId != default(int));
            Assert.IsTrue(DefaultInstructorId != default(int));

            List<ContentParameter> contentParameters = UpdateInstructorEndpoint.GetUpdateInstructorStatusAndPermissionsContentParameters(
                false,
                new List<InstructorPermissions>()
                {
                    InstructorPermissions.InitialGrade,
                    InstructorPermissions.AlterTotalPoints,
                    InstructorPermissions.AlterFeedback,
                });

            EndpointResult result = await new UpdateInstructorEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId,
                DefaultInstructorId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestUpdateInstructorWithNullPermissions()
        {
            Assert.IsTrue(DefaultSectionId != default(int));
            Assert.IsTrue(DefaultInstructorId != default(int));

            List<ContentParameter> contentParameters = UpdateInstructorEndpoint.GetUpdateInstructorStatusAndPermissionsContentParameters(
                false,
                null);

            EndpointResult result = await new UpdateInstructorEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId,
                DefaultInstructorId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestUpdateInstructorWithMissingPermissions()
        {
            Assert.IsTrue(DefaultSectionId != default(int));
            Assert.IsTrue(DefaultInstructorId != default(int));

            List<ContentParameter> contentParameters = UpdateInstructorEndpoint.GetUpdateInstructorStatusContentParameters(false);

            EndpointResult result = await new UpdateInstructorEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId,
                DefaultInstructorId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestRetrieveInstructorsBySection()
        {
            Assert.IsTrue(DefaultSectionId != default(int));
            Assert.IsTrue(DefaultInstructorId != default(int));

            EndpointResult result = await new RetrieveInstructorsBySectionEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId).CallEndpoint(null, null).ConfigureAwait(false);

            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);
        }

        [TestMethod]
        public async Task TestCreateEnrollment()
        {
            int sectionId = await TestHelpers.CreateDefaultSection().ConfigureAwait(false);
            UserIdSet userIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);

            List<ContentParameter> contentParameters = CreateEnrollmentEndpoint.GetCreateEnrollmentContentParameters(userIdSet.UserId, DateTime.UtcNow.Add(TimeSpan.FromDays(5)));

            EndpointResult result = await new CreateEnrollmentEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN, sectionId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestUpdateEnrollment()
        {
            Assert.IsTrue(DefaultSectionId != default(int));
            Assert.IsTrue(DefaultEnrollmentId != default(int));

            List<ContentParameter> contentParameters = UpdateEnrollmentEndpoint.GetUpdateEnrollmentStatusContentParameters(CourseEnrollmentStatus.Graduated);

            EndpointResult result = await new UpdateEnrollmentEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId,
                DefaultEnrollmentId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestRetrieveEnrollmentsBySection()
        {
            Assert.IsTrue(DefaultSectionId != default(int));

            EndpointResult result = await new RetrieveEnrollmentsBySectionEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN, DefaultSectionId).CallEndpoint(null, null).ConfigureAwait(false);

            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);
        }

        [TestMethod]
        public async Task TestRetrieveEnrollmentByExeterId()
        {
            Assert.IsTrue(DefaultSectionId != default(int));
            Assert.IsTrue((DefaultUserIdSet?.UserId ?? default(int)) != default(int));

            // add a second enrollment to the section
            await TestHelpers.CreateNewEnrollment(DefaultSectionId).ConfigureAwait(false);

            EndpointResult result = await new RetrieveEnrollmentByExeterIdEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN, DefaultSectionId, DefaultUserIdSet.UserId).CallEndpoint(null, null).ConfigureAwait(false);

            JsonObject json = result.ResponseBody as JsonObject;

            Assert.IsTrue(json != null);
        }

        [TestMethod]
        public async Task TestRetrieveEnrollmentByIntegrationid()
        {
            Assert.IsTrue(DefaultSectionId != default(int));
            Assert.IsTrue((DefaultUserIdSet?.IntegrationIds?.Count ?? 0) > 0);

            // add a second enrollment to the section
            await TestHelpers.CreateNewEnrollment(DefaultSectionId).ConfigureAwait(false);

            foreach (IntegrationId integrationId in DefaultUserIdSet.IntegrationIds)
            {
                EndpointResult result = await new RetrieveEnrollmentByIntegrationIdEndpoint(
                    Environment.BASE_URI,
                    Environment.AUTH_TOKEN,
                    DefaultSectionId,
                    integrationId.idType,
                    integrationId.idValue).CallEndpoint(null, null).ConfigureAwait(false);

                JsonObject json = result.ResponseBody as JsonObject;

                Assert.IsTrue(json != null);
            }
        }

        [TestMethod]
        public async Task TestRetrieveEnrollmentByEnrollmentId()
        {
            Assert.IsTrue(DefaultSectionId != default(int));
            Assert.IsTrue(DefaultEnrollmentId != default(int));

            // add a second enrollment to the section
            await TestHelpers.CreateNewEnrollment(DefaultSectionId).ConfigureAwait(false);

            EndpointResult result = await new RetrieveEnrollmentByEnrollmentIdEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN, DefaultSectionId, DefaultEnrollmentId).CallEndpoint(null, null).ConfigureAwait(false);

            JsonObject json = result.ResponseBody as JsonObject;

            Assert.IsTrue(json != null);
        }

        private static async Task InitializeDefaultSection()
        {
            DefaultSectionId = await TestHelpers.CreateDefaultSection().ConfigureAwait(false);
        }

        private static async Task InitializeDefaultUser()
        {
            DefaultUserIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);
        }

        private static async Task InitializeDefaultEnrollment()
        {
            if (DefaultSectionId == default(int))
            {
                throw new Exception("Cannot initialize enrollment.  The default section identifier is missing.");
            }

            if ((DefaultUserIdSet?.UserId ?? default(int)) == default(int))
            {
                throw new Exception("Cannot initialize enrollment.  The default user identifier is missing.");
            }

            DefaultEnrollmentId = await TestHelpers.CreateDefaultEnrollment(DefaultSectionId, DefaultUserIdSet.UserId).ConfigureAwait(false);
        }

        private static async Task InitializeDefaultInstructor()
        {
            if ((DefaultUserIdSet?.UserId ?? default(int)) == default(int))
            {
                throw new Exception("Cannot initialize enrollment.  The default user identifier is missing.");
            }

            // create a separate section for which the default user will be an instructor
            int sectionId = await TestHelpers.CreateDefaultSection().ConfigureAwait(false);

            DefaultInstructorId = await TestHelpers.CreateDefaultInstructor(sectionId, DefaultUserIdSet.UserId).ConfigureAwait(false);
        }

        [TestMethod]
        public async Task TestUpdateSection()
        {
            Assert.IsTrue(DefaultSectionId != default(int));

            List<ContentParameter> contentParameters = UpdateSectionEndpoint.GetUpdateSectionContentParameters(
                false,
                20);

            EndpointResult result = await new UpdateSectionEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestUpdateSectionComments()
        {
            Assert.IsTrue(DefaultSectionId != default(int));

            List<ContentParameter> contentParameters = UpdateSectionEndpoint.GetUpdateSectionContentParametersWithComments(UPDATED_COMMENTS);

            EndpointResult result = await new UpdateSectionEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestUpdateSectionWithCommentsOverMaxLength()
        {
            Assert.IsTrue(DefaultSectionId != default(int));

            List<ContentParameter> contentParameters = UpdateSectionEndpoint.GetUpdateSectionContentParametersWithComments(INVALID_LENGTH_COMMENTS);

            EndpointResult result = await new UpdateSectionEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId).CallEndpoint(contentParameters, null, false).ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.BadRequest, result.StatusCode);
        }

        [TestMethod]
        public async Task TestUpdateSectionCommentsWithInvalidCharacters()
        {
            Assert.IsTrue(DefaultSectionId != default(int));

            List<ContentParameter> contentParameters = UpdateSectionEndpoint.GetUpdateSectionContentParametersWithComments(INVALID_CHARACTER_COMMENTS);

            EndpointResult result = await new UpdateSectionEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId).CallEndpoint(contentParameters, null, false).ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.BadRequest, result.StatusCode);
        }

        [TestMethod]
        public async Task TestUpdateSectionEnrollmentType()
        {
            Assert.IsTrue(DefaultSectionId != default(int));

            List<ContentParameter> contentParameters = UpdateSectionEndpoint.GetUpdateSectionContentParametersWithEnrollmentType(SectionEnrollmentType.OnDemand);

            EndpointResult result = await new UpdateSectionEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId).CallEndpoint(contentParameters, null, false).ConfigureAwait(false);

            Assert.IsNotNull(result);

            JsonValue value;
            result.TransactionMetadata.Resource.TryGetValue("enrollmentType", out value);
            Assert.IsNotNull(value);
            Assert.IsTrue((int)value == (int)SectionEnrollmentType.OnDemand);
        }

        [TestMethod]
        public async Task TestUpdateSectionOriginType()
        {
            Assert.IsTrue(DefaultSectionId != default(int));

            List<ContentParameter> contentParameters =
                UpdateSectionEndpoint.GetUpdateSectionContentParametersWithOriginType(OriginType.Client);

            EndpointResult result = await new UpdateSectionEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultSectionId).CallEndpoint(contentParameters, null, false).ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.BadRequest, result.StatusCode);
        }
    }
}