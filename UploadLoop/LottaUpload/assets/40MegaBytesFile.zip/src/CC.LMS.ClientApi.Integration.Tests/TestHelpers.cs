﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Json;
    using System.Net;
    using System.Threading.Tasks;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Advisors;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Cohorts;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Enrollments;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Sections;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Users;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    public static class TestHelpers
    {
        public static async Task<int> CreateDefaultSection()
        {
            string courseCode = "CFSG105";
            DateTime endDateUTC = DateTime.UtcNow;
            DateTime startDateUTC = endDateUTC.Subtract(TimeSpan.FromDays(7));

            List<ContentParameter> contentParameters = CreateSectionEndpoint.GetCreateSectionContentParameters(
                courseCode,
                startDateUTC,
                endDateUTC,
                0,
                true,
                TimeZoneInfo.Local,
                SectionEnrollmentType.Traditional);

            EndpointResult result = await new CreateSectionEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            if (!result.TransactionMetadata.Resource.TryGetValue("sectionId", out JsonValue id))
            {
                throw new MissingFieldException("The section id was not found on the returned resource!");
            }

            // return the identifier of the section entity that was created
            return Convert.ToInt32(id.ToString());
        }

        public static async Task<UserIdSet> CreateDefaultUser()
        {
            string guid = Guid.NewGuid().ToString();

            string firstName = "John";
            string lastName = "Smith";
            string personalId = $"{firstName}.{lastName}.{guid}";

            List<ContentParameter> contentParameters = CreateUserEndpoint.GetCreateUserContentParameters(
                firstName,
                lastName,
                $"{personalId}@d.codercamps.com",
                new List<IntegrationId>()
                {
                    new IntegrationId(1, personalId),
                    new IntegrationId(2, personalId),
                });

            EndpointResult result = await new CreateUserEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            int userId;
            List<IntegrationId> integrationIds = new List<IntegrationId>();

            // retrieve the user id
            userId = RetrieveExeterIdFromUserResource(result.TransactionMetadata.Resource);

            // retrieve the integration ids
            integrationIds = RetrieveIntegrationIdsFromUserResource(result.TransactionMetadata.Resource);

            // return the user id set of the user entity that was created
            return new UserIdSet(userId, integrationIds);
        }

        public static async Task<int> CreateDefaultEnrollment(
            int sectionId,
            int exeterId)
        {
            List<ContentParameter> contentParameters = CreateEnrollmentEndpoint.GetCreateEnrollmentContentParameters(exeterId, DateTime.UtcNow);

            EndpointResult result = await new CreateEnrollmentEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN, sectionId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            if (!result.TransactionMetadata.Resource.TryGetValue("enrollmentId", out JsonValue id))
            {
                throw new MissingFieldException("The enrollment id was not found on the returned resource!");
            }

            // return the identifier of the enrollment entity that was created
            return Convert.ToInt32(id.ToString());
        }

        public static async Task<int> CreateDefaultInstructor(
            int sectionId,
            int exeterId)
        {
            List<ContentParameter> contentParameters = CreateInstructorEndpoint.GetCreateInstructorContentParameters(
                exeterId,
                new List<InstructorPermissions>()
                {
                    InstructorPermissions.SubmitFinalGrade
                });

            EndpointResult result = await new CreateInstructorEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN, sectionId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            if (!result.TransactionMetadata.Resource.TryGetValue("instructorId", out JsonValue id))
            {
                throw new MissingFieldException("The instructor id was not found on the returned resource!");
            }

            // return the identifier of the instructor entity that was created
            return Convert.ToInt32(id.ToString());
        }

        public static async Task<int> CreateDefaultCohort()
        {
            DateTime endDateUTC = DateTime.UtcNow;
            DateTime startDateUTC = endDateUTC.Subtract(TimeSpan.FromDays(7));

            List<ContentParameter> contentParameters = CreateCohortEndpoint.GetCreateCohortContentParameters(
                "Great Bananas",
                "February start of ruby students",
                startDateUTC,
                endDateUTC);

            EndpointResult result = await new CreateCohortEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            return RetrieveCohortIdFromCohortResource(result.TransactionMetadata.Resource);
        }

        public static int RetrieveExeterIdFromUserResource(JsonObject resource)
        {
            if (!resource.TryGetValue("exeterId", out JsonValue jsonValue))
            {
                throw new MissingFieldException("The user id was not found on the returned resource!");
            }

            return jsonValue;
        }

        public static List<IntegrationId> RetrieveIntegrationIdsFromUserResource(JsonObject resource)
        {
            if (resource.TryGetValue("integrationIds", out JsonValue jsonValue))
            {
                JsonArray jsonArray = jsonValue as JsonArray;

                if (jsonArray.Count == 0)
                {
                    throw new InvalidOperationException("No integration identifiers were returned with the user resource!");
                }

                List<IntegrationId> integrationIds = new List<IntegrationId>();

                foreach (JsonObject jsonObject in jsonArray)
                {
                    if (!jsonObject.TryGetValue("idType", out JsonValue idType))
                    {
                        throw new MissingFieldException("The integration id type was not found on the returned resource!");
                    }

                    if (!jsonObject.TryGetValue("idValue", out JsonValue idValue))
                    {
                        throw new MissingFieldException("The integration id value was not found on the returned resource!");
                    }

                    integrationIds.Add(new IntegrationId(
                        idType,
                        idValue));
                }

                return integrationIds;
            }
            else
            {
                throw new MissingFieldException("The integration ids were not found on the returned resource!");
            }
        }

        public static int RetrieveCohortIdFromCohortResource(JsonObject resource)
        {
            if (!resource.TryGetValue("cohortId", out JsonValue id))
            {
                throw new MissingFieldException("The cohort id was not found on the returned resource!");
            }

            return id;
        }

        public static async Task<UserMetadata> SearchForSingleUserByEmailAddress(string emailAddress)
        {
            List<QueryParameter> queryParameters = SearchUsersEndpoint.GetSearchUsersByEmailAddressQueryParameters(emailAddress);

            EndpointResult result = null;

            try
            {
                result = await new SearchUsersEndpoint(
                    Environment.BASE_URI,
                    Environment.AUTH_TOKEN).CallEndpoint(null, queryParameters).ConfigureAwait(false);
            }
            catch (AssertInconclusiveException)
            {
                // inconclusive exceptions are thrown when a user is not found
            }

            JsonArray jsonArray = result.ResponseBody as JsonArray;

            // ensure no more than one user was found
            if ((jsonArray?.Count ?? 0) > 1)
            {
                throw new InvalidOperationException($"More than one user account was discovered for e-mail address '{emailAddress}'.");
            }

            // load the user resource returned along with the transaction
            UserMetadata userData = null;

            if (result.StatusCode == HttpStatusCode.OK && jsonArray.Count == 1)
            {
                userData = UserMetadata.Load((JsonObject)jsonArray[0]);
            }

            return userData;
        }

        public static async Task<UserMetadata> CreateNewUser(UserMetadata newUserData)
        {
            List<ContentParameter> contentParameters = CreateUserEndpoint.GetCreateUserContentParameters(
                newUserData.FirstName,
                newUserData.LastName,
                newUserData.EmailAddress,
                newUserData.IntegrationIds);

            EndpointResult result = await new CreateUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

            return UserMetadata.Load(result.TransactionMetadata.Resource);
        }

        public static async Task<SectionMetadata> CreateNewSection(SectionMetadata newSectionData)
        {
            List<ContentParameter> contentParameters = CreateSectionEndpoint.GetCreateSectionContentParameters(
               newSectionData.CourseCode,
               newSectionData.StartDateUTC,
               newSectionData.EndDateUTC,
               newSectionData.MaxStudents,
               newSectionData.IsOpen,
               TimeZoneInfo.FindSystemTimeZoneById(newSectionData.TimeZone),
               SectionEnrollmentType.Traditional);

            EndpointResult result = await new CreateSectionEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

            return SectionMetadata.Load(result.TransactionMetadata.Resource);
        }

        public static async Task<CohortMetadata> CreateNewCohort(CohortMetadata newCohortData)
        {
            List<ContentParameter> contentParameters = CreateCohortEndpoint.GetCreateCohortContentParameters(
                newCohortData.Name,
                newCohortData.Description,
                newCohortData.StartDateUTC,
                newCohortData.EndDateUTC);

            EndpointResult result = await new CreateCohortEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

            return CohortMetadata.Load(result.TransactionMetadata.Resource);
        }

        public static async Task<FutureEnrollmentMetadata> CreateNewFutureEnrollment(
            string courseCode,
            int exeterId,
            DateTime sectionStartDateUTC)
        {
            List<ContentParameter> contentParameters = CreateFutureEnrollmentEndpoint.GetCreateFutureEnrollmentContentParameters(
                courseCode,
                exeterId,
                sectionStartDateUTC);

            EndpointResult result = await new CreateFutureEnrollmentEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsTrue(result?.TransactionMetadata != null);
            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

            Assert.IsTrue(result.TransactionMetadata.Resource.ContainsKey(FutureEnrollmentMetadata.FUTURE_ENROLLMENT_ID_FIELD));
            Assert.IsTrue(result.TransactionMetadata.Resource.ContainsKey(FutureEnrollmentMetadata.COURSE_CODE_FIELD));
            Assert.IsTrue(result.TransactionMetadata.Resource.ContainsKey(FutureEnrollmentMetadata.EXETER_ID_FIELD));
            Assert.IsTrue(result.TransactionMetadata.Resource.ContainsKey(FutureEnrollmentMetadata.SECTION_START_DATE_FIELD));

            // return the future enrollment metadata for the entity that was created
            return FutureEnrollmentMetadata.Load(result.TransactionMetadata.Resource);
        }

        public static async Task CreateNewCohortUser(
            int cohortId,
            int exeterId)
        {
            List<ContentParameter> contentParameters = CreateCohortUserEndpoint.GetCreateCohortUserContentParameters(exeterId);

            EndpointResult result = await new CreateCohortUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                cohortId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        public static async Task CreateNewEnrollment(int sectionId)
        {
            string integrationId = Guid.NewGuid().ToString();

            UserMetadata newUserMetadata = await TestHelpers.CreateNewUser(new UserMetadata()
            {
                FirstName = "Integration",
                LastName = "Test",
                EmailAddress = $"integration.test.{integrationId}@d.codercamps.com",
                IntegrationIds = new List<IntegrationId>()
                {
                    new IntegrationId(1, integrationId),
                    new IntegrationId(2, integrationId),
                },
            }).ConfigureAwait(false);

            await CreateNewEnrollment(
                sectionId,
                newUserMetadata.ExeterId,
                DateTime.UtcNow).ConfigureAwait(false);
        }

        public static async Task CreateNewEnrollment(
            int sectionId,
            int exeterId,
            DateTime enrollmentDateUTC)
        {
            List<ContentParameter> contentParameters = CreateEnrollmentEndpoint.GetCreateEnrollmentContentParameters(
                exeterId,
                enrollmentDateUTC);

            EndpointResult result = await new CreateEnrollmentEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                sectionId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        public static async Task CreateNewInstructor(
            int sectionId,
            int exeterId,
            List<InstructorPermissions> permissions)
        {
            List<ContentParameter> contentParameters = CreateInstructorEndpoint.GetCreateInstructorContentParameters(
                exeterId,
                permissions);

            EndpointResult result = await new CreateInstructorEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                sectionId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        public static async Task<AdvisorMetadata> CreateNewAdvisor(int exeterId)
        {
            List<ContentParameter> contentParameters = CreateAdvisorEndpoint.GetContentParameters(
                exeterId,
                new List<AdvisorRole> { AdvisorRole.Academic });

            EndpointResult result = await new CreateAdvisorEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);

            return AdvisorMetadata.Load(result.TransactionMetadata.Resource);
        }

        public static async Task<AdvisorAssignmentMetadata> CreateNewAdvisorAssignment(
            int advisorId,
            int studentExeterId)
        {
            DateTime utcNowDate = DateTime.UtcNow.Date;

            List<ContentParameter> contentParameters = CreateAdvisorAssignmentEndpoint.GetContentParameters(
                advisorId,
                studentExeterId,
                utcNowDate,
                AdvisorRole.Academic,
                utcNowDate);

            EndpointResult result = await new CreateAdvisorAssignmentEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);

            return AdvisorAssignmentMetadata.Load(result.TransactionMetadata.Resource);
        }

        public static async Task<AdvisorAssignmentMetadata> CreateNewUserAdvisorship(
            int advisorExeterId,
            int studentExeterId)
        {
            List<ContentParameter> contentParameters = CreateUserAdvisorshipByExeterIdEndpoint.GetContentParameters(
                studentExeterId,
                DateTime.UtcNow,
                AdvisorRole.Academic);

            EndpointResult result = await new CreateUserAdvisorshipByExeterIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                advisorExeterId)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);

            return AdvisorAssignmentMetadata.Load(result.TransactionMetadata.Resource);
        }
    }
}