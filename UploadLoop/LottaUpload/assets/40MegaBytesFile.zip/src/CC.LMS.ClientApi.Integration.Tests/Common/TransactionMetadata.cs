﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
// -- SBS ~ 20180123
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    using System.Json;

    public class TransactionMetadata
    {
        public string Id { get; }

        public TransactionStatus Status { get; }

        public string Message { get; }

        public JsonObject Resource { get; }

        public TransactionMetadata(string id, TransactionStatus status, string message, JsonObject resource)
        {
            this.Id = id;
            this.Status = status;
            this.Message = message;
            this.Resource = resource;
        }

        public void Deconstruct(out string id, out TransactionStatus status, out string message, out JsonObject resource)
        {
            id = this.Id;
            status = this.Status;
            message = this.Message;
            resource = this.Resource;
        }
    }
}