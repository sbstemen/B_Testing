﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    using System;
    using System.Collections.Generic;
    using System.Json;
    using Newtonsoft.Json.Linq;

    public class UserMetadata
    {
        private const string EXETER_ID_FIELD = "exeterId";
        private const string FIRST_NAME_FIELD = "firstName";
        private const string LAST_NAME_FIELD = "lastName";
        private const string EMAIL_ADDRESS_FIELD = "emailAddress";
        private const string INTEGRATION_IDS_FIELD = "integrationIds";
        private const string ORIGIN_FIELD = "origin";
        private const string CAMPAIGN_FIELD = "campaign";
        private const string COMMENTS_FIELD = "comments";

        public int ExeterId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string EmailAddress { get; set; }

        public OriginType Origin { get; set; }

        public string Campaign { get; set; }

        public string Comments { get; set; }

        public List<IntegrationId> IntegrationIds { get; set; }

        public static UserMetadata Load(JObject jsonObject)
        {
            return new UserMetadata()
            {
                ExeterId = jsonObject.TryGetValue(EXETER_ID_FIELD, out JToken exeterIdToken) ?
                    exeterIdToken.ToObject<int>() :
                    default(int),

                FirstName = jsonObject.TryGetValue(FIRST_NAME_FIELD, out JToken firstNameToken) ?
                    firstNameToken.ToObject<string>() :
                    throw new ArgumentNullException(nameof(FirstName)),

                LastName = jsonObject.TryGetValue(LAST_NAME_FIELD, out JToken lastNameToken) ?
                    lastNameToken.ToObject<string>() :
                    throw new ArgumentNullException(nameof(LastName)),

                EmailAddress = jsonObject.TryGetValue(EMAIL_ADDRESS_FIELD, out JToken emailAddressToken) ?
                    emailAddressToken.ToObject<string>() :
                    throw new ArgumentNullException(nameof(EmailAddress)),

                Origin = jsonObject.TryGetValue(ORIGIN_FIELD, out JToken originToken) ?
                    originToken.ToObject<OriginType>() :
                    throw new ArgumentNullException(nameof(Origin)),

                Campaign = jsonObject.TryGetValue(CAMPAIGN_FIELD, out JToken campaignToken) ?
                    campaignToken.ToObject<string>() :
                    throw new ArgumentNullException(nameof(Campaign)),

                Comments = jsonObject.TryGetValue(COMMENTS_FIELD, out JToken commentsToken) ?
                    commentsToken.ToObject<string>() :
                    throw new ArgumentNullException(nameof(Comments)),

                IntegrationIds = jsonObject.TryGetValue(INTEGRATION_IDS_FIELD, out JToken integrationIdsToken) ?
                    integrationIdsToken.ToObject<List<IntegrationId>>() :
                    null,
            };
        }

        public static UserMetadata Load(JsonObject jsonObject)
        {
            return new UserMetadata()
            {
                ExeterId = jsonObject.TryGetValue(EXETER_ID_FIELD, out JsonValue exeterIdValue) ?
                    (int)exeterIdValue :
                    default(int),

                FirstName = jsonObject.TryGetValue(FIRST_NAME_FIELD, out JsonValue firstNameValue) ?
                    firstNameValue :
                    throw new ArgumentNullException(nameof(FirstName)),

                LastName = jsonObject.TryGetValue(LAST_NAME_FIELD, out JsonValue lastNameValue) ?
                    lastNameValue :
                    throw new ArgumentNullException(nameof(LastName)),

                EmailAddress = jsonObject.TryGetValue(EMAIL_ADDRESS_FIELD, out JsonValue emailAddressValue) ?
                    emailAddressValue :
                    throw new ArgumentNullException(nameof(EmailAddress)),

                Origin = (OriginType)(jsonObject.TryGetValue(ORIGIN_FIELD, out JsonValue originValue) ?
                    (int)originValue :
                    throw new ArgumentNullException(nameof(Origin))),

                Campaign = jsonObject.TryGetValue(CAMPAIGN_FIELD, out JsonValue campaignValue) ?
                    campaignValue :
                    throw new ArgumentNullException(nameof(Campaign)),

                Comments = jsonObject.TryGetValue(COMMENTS_FIELD, out JsonValue commentsValue) ?
                    commentsValue :
                    throw new ArgumentNullException(nameof(Comments)),

                IntegrationIds = jsonObject.TryGetValue(INTEGRATION_IDS_FIELD, out JsonValue integrationIdsValue) ?
                    (integrationIdsValue as JsonArray).ToList<IntegrationId>() :
                    null,
            };
        }
    }
}
