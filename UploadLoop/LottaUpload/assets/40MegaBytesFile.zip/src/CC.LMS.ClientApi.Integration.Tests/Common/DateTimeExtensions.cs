﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    using System;

    public static class DateTimeExtensions
    {
        public static long EpochMilliseconds(this DateTime date)
        {
            return new DateTimeOffset(new DateTime(date.Ticks, DateTimeKind.Utc)).ToUnixTimeMilliseconds();
        }
    }
}
