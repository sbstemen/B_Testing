﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    using System;
    using System.Json;
    using Newtonsoft.Json.Linq;

    public class CohortMetadata
    {
        public int CohortId { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public DateTime StartDateUTC { get; set; }

        public DateTime EndDateUTC { get; set; }

        public static CohortMetadata Load(JObject jsonObject)
        {
            return new CohortMetadata()
            {
                CohortId = jsonObject.TryGetValue("cohortId", out JToken cohortIdToken) ?
                    cohortIdToken.ToObject<int>() :
                    default(int),

                Name = jsonObject.TryGetValue("name", out JToken nameToken) ?
                    nameToken.ToObject<string>() :
                    throw new ArgumentNullException(nameof(Name)),

                Description = jsonObject.TryGetValue("description", out JToken descriptionToken) ?
                    descriptionToken.ToObject<string>() :
                    throw new ArgumentNullException(nameof(Description)),

                StartDateUTC = jsonObject.TryGetValue("startDateUTC", out JToken startDateUTCToken) ?
                    startDateUTCToken.ToObject<DateTime>() :
                    throw new ArgumentNullException(nameof(StartDateUTC)),

                EndDateUTC = jsonObject.TryGetValue("endDateUTC", out JToken endDateUTCToken) ?
                    endDateUTCToken.ToObject<DateTime>() :
                    throw new ArgumentNullException(nameof(EndDateUTC)),
            };
        }

        public static CohortMetadata Load(JsonObject jsonObject)
        {
            return new CohortMetadata()
            {
                CohortId = jsonObject.TryGetValue("cohortId", out JsonValue cohortIdValue) ?
                    (int)cohortIdValue :
                    default(int),

                Name = jsonObject.TryGetValue("name", out JsonValue nameValue) ?
                    nameValue :
                    throw new ArgumentNullException(nameof(Name)),

                Description = jsonObject.TryGetValue("description", out JsonValue descriptionValue) ?
                    descriptionValue :
                    throw new ArgumentNullException(nameof(Description)),

                StartDateUTC = jsonObject.TryGetValue("startDateUTC", out JsonValue startDateUTCValue) ?
                    JsonUtilities.ToDateTime(startDateUTCValue) :
                    throw new ArgumentNullException(nameof(StartDateUTC)),

                EndDateUTC = jsonObject.TryGetValue("endDateUTC", out JsonValue endDateUTCValue) ?
                    JsonUtilities.ToDateTime(endDateUTCValue) :
                    throw new ArgumentNullException(nameof(EndDateUTC)),
            };
        }
    }
}
