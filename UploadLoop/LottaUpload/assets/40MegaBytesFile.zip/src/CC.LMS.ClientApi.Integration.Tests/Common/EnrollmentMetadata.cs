﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    using System;
    using System.Json;
    using Newtonsoft.Json.Linq;

    public class EnrollmentMetadata : UserMetadata
    {
        public DateTime EnrollmentDateUTC { get; set; }

        public EnrollmentMetadata(UserMetadata userData)
        {
            this.ExeterId = userData.ExeterId;
            this.FirstName = userData.FirstName;
            this.LastName = userData.LastName;
            this.EmailAddress = userData.EmailAddress;
            this.IntegrationIds = userData.IntegrationIds;
        }

        public static new EnrollmentMetadata Load(JObject jsonObject)
        {
            return new EnrollmentMetadata(UserMetadata.Load(jsonObject))
            {
                EnrollmentDateUTC = jsonObject.TryGetValue("enrollmentDateUTC", out JToken enrollmentDateUTCToken) ?
                    enrollmentDateUTCToken.ToObject<DateTime>() :
                    throw new ArgumentNullException(nameof(EnrollmentDateUTC)),
            };
        }

        public static new EnrollmentMetadata Load(JsonObject jsonObject)
        {
            return new EnrollmentMetadata(UserMetadata.Load(jsonObject))
            {
                EnrollmentDateUTC = jsonObject.TryGetValue("enrollmentDateUTC", out JsonValue enrollmentDateUTCValue) ?
                    JsonUtilities.ToDateTime(enrollmentDateUTCValue) :
                    throw new ArgumentNullException(nameof(EnrollmentDateUTC)),
            };
        }
    }
}
