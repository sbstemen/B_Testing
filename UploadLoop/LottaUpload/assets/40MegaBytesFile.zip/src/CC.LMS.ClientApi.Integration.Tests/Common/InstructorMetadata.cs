﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    using System;
    using System.Collections.Generic;
    using Newtonsoft.Json.Linq;

    public class InstructorMetadata : UserMetadata
    {
        public List<InstructorPermissions> Permissions { get; set; }

        public InstructorMetadata(UserMetadata userData)
        {
            this.ExeterId = userData.ExeterId;
            this.FirstName = userData.FirstName;
            this.LastName = userData.LastName;
            this.EmailAddress = userData.EmailAddress;
            this.IntegrationIds = userData.IntegrationIds;
        }

        public static new InstructorMetadata Load(JObject jsonObject)
        {
            return new InstructorMetadata(UserMetadata.Load(jsonObject))
            {
                Permissions = jsonObject.TryGetValue("permissions", out JToken permissionsToken) ?
                    permissionsToken.ToObject<List<InstructorPermissions>>() :
                    throw new ArgumentNullException(nameof(Permissions)),
            };
        }
    }
}
