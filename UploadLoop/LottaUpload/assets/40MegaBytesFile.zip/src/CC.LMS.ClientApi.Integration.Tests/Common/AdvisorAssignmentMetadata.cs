﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    using System;
    using System.Json;
    using Newtonsoft.Json.Linq;

    public class AdvisorAssignmentMetadata
    {
        private const string ADVISOR_ASSIGNMENT_ID_FIELD = "advisorAssignmentId";
        private const string ADVISOR_ID_FIELD = "advisorId";
        private const string STUDENT_EXETER_ID_FIELD = "studentExeterId";
        private const string CREATE_DATE_FIELD = "createDateUTC";
        private const string ASSIGNMENT_DATE_FIELD = "assignmentDateUTC";
        private const string ADVISOR_ROLE_FIELD = "advisorRole";
        private const string LAST_MEETING_DATE_FIELD = "lastMeetingDateUTC";

        public int AdvisorAssignmentId { get; set; }

        public int AdvisorId { get; set; }

        public int StudentExeterId { get; set; }

        public DateTime CreateDateUTC { get; set; }

        public DateTime AssignmentDateUTC { get; set; }

        public AdvisorRole AdvisorRole { get; set; }

        public DateTime? LastMeetingDateUTC { get; set; }

        public static AdvisorAssignmentMetadata Load(JObject jsonObject)
        {
            return new AdvisorAssignmentMetadata()
            {
                AdvisorAssignmentId = jsonObject.TryGetValue(ADVISOR_ASSIGNMENT_ID_FIELD, out JToken advisorAssignmentIdToken) ?
                    advisorAssignmentIdToken.ToObject<int>() :
                    throw new ArgumentNullException(nameof(AdvisorAssignmentId)),

                AdvisorId = jsonObject.TryGetValue(ADVISOR_ID_FIELD, out JToken advisorIdToken) ?
                    advisorIdToken.ToObject<int>() :
                    throw new ArgumentNullException(nameof(AdvisorId)),

                StudentExeterId = jsonObject.TryGetValue(STUDENT_EXETER_ID_FIELD, out JToken studentExeterIdToken) ?
                    studentExeterIdToken.ToObject<int>() :
                    throw new ArgumentNullException(nameof(StudentExeterId)),

                CreateDateUTC = jsonObject.TryGetValue(CREATE_DATE_FIELD, out JToken createDateUTCToken) ?
                    createDateUTCToken.ToObject<DateTime>() :
                    throw new ArgumentNullException(nameof(CreateDateUTC)),

                AssignmentDateUTC = jsonObject.TryGetValue(ASSIGNMENT_DATE_FIELD, out JToken assignmentDateUTCToken) ?
                    assignmentDateUTCToken.ToObject<DateTime>() :
                    throw new ArgumentNullException(nameof(AssignmentDateUTC)),

                AdvisorRole = jsonObject.TryGetValue(ADVISOR_ROLE_FIELD, out JToken advisorRoleToken) ?
                    advisorRoleToken.ToObject<AdvisorRole>() :
                    throw new ArgumentNullException(nameof(AdvisorRole)),

                LastMeetingDateUTC = jsonObject.TryGetValue(LAST_MEETING_DATE_FIELD, out JToken lastMeetingDateUTCToken) ?
                    lastMeetingDateUTCToken.ToObject<DateTime?>() :
                    throw new ArgumentNullException(nameof(LastMeetingDateUTC)),
            };
        }

        public static AdvisorAssignmentMetadata Load(JsonObject jsonObject)
        {
            return new AdvisorAssignmentMetadata()
            {
                AdvisorAssignmentId = jsonObject.TryGetValue(ADVISOR_ASSIGNMENT_ID_FIELD, out JsonValue advisorAssignmentValue) ?
                    (int)advisorAssignmentValue :
                    throw new ArgumentNullException(nameof(AdvisorId)),

                AdvisorId = jsonObject.TryGetValue(ADVISOR_ID_FIELD, out JsonValue advisorIdValue) ?
                    (int)advisorIdValue :
                    throw new ArgumentNullException(nameof(AdvisorId)),

                StudentExeterId = jsonObject.TryGetValue(STUDENT_EXETER_ID_FIELD, out JsonValue studentExeterIdValue) ?
                    (int)studentExeterIdValue :
                    throw new ArgumentNullException(nameof(StudentExeterId)),

                CreateDateUTC = jsonObject.TryGetValue(CREATE_DATE_FIELD, out JsonValue createDateUTCValue) ?
                    JsonUtilities.ToDateTime(createDateUTCValue) :
                    throw new ArgumentNullException(nameof(CreateDateUTC)),

                AssignmentDateUTC = jsonObject.TryGetValue(ASSIGNMENT_DATE_FIELD, out JsonValue assignmentDateUTCValue) ?
                    JsonUtilities.ToDateTime(assignmentDateUTCValue) :
                    throw new ArgumentNullException(nameof(AssignmentDateUTC)),

                AdvisorRole = jsonObject.TryGetValue(ADVISOR_ROLE_FIELD, out JsonValue advisorRoleValue) ?
                    (AdvisorRole)(int)advisorRoleValue :
                    throw new ArgumentNullException(nameof(AdvisorRole)),

                LastMeetingDateUTC = jsonObject.TryGetValue(LAST_MEETING_DATE_FIELD, out JsonValue lastMeetingDateUTCValue) ?
                    JsonUtilities.ToNullableDateTime(lastMeetingDateUTCValue) :
                    throw new ArgumentNullException(nameof(LastMeetingDateUTC)),
            };
        }
    }
}
