﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    public enum AdvisorRole
    {
        Unknown = 0,
        Admissions = 1 << 0,
        Academic = 1 << 1,
        Financial = 1 << 2,
        Instructional = 1 << 3
    }
}
