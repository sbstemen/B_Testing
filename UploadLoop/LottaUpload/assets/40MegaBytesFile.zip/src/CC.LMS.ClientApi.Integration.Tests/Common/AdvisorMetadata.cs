﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    using System;
    using System.Collections.Generic;
    using System.Json;
    using System.Linq;
    using Newtonsoft.Json.Linq;

    public class AdvisorMetadata
    {
        private const string ADVISOR_ID_FIELD = "advisorId";
        private const string ADVISOR_EXETER_ID_FIELD = "advisorExeterId";
        private const string ADVISOR_ROLES_FIELD = "advisorRoles";
        private const string CREATE_DATE_FIELD = "createDateUTC";

        public int AdvisorId { get; set; }

        public int AdvisorExeterId { get; set; }

        public List<AdvisorRole> AdvisorRoles { get; set; }

        public DateTime CreateDateUTC { get; set; }

        public static AdvisorMetadata Load(JObject jsonObject)
        {
            return new AdvisorMetadata()
            {
                AdvisorId = jsonObject.TryGetValue(ADVISOR_ID_FIELD, out JToken advisorIdToken) ?
                    advisorIdToken.ToObject<int>() :
                    throw new ArgumentNullException(nameof(AdvisorId)),

                AdvisorExeterId = jsonObject.TryGetValue(ADVISOR_EXETER_ID_FIELD, out JToken advisorExeterIdToken) ?
                    advisorExeterIdToken.ToObject<int>() :
                    throw new ArgumentNullException(nameof(AdvisorExeterId)),

                AdvisorRoles = jsonObject.TryGetValue(ADVISOR_ROLES_FIELD, out JToken advisorRolesToken) ?
                    advisorRolesToken.ToObject<List<AdvisorRole>>() :
                    throw new ArgumentNullException(nameof(AdvisorRoles)),

                CreateDateUTC = jsonObject.TryGetValue(CREATE_DATE_FIELD, out JToken createDateUTCToken) ?
                    createDateUTCToken.ToObject<DateTime>() :
                    throw new ArgumentNullException(nameof(CreateDateUTC)),
            };
        }

        public static AdvisorMetadata Load(JsonObject jsonObject)
        {
            return new AdvisorMetadata()
            {
                AdvisorId = jsonObject.TryGetValue(ADVISOR_ID_FIELD, out JsonValue firstNameValue) ?
                    (int)firstNameValue :
                    throw new ArgumentNullException(nameof(AdvisorId)),

                AdvisorExeterId = jsonObject.TryGetValue(ADVISOR_EXETER_ID_FIELD, out JsonValue advisorExeterIdValue) ?
                    (int)advisorExeterIdValue :
                    throw new ArgumentNullException(nameof(AdvisorExeterId)),

                AdvisorRoles = jsonObject.TryGetValue(ADVISOR_ROLES_FIELD, out JsonValue advisorRolesValue) ?
                    (advisorRolesValue as JsonArray).ToInt32List().Cast<AdvisorRole>().ToList() :
                    throw new ArgumentNullException(nameof(AdvisorRoles)),

                CreateDateUTC = jsonObject.TryGetValue(CREATE_DATE_FIELD, out JsonValue createDateUTCValue) ?
                    JsonUtilities.ToDateTime(createDateUTCValue) :
                    throw new ArgumentNullException(nameof(CreateDateUTC)),
            };
        }
    }
}
