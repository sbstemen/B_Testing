﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    /// <summary>
    /// The possible types of origin from which a request may be made.
    /// </summary>
    public enum OriginType
    {
        Platform = 0,
        Client = 1
    }
}
