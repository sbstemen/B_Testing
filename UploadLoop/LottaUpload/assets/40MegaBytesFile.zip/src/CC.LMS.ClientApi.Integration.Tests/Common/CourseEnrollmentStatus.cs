﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    public enum CourseEnrollmentStatus
    {
        Unknown = 0,
        Enrolled = 100,
        Graduated = 200,
        Incomplete = 300,
        Withdrawn = 400,
        WithdrawnWithFailure = 450,
        Canceled = 500,
    }
}
