﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    using System.Collections.Generic;

    public class UserIdSet
    {
        public int UserId { get; }

        public List<IntegrationId> IntegrationIds { get; }

        public UserIdSet(int userId, List<IntegrationId> integrationIds)
        {
            this.UserId = userId;
            this.IntegrationIds = integrationIds;
        }
    }
}
