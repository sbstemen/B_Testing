﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    public enum TransactionStatus
    {
        Default = 0,
        Scheduled = 100,
        Staged = 200,
        Processing = 300,
        Succeeded = 400,
        Failed = 500,
        Cancelled = 600,
        Expired = 700,
    }
}
