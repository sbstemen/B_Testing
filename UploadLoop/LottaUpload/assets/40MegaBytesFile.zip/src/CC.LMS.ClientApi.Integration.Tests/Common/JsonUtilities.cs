﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    using System;
    using System.Collections.Generic;
    using System.Json;

    public static class JsonUtilities
    {
        public static DateTime ToDateTime(JsonValue jsonValue)
        {
            return jsonValue.JsonType == JsonType.Number ?
                DateTimeOffset.FromUnixTimeMilliseconds(jsonValue).DateTime :
                (DateTime)jsonValue;
        }

        public static DateTime? ToNullableDateTime(JsonValue jsonValue)
        {
            DateTime? result;

            if (jsonValue == null)
            {
                result = null;
            }
            else if (jsonValue.JsonType == JsonType.Number)
            {
                result = new DateTime?(DateTimeOffset.FromUnixTimeMilliseconds(jsonValue).DateTime);
            }
            else
            {
                result = new DateTime?(jsonValue);
            }

            return result;
        }

        public static List<T> ToList<T>(this JsonArray jsonArray)
            where T : class
        {
            List<T> list = null;

            if (jsonArray != null)
            {
                list = new List<T>();

                foreach (JsonObject element in jsonArray)
                {
                    list.Add(element as T);
                }
            }

            return list;
        }

        public static List<int> ToInt32List(this JsonArray jsonArray)
        {
            List<int> list = null;

            if (jsonArray != null)
            {
                list = new List<int>();

                foreach (JsonValue element in jsonArray)
                {
                    list.Add(element);
                }
            }

            return list;
        }
    }
}
