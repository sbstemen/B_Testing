﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    using System;
    using System.Json;

    public class FutureEnrollmentMetadata
    {
        public const string FUTURE_ENROLLMENT_ID_FIELD = "futureEnrollmentId";
        public const string COURSE_CODE_FIELD = "courseCode";
        public const string EXETER_ID_FIELD = "exeterId";
        public const string SECTION_START_DATE_FIELD = "sectionStartDateUTC";

        public int FutureEnrollmentId { get; set; }

        public string CourseCode { get; set; }

        public int ExeterId { get; set; }

        public DateTime SectionStartDateUTC { get; set; }

        public static FutureEnrollmentMetadata Load(JsonObject jsonObject)
        {
            return new FutureEnrollmentMetadata()
            {
                FutureEnrollmentId = jsonObject.TryGetValue(
                    FUTURE_ENROLLMENT_ID_FIELD,
                    out JsonValue futureEnrollmentIdValue) ?
                        (int)futureEnrollmentIdValue :
                        default(int),

                CourseCode = jsonObject.TryGetValue(
                    COURSE_CODE_FIELD,
                    out JsonValue courseCodeValue) ?
                        (string)courseCodeValue :
                        default(string),

                ExeterId = jsonObject.TryGetValue(
                    EXETER_ID_FIELD,
                    out JsonValue exeterIdValue) ?
                        (int)exeterIdValue :
                        default(int),

                SectionStartDateUTC = jsonObject.TryGetValue(
                    SECTION_START_DATE_FIELD,
                    out JsonValue sectionStartDateValue) ?
                        JsonUtilities.ToDateTime(sectionStartDateValue) :
                        default(DateTime),
            };
        }
    }
}
