﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    using System;
    using System.Json;
    using Newtonsoft.Json.Linq;

    public class SectionMetadata
    {
        public static readonly int COMMENTS_MAX_LENGTH = 300;
        public static readonly string REGEX_ALPHANUMERIC_ONLY = "^[A-Za-z0-9, -.]*$";

        public int SectionId { get; set; }

        public string CourseCode { get; set; }

        public DateTime StartDateUTC { get; set; }

        public DateTime EndDateUTC { get; set; }

        public bool IsOpen { get; set; }

        public int MaxStudents { get; set; }

        public string TimeZone { get; set; }

        public OriginType Origin { get; set; }

        public SectionEnrollmentType EnrollmentType { get; set; }

        public string Comments { get; set; }

        public static SectionMetadata Load(JObject jsonObject)
        {
            return new SectionMetadata()
            {
                SectionId = jsonObject.TryGetValue("sectionId", out JToken sectionIdToken) ?
                    sectionIdToken.ToObject<int>() :
                    default(int),

                CourseCode = jsonObject.TryGetValue("courseCode", out JToken courseCodeToken) ?
                    courseCodeToken.ToObject<string>() :
                    throw new ArgumentNullException(nameof(CourseCode)),

                StartDateUTC = jsonObject.TryGetValue("startDateUTC", out JToken startDateUTCToken) ?
                    startDateUTCToken.ToObject<DateTime>() :
                    throw new ArgumentNullException(nameof(StartDateUTC)),

                EndDateUTC = jsonObject.TryGetValue("endDateUTC", out JToken endDateUTCToken) ?
                    endDateUTCToken.ToObject<DateTime>() :
                    throw new ArgumentNullException(nameof(EndDateUTC)),

                IsOpen = jsonObject.TryGetValue("isOpen", out JToken isOpenToken) ?
                    isOpenToken.ToObject<bool>() :
                    throw new ArgumentNullException(nameof(IsOpen)),

                MaxStudents = jsonObject.TryGetValue("maxStudents", out JToken maxStudentsToken) ?
                    maxStudentsToken.ToObject<int>() :
                    throw new ArgumentNullException(nameof(MaxStudents)),

                TimeZone = jsonObject.TryGetValue("timeZone", out JToken timeZoneToken) ?
                    timeZoneToken.ToObject<string>() :
                    throw new ArgumentNullException(nameof(TimeZone)),

                EnrollmentType = jsonObject.TryGetValue("enrollmentType", out JToken enrollmentTypeToken) ?
                    enrollmentTypeToken.ToObject<SectionEnrollmentType>() :
                    SectionEnrollmentType.Traditional,

                Origin = jsonObject.TryGetValue("origin", out JToken originToken) ?
                    originToken.ToObject<OriginType>() :
                    OriginType.Platform,

                Comments = jsonObject.TryGetValue("comments", out JToken commentsToken) ?
                    commentsToken.ToObject<string>() :
                    default(string),
            };
        }

        public static SectionMetadata Load(JsonObject jsonObject)
        {
            return new SectionMetadata()
            {
                SectionId = jsonObject.TryGetValue("sectionId", out JsonValue sectionIdValue) ?
                    (int)sectionIdValue :
                    default(int),

                CourseCode = jsonObject.TryGetValue("courseCode", out JsonValue courseCodeValue) ?
                    courseCodeValue :
                    throw new ArgumentNullException(nameof(CourseCode)),

                StartDateUTC = jsonObject.TryGetValue("startDateUTC", out JsonValue startDateUTCValue) ?
                    JsonUtilities.ToDateTime(startDateUTCValue) :
                    throw new ArgumentNullException(nameof(StartDateUTC)),

                EndDateUTC = jsonObject.TryGetValue("endDateUTC", out JsonValue endDateUTCValue) ?
                    JsonUtilities.ToDateTime(endDateUTCValue) :
                    throw new ArgumentNullException(nameof(EndDateUTC)),

                IsOpen = jsonObject.TryGetValue("isOpen", out JsonValue isOpenValue) ?
                    isOpenValue :
                    throw new ArgumentNullException(nameof(IsOpen)),

                MaxStudents = jsonObject.TryGetValue("maxStudents", out JsonValue maxStudentsValue) ?
                    maxStudentsValue :
                    throw new ArgumentNullException(nameof(MaxStudents)),

                TimeZone = jsonObject.TryGetValue("timeZone", out JsonValue timeZoneValue) ?
                    timeZoneValue :
                    throw new ArgumentNullException(nameof(TimeZone)),

                EnrollmentType = (SectionEnrollmentType)(jsonObject.TryGetValue("enrollmentType", out JsonValue enrollmentTypeValue) ?
                (int)enrollmentTypeValue :
                default(int)),

                Origin = (OriginType)(jsonObject.TryGetValue("origin", out JsonValue originValue) ?
                (int)originValue :
                default(int)),

                Comments = jsonObject.TryGetValue("comments", out JsonValue commentsValue) ?
                commentsValue :
                throw new ArgumentNullException(nameof(Comments)),
            };
        }
    }
}
