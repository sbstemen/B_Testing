﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    public class IntegrationId
    {
        public int idType { get; }

        public string idValue { get; }

        public IntegrationId(int idType, string idValue)
        {
            this.idType = idType;
            this.idValue = idValue;
        }
    }
}
