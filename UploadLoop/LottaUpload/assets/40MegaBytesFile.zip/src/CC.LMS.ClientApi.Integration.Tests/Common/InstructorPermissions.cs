﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests.Common
{
    public enum InstructorPermissions
    {
        View = 0,
        InitialGrade = 1,
        AlterGrade = 2,
        AlterTotalPoints = 4,
        AlterDates = 8,
        AlterFeedback = 16,
        SubmitFinalGrade = 32,
        Ownership = 64,
        ConfirmFinalGrade = 128,
        AlterFinalGrade = 256
    }
}
