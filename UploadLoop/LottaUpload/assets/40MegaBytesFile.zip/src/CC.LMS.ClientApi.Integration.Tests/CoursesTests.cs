﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests
{
    using System.Json;
    using System.Threading.Tasks;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Courses;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class CoursesTests
    {
        [ClassInitialize]
        public static void ClassInitialize(TestContext testContext)
        {
            if (!Environment.ENABLE_ENDPOINT_TESTS)
            {
                Assert.Inconclusive("Endpoint tests are currently disabled.  Endpoint tests may be enabled via the runsettings configuration.");
            }
        }

        [TestMethod]
        public async Task TestRetrieveAllCourses()
        {
            EndpointResult result = await new RetrieveAllCoursesEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN).CallEndpoint(null, null).ConfigureAwait(false);

            // verify that the response if valid JSON
            var json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);
        }

        [TestMethod]
        public async Task TestRetrieveCourseByCourseCode()
        {
            EndpointResult result = await new RetrieveCourseByCourseCodeEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN, "CFSG105").CallEndpoint(null, null).ConfigureAwait(false);

            JsonObject json = result.ResponseBody as JsonObject;

            Assert.IsTrue(json != null);
        }
    }
}
