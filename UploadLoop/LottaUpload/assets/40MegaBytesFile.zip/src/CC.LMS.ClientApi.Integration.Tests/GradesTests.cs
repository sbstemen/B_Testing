﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Json;
    using System.Threading.Tasks;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Grades;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class GradesTests
    {
        [ClassInitialize]
        public static void ClassInitialize(TestContext testContext)
        {
            if (!Environment.ENABLE_ENDPOINT_TESTS)
            {
                Assert.Inconclusive("Endpoint tests are currently disabled.  Endpoint tests may be enabled via the runsettings configuration.");
            }
        }

        [TestMethod]
        public async Task TestSearchGradesByCourseCodes()
        {
            List<ContentParameter> contentParameters = SearchGradesEndpoint.GetSearchGradesByCourseCodesContentParameters(new List<string>()
            {
                "DOW100",
            });

            EndpointResult result = await new SearchGradesEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            var json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No final grades were found when searching by course codes.");
            }
        }

        [TestMethod]
        public async Task TestSearchGradesByLetterGrades()
        {
            List<ContentParameter> contentParameters = SearchGradesEndpoint.GetSearchGradesByLetterGradesContentParameters(new List<string>()
            {
                "A",
                "B",
                "C",
            });

            EndpointResult result = await new SearchGradesEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            var json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No final grades were found when searching by letter grades.");
            }
        }

        [TestMethod]
        public async Task TestSearchGradesBySectionIds()
        {
            List<ContentParameter> contentParameters = SearchGradesEndpoint.GetSearchGradesBySectionIdsContentParameters(new List<int>()
            {
                41589,
            });

            EndpointResult result = await new SearchGradesEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            var json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No final grades were found when searching by section IDs.");
            }
        }

        [TestMethod]
        public async Task TestSearchGradesByIntegrationIds()
        {
            List<ContentParameter> contentParameters = SearchGradesEndpoint.GetSearchGradesByIntegrationIdsContentParameters(new List<IntegrationId>()
            {
                new IntegrationId(1, "1234567890"),
            });

            EndpointResult result = await new SearchGradesEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            var json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No final grades were found when searching by integration IDs.");
            }
        }

        [TestMethod]
        [ExpectedException(typeof(AssertInconclusiveException))]
        public async Task TestSearchGradesByIntegrationIdsNoResults()
        {
            List<ContentParameter> contentParameters = SearchGradesEndpoint.GetSearchGradesByIntegrationIdsContentParameters(new List<IntegrationId>()
            {
                new IntegrationId(1, $"DNE_{Guid.NewGuid().ToString()}"),
            });

            EndpointResult result = await new SearchGradesEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            var json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No final grades were found when searching by integration IDs.");
            }
        }

        [TestMethod]
        public async Task TestSearchGradesByExeterIds()
        {
            List<ContentParameter> contentParameters = SearchGradesEndpoint.GetSearchGradesByExeterIdsContentParameters(new List<int>()
            {
                430,
            });

            EndpointResult result = await new SearchGradesEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            var json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No final grades were found when searching by Exeter IDs.");
            }
        }
    }
}
