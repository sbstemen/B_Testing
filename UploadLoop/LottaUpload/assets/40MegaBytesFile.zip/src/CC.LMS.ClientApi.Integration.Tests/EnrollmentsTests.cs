﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Json;
    using System.Net;
    using System.Threading.Tasks;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Common.Exceptions;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Enrollments;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class EnrollmentsTests
    {
        public static DateTime DefaultSectionStartDateUtc = DateTime.UtcNow + TimeSpan.FromDays(5);

        public static UserIdSet DefaultUserIdSet { get; set; }

        public static FutureEnrollmentMetadata DefaultFutureEnrollment { get; set; }

        [ClassInitialize]
        public static async Task ClassInitialize(TestContext testContext)
        {
            if (!Environment.ENABLE_ENDPOINT_TESTS)
            {
                Assert.Inconclusive("Endpoint tests are currently disabled.  Endpoint tests may be enabled via the runsettings configuration.");
            }

            await Task.WhenAll(InitializeDefaultUser());
            await Task.WhenAll(InitializeDefaultFutureEnrollment(DefaultUserIdSet.UserId));
        }

        [TestMethod]
        public async Task TestCreateFutureEnrollment()
        {
            List<ContentParameter> contentParameters = CreateFutureEnrollmentEndpoint.GetCreateFutureEnrollmentContentParameters(
                "DOW100",
                DefaultUserIdSet.UserId,
                DateTime.UtcNow + TimeSpan.FromDays(3));

            EndpointResult result = await new CreateFutureEnrollmentEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsTrue(result?.TransactionMetadata != null);
            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

            Assert.IsTrue(result.TransactionMetadata.Resource.ContainsKey("futureEnrollmentId"));
            Assert.IsTrue(result.TransactionMetadata.Resource.ContainsKey("courseCode"));
            Assert.IsTrue(result.TransactionMetadata.Resource.ContainsKey("exeterId"));
            Assert.IsTrue(result.TransactionMetadata.Resource.ContainsKey("sectionStartDateUTC"));
        }

        [TestMethod]
        [ExpectedException(typeof(BadRequestException))]
        public async Task TestCreateFutureEnrollmentDuplicate()
        {
            List<ContentParameter> contentParameters = CreateFutureEnrollmentEndpoint.GetCreateFutureEnrollmentContentParameters(
                DefaultFutureEnrollment.CourseCode,
                DefaultFutureEnrollment.ExeterId,
                DefaultFutureEnrollment.SectionStartDateUTC);

            await new CreateFutureEnrollmentEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);
        }

        [TestMethod]
        [ExpectedException(typeof(BadRequestException))]
        public async Task TestCreateFutureEnrollmentAfterCutoffDate()
        {
            List<ContentParameter> contentParameters = CreateFutureEnrollmentEndpoint.GetCreateFutureEnrollmentContentParameters(
                "CFS105",
                DefaultUserIdSet.UserId,
                DateTime.UtcNow.Subtract(TimeSpan.FromDays(100)));

            await new CreateFutureEnrollmentEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);
        }

        [TestMethod]
        public async Task TestRetrieveFutureEnrollmentById()
        {
            Assert.IsTrue((DefaultFutureEnrollment?.FutureEnrollmentId ?? 0) > 0);

            EndpointResult result = await new RetrieveFutureEnrollmentByIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultFutureEnrollment.FutureEnrollmentId)
                .CallEndpoint(null, null)
                .ConfigureAwait(false);

            JsonObject json = result.ResponseBody as JsonObject;

            Assert.IsTrue(json != null);
        }

        [TestMethod]
        public async Task TestRetrieveFutureEnrollmentsByCourseCodeWithoutQueryParameters()
        {
            Assert.IsTrue(!string.IsNullOrWhiteSpace(DefaultFutureEnrollment?.CourseCode));

            EndpointResult result = await new RetrieveFutureEnrollmentsByCourseCodeEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultFutureEnrollment.CourseCode)
                .CallEndpoint(null, null)
                .ConfigureAwait(false);

            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue((json?.Count ?? 0) > 0);
        }

        [TestMethod]
        public async Task TestRetrieveFutureEnrollmentsByCourseCodeWithQueryParameters()
        {
            Assert.IsTrue(!string.IsNullOrWhiteSpace(DefaultFutureEnrollment?.CourseCode));
            Assert.IsTrue((DefaultFutureEnrollment?.ExeterId ?? 0) > 0);
            Assert.IsTrue((DefaultFutureEnrollment?.SectionStartDateUTC ?? default(DateTime)) != default(DateTime));

            List<QueryParameter> queryParameters = RetrieveFutureEnrollmentsByCourseCodeEndpoint.GetQueryParameters(
                DefaultFutureEnrollment.ExeterId,
                DefaultFutureEnrollment.SectionStartDateUTC);

            EndpointResult result = await new RetrieveFutureEnrollmentsByCourseCodeEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultFutureEnrollment.CourseCode)
                .CallEndpoint(null, queryParameters)
                .ConfigureAwait(false);

            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue((json?.Count ?? 0) > 0);
        }

        [TestMethod]
        public async Task TestRetrieveFutureEnrollmentsByExeterIdWithoutQueryParameters()
        {
            Assert.IsTrue((DefaultFutureEnrollment?.ExeterId ?? 0) > 0);

            EndpointResult result = await new RetrieveFutureEnrollmentsByExeterIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultFutureEnrollment.ExeterId)
                .CallEndpoint(null, null)
                .ConfigureAwait(false);

            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue((json?.Count ?? 0) > 0);
        }

        [TestMethod]
        public async Task TestRetrieveFutureEnrollmentsByExeterIdWithQueryParameters()
        {
            Assert.IsTrue((DefaultFutureEnrollment?.ExeterId ?? 0) > 0);
            Assert.IsTrue((DefaultFutureEnrollment?.SectionStartDateUTC ?? default(DateTime)) != default(DateTime));
            Assert.IsTrue(!string.IsNullOrWhiteSpace(DefaultFutureEnrollment?.CourseCode));

            List<QueryParameter> queryParameters = RetrieveFutureEnrollmentsByExeterIdEndpoint.GetQueryParameters(
                DefaultFutureEnrollment.CourseCode,
                DefaultFutureEnrollment.SectionStartDateUTC);

            EndpointResult result = await new RetrieveFutureEnrollmentsByExeterIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultFutureEnrollment.ExeterId)
                .CallEndpoint(null, queryParameters)
                .ConfigureAwait(false);

            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue((json?.Count ?? 0) > 0);
        }

        [TestMethod]
        public async Task TestRetrieveFutureEnrollmentsByDateWithoutQueryParameters()
        {
            Assert.IsTrue((DefaultFutureEnrollment?.SectionStartDateUTC ?? default(DateTime)) != default(DateTime));

            EndpointResult result = await new RetrieveFutureEnrollmentsBySectionStartDateEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultFutureEnrollment.SectionStartDateUTC.EpochMilliseconds())
                .CallEndpoint(null, null)
                .ConfigureAwait(false);

            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue((json?.Count ?? 0) > 0);
        }

        [TestMethod]
        public async Task TestRetrieveFutureEnrollmentsByDateWithQueryParameters()
        {
            Assert.IsTrue((DefaultFutureEnrollment?.SectionStartDateUTC ?? default(DateTime)) != default(DateTime));
            Assert.IsTrue(!string.IsNullOrWhiteSpace(DefaultFutureEnrollment?.CourseCode));
            Assert.IsTrue((DefaultFutureEnrollment?.ExeterId ?? 0) > 0);

            List<QueryParameter> queryParameters = RetrieveFutureEnrollmentsBySectionStartDateEndpoint.GetQueryParameters(
                DefaultFutureEnrollment.CourseCode,
                DefaultFutureEnrollment.ExeterId);

            EndpointResult result = await new RetrieveFutureEnrollmentsBySectionStartDateEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultFutureEnrollment.SectionStartDateUTC.EpochMilliseconds())
                .CallEndpoint(null, queryParameters)
                .ConfigureAwait(false);

            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue((json?.Count ?? 0) > 0);
        }

        [TestMethod]
        public async Task TestSearchEnrollmentProgressWithCourseCodes()
        {
            List<ContentParameter> contentParameters = SearchEnrollmentProgressEndpoint.GetContentParametersWithCourseCodes(new List<string>()
            {
                "SWD100",
            });

            EndpointResult result = await new SearchEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.ResponseBody);

            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsNotNull(json);

            Assert.IsTrue(json.Count >= 0);
        }

        [TestMethod]
        public async Task TestSearchEnrollmentProgressWithSectionIds()
        {
            List<ContentParameter> contentParameters = SearchEnrollmentProgressEndpoint.GetContentParametersWithSectionIds(new List<int>()
            {
                41000,
            });

            EndpointResult result = await new SearchEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.ResponseBody);

            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsNotNull(json);

            Assert.IsTrue(json.Count >= 0);
        }

        [TestMethod]
        public async Task TestSearchEnrollmentProgressWithEnrollmentStati()
        {
            List<ContentParameter> contentParameters = SearchEnrollmentProgressEndpoint.GetContentParametersWithEnrollmentStati(new List<CourseEnrollmentStatus>()
            {
                CourseEnrollmentStatus.Enrolled,
                CourseEnrollmentStatus.Graduated,
            });

            EndpointResult result = await new SearchEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.ResponseBody);

            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsNotNull(json);

            Assert.IsTrue(json.Count >= 0);
        }

        [TestMethod]
        public async Task TestSearchEnrollmentProgressWithSectionStartDateRange()
        {
            DateTime utcNow = DateTime.UtcNow;

            DateTimeRange pastYear = new DateTimeRange()
            {
                Start = utcNow - TimeSpan.FromDays(365),
                End = utcNow,
            };

            List<ContentParameter> contentParameters = SearchEnrollmentProgressEndpoint.GetContentParametersWithSectionStartDateRange(pastYear);

            EndpointResult result = await new SearchEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.ResponseBody);

            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsNotNull(json);

            Assert.IsTrue(json.Count >= 0);
        }

        [TestMethod]
        public async Task TestSearchEnrollmentProgressWithInvalidSectionStartDateRange()
        {
            DateTime utcNow = DateTime.UtcNow;
            DateTime start = utcNow - TimeSpan.FromDays(366);

            Console.WriteLine(start.ToString());

            // a date range may be at most 365 days
            DateTimeRange past366Days = new DateTimeRange()
            {
                Start = DateTime.MinValue,
                End = utcNow,
            };

            List<ContentParameter> contentParameters = SearchEnrollmentProgressEndpoint.GetContentParametersWithSectionStartDateRange(past366Days);

            EndpointResult result = await new SearchEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.BadRequest, result.StatusCode);
        }

        [TestMethod]
        public async Task TestSearchEnrollmentProgressWithEnrollmentDateRange()
        {
            DateTime utcNow = DateTime.UtcNow;

            DateTimeRange pastYear = new DateTimeRange()
            {
                Start = utcNow - TimeSpan.FromDays(365),
                End = utcNow,
            };

            List<ContentParameter> contentParameters = SearchEnrollmentProgressEndpoint.GetContentParametersWithEnrollmentDateRange(pastYear);

            EndpointResult result = await new SearchEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.ResponseBody);

            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsNotNull(json);

            Assert.IsTrue(json.Count >= 0);
        }

        [TestMethod]
        public async Task TestSearchEnrollmentProgressWithInvalidEnrollmentDateRange()
        {
            DateTime utcNow = DateTime.UtcNow;
            DateTime start = utcNow - TimeSpan.FromDays(366);

            Console.WriteLine(start.ToString());

            // a date range may be at most 365 days
            DateTimeRange past366Days = new DateTimeRange()
            {
                Start = DateTime.MinValue,
                End = utcNow,
            };

            List<ContentParameter> contentParameters = SearchEnrollmentProgressEndpoint.GetContentParametersWithEnrollmentDateRange(past366Days);

            EndpointResult result = await new SearchEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.BadRequest, result.StatusCode);
        }

        private static async Task InitializeDefaultUser()
        {
            DefaultUserIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);
        }

        private static async Task InitializeDefaultFutureEnrollment(int userId)
        {
            DefaultFutureEnrollment = await TestHelpers.CreateNewFutureEnrollment(
                "SWD100",
                DefaultUserIdSet.UserId,
                DefaultSectionStartDateUtc).ConfigureAwait(false);
        }
    }
}
