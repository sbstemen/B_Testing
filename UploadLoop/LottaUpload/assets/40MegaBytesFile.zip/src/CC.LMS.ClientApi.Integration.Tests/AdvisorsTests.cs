﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-19
// Project:      CC.LMS.ClientApi.Integration.Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Json;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Advisors;

    [TestClass]
    public class AdvisorsTests
    {
        private static UserIdSet DefaultAdvisorUserIdSet { get; set; }

        private static UserIdSet DefaultStudentUserIdSet { get; set; }

        private static AdvisorMetadata DefaultAdvisor { get; set; }

        private static AdvisorAssignmentMetadata DefaultAdvisorAssignment { get; set; }

        [ClassInitialize]
        public static async Task InitializeClass(TestContext testContext)
        {
            if (!Environment.ENABLE_ENDPOINT_TESTS)
            {
                Assert.Inconclusive("Endpoint tests are currently disabled.  Endpoint tests may be enabled via the runsettings configuration.");
            }

            await Task.WhenAll(
                InitializeDefaultAdvisorUser(),
                InitializeDefaultStudentUser());
            await Task.WhenAll(InitializeDefaultAdvisor(DefaultAdvisorUserIdSet.UserId));
            await Task.WhenAll(InitializeDefaultAdvisorAssignment(
                DefaultAdvisor.AdvisorId,
                DefaultStudentUserIdSet.UserId));
        }

        [TestMethod]
        public async Task TestCreateAdvisor()
        {
            UserIdSet userIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);

            List<ContentParameter> contentParameters = CreateAdvisorEndpoint.GetContentParameters(
                userIdSet.UserId,
                new List<AdvisorRole> { AdvisorRole.Academic });

            EndpointResult result = await new CreateAdvisorEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);
        }

        [TestMethod]
        public async Task TestUpdateAdvisor()
        {
            List<ContentParameter> contentParameters = UpdateAdvisorEndpoint.GetContentParameters(new List<AdvisorRole>()
            {
                AdvisorRole.Instructional,
                AdvisorRole.Financial,
            });

            EndpointResult result = await new UpdateAdvisorEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultAdvisor.AdvisorId)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);

            AdvisorMetadata advisorMetadata = AdvisorMetadata.Load(result.TransactionMetadata.Resource);

            Assert.AreEqual(2, advisorMetadata.AdvisorRoles.Count);
            Assert.IsTrue(advisorMetadata.AdvisorRoles.Contains(AdvisorRole.Instructional));
            Assert.IsTrue(advisorMetadata.AdvisorRoles.Contains(AdvisorRole.Financial));
        }

        [TestMethod]
        public async Task TestCreateAdvisorAssignment()
        {
            AdvisorRole vacantRole = Enum.GetValues(typeof(AdvisorRole))
                .Cast<AdvisorRole>()
                .Where(x => x != DefaultAdvisorAssignment.AdvisorRole && x != AdvisorRole.Unknown)
                .First();

            List <ContentParameter> contentParameters = CreateAdvisorAssignmentEndpoint.GetContentParameters(
                DefaultAdvisorAssignment.AdvisorId,
                DefaultAdvisorAssignment.StudentExeterId,
                DateTime.UtcNow,
                vacantRole);

            EndpointResult result = await new CreateAdvisorAssignmentEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);

            AdvisorAssignmentMetadata advisorAssignmentMetadata = AdvisorAssignmentMetadata.Load(result.TransactionMetadata.Resource);

            // test that a new advisor assignment was created
            Assert.IsNotNull(advisorAssignmentMetadata);
            Assert.IsTrue(advisorAssignmentMetadata.AdvisorAssignmentId > 0);
            Assert.AreNotEqual(DefaultAdvisorAssignment.AdvisorAssignmentId, advisorAssignmentMetadata.AdvisorAssignmentId);
            Assert.AreEqual(DefaultAdvisorAssignment.AdvisorId, advisorAssignmentMetadata.AdvisorId);
            Assert.AreEqual(DefaultAdvisorAssignment.StudentExeterId, advisorAssignmentMetadata.StudentExeterId);
            Assert.AreEqual(vacantRole, advisorAssignmentMetadata.AdvisorRole);
        }

        [TestMethod]
        public async Task TestCreateAdvisorAssignmentAlreadyExists()
        {
            List<ContentParameter> contentParameters = CreateAdvisorAssignmentEndpoint.GetContentParameters(
                DefaultAdvisorAssignment.AdvisorId,
                DefaultAdvisorAssignment.StudentExeterId,
                DefaultAdvisorAssignment.AssignmentDateUTC,
                DefaultAdvisorAssignment.AdvisorRole);

            EndpointResult result = await new CreateAdvisorAssignmentEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);

            AdvisorAssignmentMetadata advisorAssignmentMetadata = AdvisorAssignmentMetadata.Load(result.TransactionMetadata.Resource);

            // test that a new advisor assignment was not created
            Assert.IsNotNull(advisorAssignmentMetadata);
            Assert.AreEqual(DefaultAdvisorAssignment.AdvisorAssignmentId, advisorAssignmentMetadata.AdvisorAssignmentId);
            Assert.AreEqual(DefaultAdvisorAssignment.AdvisorId, advisorAssignmentMetadata.AdvisorId);
            Assert.AreEqual(DefaultAdvisorAssignment.StudentExeterId, advisorAssignmentMetadata.StudentExeterId);
            Assert.AreEqual(DefaultAdvisorAssignment.AdvisorRole, advisorAssignmentMetadata.AdvisorRole);
        }

        [TestMethod]
        public async Task TestUpdateAdvisorAssignment()
        {
            DateTime utcNowPlusFiveDays = DateTime.UtcNow + TimeSpan.FromDays(5);

            List<ContentParameter> contentParameters = UpdateAdvisorAssignmentEndpoint.GetContentParameters(utcNowPlusFiveDays);

            EndpointResult result = await new UpdateAdvisorAssignmentEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultAdvisorAssignment.AdvisorAssignmentId)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);

            AdvisorAssignmentMetadata advisorAssignmentMetadata = AdvisorAssignmentMetadata.Load(result.TransactionMetadata.Resource);

            Assert.IsNotNull(advisorAssignmentMetadata);
            Assert.AreEqual(DefaultAdvisorAssignment.AdvisorId, advisorAssignmentMetadata.AdvisorId);
            Assert.AreEqual(DefaultAdvisorAssignment.AdvisorAssignmentId, advisorAssignmentMetadata.AdvisorAssignmentId);
            Assert.IsTrue(advisorAssignmentMetadata.LastMeetingDateUTC.HasValue);
            Assert.AreEqual(utcNowPlusFiveDays.Date, advisorAssignmentMetadata.LastMeetingDateUTC.Value.Date);
        }

        [TestMethod]
        public async Task TestRetrieveAdvisorById()
        {
            EndpointResult result = await new RetrieveAdvisorByIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultAdvisor.AdvisorId)
                .CallEndpoint(null, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.ResponseBody as JsonObject);

            AdvisorMetadata advisorMetadata = AdvisorMetadata.Load(result.ResponseBody as JsonObject);

            Assert.AreEqual(DefaultAdvisor.AdvisorId, advisorMetadata.AdvisorId);
        }

        [TestMethod]
        public async Task TestRetrieveAllAdvisors()
        {
            EndpointResult result = await new RetrieveAllAdvisorsEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(null, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.ResponseBody as JsonArray);

            JsonArray jsonArray = result.ResponseBody as JsonArray;

            if (jsonArray.Count == 0)
            {
                Assert.Inconclusive("No advisors were returned.");
            }
            else
            {
                Assert.IsTrue(jsonArray
                    .Select(x => AdvisorMetadata.Load(x as JsonObject))
                    .All(x => x.AdvisorId > 0));
            }
        }

        [TestMethod]
        public async Task TestRetrieveAdvisorAssignmentById()
        {
            EndpointResult result = await new RetrieveAdvisorAssignmentByIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultAdvisorAssignment.AdvisorAssignmentId)
                .CallEndpoint(null, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.ResponseBody as JsonObject);

            AdvisorAssignmentMetadata advisorAssignmentMetadata = AdvisorAssignmentMetadata.Load(result.ResponseBody as JsonObject);

            Assert.AreEqual(DefaultAdvisorAssignment.AdvisorAssignmentId, advisorAssignmentMetadata.AdvisorAssignmentId);
        }

        [TestMethod]
        public async Task TestRetrieveAdvisorAssignmentsByAdvisorId()
        {
            EndpointResult result = await new RetrieveAdvisorAssignmentsByAdvisorIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultAdvisor.AdvisorId)
                .CallEndpoint(null, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.ResponseBody as JsonArray);

            JsonArray jsonArray = result.ResponseBody as JsonArray;

            if (jsonArray.Count == 0)
            {
                Assert.Inconclusive("No advisor assignments were returned.");
            }
            else
            {
                Assert.IsTrue(jsonArray
                    .Select(x => AdvisorAssignmentMetadata.Load(x as JsonObject))
                    .All(x => x.AdvisorAssignmentId > 0 && x.AdvisorId == DefaultAdvisor.AdvisorId));
            }
        }

        [TestMethod]
        public async Task RetrieveAllAdvisorAssignments()
        {
            EndpointResult result = await new RetrieveAllAdvisorAssignmentsEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(null, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.ResponseBody as JsonArray);

            JsonArray jsonArray = result.ResponseBody as JsonArray;

            if (jsonArray.Count == 0)
            {
                Assert.Inconclusive("No advisor assignments were returned.");
            }
            else
            {
                Assert.IsTrue(jsonArray
                    .Select(x => AdvisorAssignmentMetadata.Load(x as JsonObject))
                    .All(x => x.AdvisorAssignmentId > 0));
            }
        }

        private static async Task InitializeDefaultAdvisorUser()
        {
            DefaultAdvisorUserIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);
        }

        private static async Task InitializeDefaultStudentUser()
        {
            DefaultStudentUserIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);
        }

        private static async Task InitializeDefaultAdvisor(int exeterId)
        {
            DefaultAdvisor = await TestHelpers
                .CreateNewAdvisor(exeterId)
                .ConfigureAwait(false);
        }

        private static async Task InitializeDefaultAdvisorAssignment(
            int advisorId,
            int studentExeterId)
        {
            DefaultAdvisorAssignment = await TestHelpers
                .CreateNewAdvisorAssignment(
                    advisorId,
                    studentExeterId)
                .ConfigureAwait(false);
        }
    }
}
