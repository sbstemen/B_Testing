﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Cohorts;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Users;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class LoadTests
    {
        [ClassInitialize]
        public static void ClassInitialize(TestContext testContext)
        {
            if (!Environment.ENABLE_LOAD_TESTS)
            {
                Assert.Inconclusive("Load tests are currently disabled.  Load tests may be enabled via the runsettings configuration.");
            }
        }

        [TestMethod]
        public async Task LoadTestCreateCohortUsers()
        {
            string testSignature = Guid.NewGuid().ToString();

            // create a single cohort
            DateTime currentTimeUTC = DateTime.UtcNow;
            string cohortName = $"Integration Load Test Cohort - {nameof(LoadTestCreateCohortUsers)}";
            string cohortDescription = $"[{testSignature}] This cohort was created for the {nameof(LoadTestCreateCohortUsers)} Client API integration test.  The test will attempt to create and add {Environment.NUM_REQUESTS_PER_LOAD_TEST} users to this cohort as part of the test (Current time: {currentTimeUTC.ToString()} (UTC)).";

            List<ContentParameter> cohortContentParameters = CreateCohortEndpoint.GetCreateCohortContentParameters(
                cohortName,
                cohortDescription,
                currentTimeUTC.Subtract(TimeSpan.FromDays(1)),
                currentTimeUTC.Add(TimeSpan.FromDays(1)));

            EndpointResult createCohortResult = await new CreateCohortEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(cohortContentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(createCohortResult.TransactionMetadata.Status == TransactionStatus.Succeeded);

            int cohortId = TestHelpers.RetrieveCohortIdFromCohortResource(createCohortResult.TransactionMetadata.Resource);

            Console.WriteLine($"Created cohort '{cohortName}' (Cohort ID = {cohortId}).");

            // define the thread pool callback
            bool[] createCohortUserCallbackSucceeded = new bool[Environment.NUM_REQUESTS_PER_LOAD_TEST];
            Exception[] createCohortUserCallbackExceptions = new Exception[Environment.NUM_REQUESTS_PER_LOAD_TEST];

            async void CreateCohortUserCallback(object state)
            {
                WaitCallbackArguments args = state as WaitCallbackArguments;

                try
                {
                    createCohortUserCallbackSucceeded[args.CallbackNumber] = true;
                    createCohortUserCallbackExceptions[args.CallbackNumber] = null;

                    // create user
                    string guid = Guid.NewGuid().ToString();

                    string firstName = $"IntegrationLoadTestUser_{args.CallbackNumber}";
                    string lastName = $"{nameof(LoadTestCreateCohortUsers)}_{testSignature}";
                    string personalId = $"{firstName}.{lastName}.{guid}";

                    List<ContentParameter> userContentParameters = CreateUserEndpoint.GetCreateUserContentParameters(
                        firstName,
                        lastName,
                        $"{personalId}@d.codercamps.com");

                    EndpointResult createUserResult = await new CreateUserEndpoint(
                        Environment.BASE_URI,
                        Environment.AUTH_TOKEN).CallEndpoint(userContentParameters, null).ConfigureAwait(false);

                    if (createUserResult.TransactionMetadata.Status != TransactionStatus.Succeeded)
                    {
                        createCohortUserCallbackSucceeded[args.CallbackNumber] = false;

                        return;
                    }

                    int exeterId = TestHelpers.RetrieveExeterIdFromUserResource(createUserResult.TransactionMetadata.Resource);

                    Console.WriteLine($"Created user '{firstName} {lastName}'.");

                    // create cohort user
                    List<ContentParameter> cohortUserContentParameter = CreateCohortUserEndpoint.GetCreateCohortUserContentParameters(exeterId);

                    EndpointResult createCohortUserResult = await new CreateCohortUserEndpoint(
                        Environment.BASE_URI,
                        Environment.AUTH_TOKEN,
                        cohortId).CallEndpoint(cohortUserContentParameter, null).ConfigureAwait(false);

                    if (createUserResult.TransactionMetadata.Status != TransactionStatus.Succeeded)
                    {
                        createCohortUserCallbackSucceeded[args.CallbackNumber] = false;

                        return;
                    }

                    Console.WriteLine($"Created cohort user '{firstName} {lastName}'.");
                }
                catch (Exception e)
                {
                    createCohortUserCallbackExceptions[args.CallbackNumber] = e;
                    createCohortUserCallbackSucceeded[args.CallbackNumber] = false;
                }
                finally
                {
                    args.CountdownEvent.Signal();
                }
            }

            // create cohort users on the thread pool
            this.ExecuteThreadPoolWork(CreateCohortUserCallback);

            // inspect the result of each callback
            if (createCohortUserCallbackExceptions.Any(x => x != null))
            {
                throw new AggregateException(createCohortUserCallbackExceptions.Where(x => x != null));
            }

            Assert.IsTrue(createCohortUserCallbackSucceeded.All(x => x));
        }

        private void ExecuteThreadPoolWork(WaitCallback waitCallbackDelegate)
        {
            // schedule the work on the thread pool
            using (CountdownEvent countdownEvent = new CountdownEvent(1))
            {
                // invoke the callback the specified number of times
                for (int i = 0; i < Environment.NUM_REQUESTS_PER_LOAD_TEST; i++)
                {
                    countdownEvent.AddCount();

                    // queue the work item on the thread pool
                    ThreadPool.QueueUserWorkItem(
                        waitCallbackDelegate,
                        new WaitCallbackArguments(i, countdownEvent));
                }

                // wait for all operations to complete
                countdownEvent.Signal();
                countdownEvent.Wait();
            }
        }

        private class WaitCallbackArguments
        {
            public int CallbackNumber { get; }

            public CountdownEvent CountdownEvent { get; }

            public WaitCallbackArguments(int callbackNumber, CountdownEvent countdownEvent)
            {
                this.CallbackNumber = callbackNumber;
                this.CountdownEvent = countdownEvent;
            }
        }
    }
}
