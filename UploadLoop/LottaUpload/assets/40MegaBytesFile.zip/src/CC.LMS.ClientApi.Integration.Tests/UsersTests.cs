﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Json;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Users;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class UsersTests
    {
        private static UserIdSet DefaultUserIdSet { get; set; }

        private static UserIdSet DefaultAdvisorUserIdSet { get; set; }

        private static UserIdSet DefaultStudentUserIdSet { get; set; }

        private static AdvisorAssignmentMetadata DefaultUserAdvisorship { get; set; }

        private static IntegrationId DefaultIntegrationId { get; set; }

        [ClassInitialize]
        public static async Task ClassInitialize(TestContext testContext)
        {
            if (!Environment.ENABLE_ENDPOINT_TESTS)
            {
                Assert.Inconclusive("Endpoint tests are currently disabled.  Endpoint tests may be enabled via the runsettings configuration.");
            }

            await Task.WhenAll(
                InitializeDefaultUser(),
                InitializeDefaultUserAdvisorship());
        }

        [TestMethod]
        public async Task TestCreateUserWithoutIntegrationIdsAndWithEmail()
        {
            int number1 = new Random().Next(0, 9999);
            int number2 = new Random().Next(0, 9999);
            string guid = Guid.NewGuid().ToString();

            string firstName = $"Integration_{number1}";
            string lastName = $"Test_{number2}";
            string personalId = $"{firstName}.{lastName}.{guid}";

            List<ContentParameter> contentParameters = CreateUserEndpoint.GetCreateUserContentParameters(
                firstName,
                lastName,
                $"{personalId}@d.codercamps.com",
                false);

            EndpointResult result = await new CreateUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestCreateUserWithNullIntegrationIds()
        {
            int number1 = new Random().Next(0, 9999);
            int number2 = new Random().Next(0, 9999);
            string guid = Guid.NewGuid().ToString();

            string firstName = $"Integration_{number1}";
            string lastName = $"Test_{number2}";
            string personalId = $"{firstName}.{lastName}.{guid}";

            List<ContentParameter> contentParameters = CreateUserEndpoint.GetCreateUserContentParameters(
                firstName,
                lastName,
                $"{personalId}@d.codercamps.com",
                null);

            EndpointResult result = await new CreateUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestCreateUserWithIntegrationIds()
        {
            int number1 = new Random().Next(0, 9999);
            int number2 = new Random().Next(0, 9999);
            string guid = Guid.NewGuid().ToString();

            string firstName = $"Integration_{number1}";
            string lastName = $"Test_{number2}";
            string personalId = $"{firstName}.{lastName}.{guid}";

            List<ContentParameter> contentParameters = CreateUserEndpoint.GetCreateUserContentParameters(
                firstName,
                lastName,
                $"{personalId}@d.codercamps.com",
                new List<IntegrationId>()
                {
                    new IntegrationId(1, $"{guid}.{lastName}.{firstName}"),
                    new IntegrationId(2, $"{guid}.{lastName}.{firstName}"),
                });

            EndpointResult result = await new CreateUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestCreateUserAcceptToSAndSuppressEmail()
        {
            int number1 = new Random().Next(0, 9999);
            int number2 = new Random().Next(0, 9999);
            string guid = Guid.NewGuid().ToString();

            string firstName = $"Integration_{number1}";
            string lastName = $"Test_{number2}";
            string personalId = $"{firstName}.{lastName}.{guid}";
            string emailAddress = $"{personalId}@d.codercamps.com";
            int acceptedToSDocumentId = 456455;
            bool suppressRegistrationEmail = true;

            List<ContentParameter> contentParameters = CreateUserEndpoint.GetCreateUserContentParameters(
                firstName,
                lastName,
                emailAddress,
                null,
                acceptedToSDocumentId,
                suppressRegistrationEmail);

            EndpointResult result = await new CreateUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

            JsonObject transactionResource = result.TransactionMetadata.Resource;

            Assert.IsTrue(transactionResource.ContainsKey("invitationCode"));
            Assert.IsTrue(transactionResource.ContainsKey("registrationUrl"));
        }

        [TestMethod]
        public async Task TestCreateUserWithOriginCampaignComments()
        {
            // build the request
            int number1 = new Random().Next(0, 9999);
            int number2 = new Random().Next(0, 9999);
            string guid = Guid.NewGuid().ToString();

            string firstName = $"Integration_{number1}";
            string lastName = $"Test_{number2}";
            string personalId = $"{firstName}.{lastName}.{guid}";
            string emailAddress = $"{personalId}@d.codercamps.com";
            OriginType origin = OriginType.Platform;
            string campaign = "western front";
            string comments = "can't stop, won't stop";

            List<ContentParameter> contentParameters = CreateUserEndpoint.GetContentParametersWithOriginCampaignComments(
                firstName,
                lastName,
                emailAddress,
                origin,
                campaign,
                comments);

            // call the endpoint
            EndpointResult result = await new CreateUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result?.TransactionMetadata);
            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
            Assert.IsNotNull(result?.TransactionMetadata?.Resource);

            // deserialize the results
            UserMetadata userMetadata = UserMetadata.Load(result.TransactionMetadata.Resource);

            // verify origin is client
            Assert.AreEqual(OriginType.Client, userMetadata.Origin);

            // verify campaign and comments are as provided
            Assert.AreEqual(campaign, userMetadata.Campaign);
            Assert.AreEqual(comments, userMetadata.Comments);
        }

        [TestMethod]
        public async Task TestCreateUserWithCampaignComments()
        {
            // build the request
            int number1 = new Random().Next(0, 9999);
            int number2 = new Random().Next(0, 9999);
            string guid = Guid.NewGuid().ToString();

            string firstName = $"Integration_{number1}";
            string lastName = $"Test_{number2}";
            string personalId = $"{firstName}.{lastName}.{guid}";
            string emailAddress = $"{personalId}@d.codercamps.com";
            string campaign = "western front";
            string comments = "can't stop, won't stop";

            List<ContentParameter> contentParameters = CreateUserEndpoint.GetContentParametersWithCampaignComments(
                firstName,
                lastName,
                emailAddress,
                campaign,
                comments);

            // call the endpoint
            EndpointResult result = await new CreateUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result?.TransactionMetadata);
            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
            Assert.IsNotNull(result?.TransactionMetadata?.Resource);

            // deserialize the results
            UserMetadata userMetadata = UserMetadata.Load(result.TransactionMetadata.Resource);

            // verify origin is client
            Assert.AreEqual(OriginType.Client, userMetadata.Origin);

            // verify campaign and comments are as provided
            Assert.AreEqual(campaign, userMetadata.Campaign);
            Assert.AreEqual(comments, userMetadata.Comments);
        }

        [TestMethod]
        public async Task TestCreateUserCampaignTooLong()
        {
            // build the request
            int number1 = new Random().Next(0, 9999);
            int number2 = new Random().Next(0, 9999);
            string guid = Guid.NewGuid().ToString();

            string firstName = $"Integration_{number1}";
            string lastName = $"Test_{number2}";
            string personalId = $"{firstName}.{lastName}.{guid}";
            string emailAddress = $"{personalId}@d.codercamps.com";

            // max campaign length is 50 characters
            string campaign = "tententen!tententen!tententen!tententen!tententen!tententen!";
            string comments = "can't stop, won't stop";

            List<ContentParameter> contentParameters = CreateUserEndpoint.GetContentParametersWithCampaignComments(
                firstName,
                lastName,
                emailAddress,
                campaign,
                comments);

            // call the endpoint
            EndpointResult result = await new CreateUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null, false)
                .ConfigureAwait(false);

            // ensure that the server returned a bad request response
            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.BadRequest, result.StatusCode);
        }

        [TestMethod]
        public async Task TestCreateUserCommentsTooLong()
        {
            // build the request
            int number1 = new Random().Next(0, 9999);
            int number2 = new Random().Next(0, 9999);
            string guid = Guid.NewGuid().ToString();

            string firstName = $"Integration_{number1}";
            string lastName = $"Test_{number2}";
            string personalId = $"{firstName}.{lastName}.{guid}";
            string emailAddress = $"{personalId}@d.codercamps.com";
            string campaign = "western front";

            // max comments length is 300 characters
            string comments = "twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!twentytwentytwenty!!";

            List<ContentParameter> contentParameters = CreateUserEndpoint.GetContentParametersWithCampaignComments(
                firstName,
                lastName,
                emailAddress,
                campaign,
                comments);

            // call the endpoint
            EndpointResult result = await new CreateUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null, false)
                .ConfigureAwait(false);

            // ensure that the server returned a bad request response
            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.BadRequest, result.StatusCode);
        }

        [TestMethod]
        public async Task TestCreateUserCampaignWithInvalidCharacters()
        {
            // build the request
            int number1 = new Random().Next(0, 9999);
            int number2 = new Random().Next(0, 9999);
            string guid = Guid.NewGuid().ToString();

            string firstName = $"Integration_{number1}";
            string lastName = $"Test_{number2}";
            string personalId = $"{firstName}.{lastName}.{guid}";
            string emailAddress = $"{personalId}@d.codercamps.com";

            // only supports extended alpha-numeric characters
            string campaign = "western~ front";
            string comments = "can't stop, won't stop";

            List<ContentParameter> contentParameters = CreateUserEndpoint.GetContentParametersWithCampaignComments(
                firstName,
                lastName,
                emailAddress,
                campaign,
                comments);

            // call the endpoint
            EndpointResult result = await new CreateUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null, false)
                .ConfigureAwait(false);

            // ensure that the server returned a bad request response
            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.BadRequest, result.StatusCode);
        }

        [TestMethod]
        public async Task TestCreateUserCommentsWithInvalidCharacters()
        {
            // build the request
            int number1 = new Random().Next(0, 9999);
            int number2 = new Random().Next(0, 9999);
            string guid = Guid.NewGuid().ToString();

            string firstName = $"Integration_{number1}";
            string lastName = $"Test_{number2}";
            string personalId = $"{firstName}.{lastName}.{guid}";
            string emailAddress = $"{personalId}@d.codercamps.com";
            string campaign = "western front";

            // only supports extended alpha-numeric characters
            string comments = "can't stop, won't stop|";

            List<ContentParameter> contentParameters = CreateUserEndpoint.GetContentParametersWithCampaignComments(
                firstName,
                lastName,
                emailAddress,
                campaign,
                comments);

            // call the endpoint
            EndpointResult result = await new CreateUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null, false)
                .ConfigureAwait(false);

            // ensure that the server returned a bad request response
            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.BadRequest, result.StatusCode);
        }

        [TestMethod]
        public async Task TestSearchUsersByFirstName()
        {
            // search for users via first name
            List<QueryParameter> queryParameters = SearchUsersEndpoint.GetSearchUsersByFirstNameQueryParameters("Super");

            EndpointResult result = await new SearchUsersEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(null, queryParameters).ConfigureAwait(false);

            // verify that the response is valid JSON
            var json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No users were found when searching by first name.");
            }
        }

        [TestMethod]
        public async Task TestSearchUsersByLastName()
        {
            // search for users via last name
            List<QueryParameter> queryParameters = SearchUsersEndpoint.GetSearchUsersByLastNameQueryParameters("Coder");

            EndpointResult result = await new SearchUsersEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(null, queryParameters).ConfigureAwait(false);

            // verify that the response is valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No users were found when searching by last name.");
            }
        }

        [TestMethod]
        public async Task TestSearchUsersByEmailAddress()
        {
            // search for users via e-mail address
            List<QueryParameter> queryParameters = SearchUsersEndpoint.GetSearchUsersByEmailAddressQueryParameters("student");

            EndpointResult result = await new SearchUsersEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(null, queryParameters).ConfigureAwait(false);

            // verify that the response is valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No users were found when searching by e-mail address.");
            }
        }

        [TestMethod]
        public async Task TestSearchUsersByAllParameters()
        {
            // search for users via a combination of first name, last name, and e-mail address
            List<QueryParameter> queryParameters = SearchUsersEndpoint.GetSearchUsersByAllQueryParameters(
                "Student",
                "Coder",
                "Student1");

            EndpointResult result = await new SearchUsersEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(null, queryParameters).ConfigureAwait(false);

            // verify that the response is valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No users were found when searching by first name, last name, and e-mail address.");
            }
        }

        [TestMethod]
        public async Task TestSearchUserEnrollmentProgressByCourseCodes()
        {
            int userId = 430;

            List<ContentParameter> contentParameters = SearchUserEnrollmentProgressEndpoint.GetContentParameters(new List<string>()
            {
                "CFS105",
            });

            EndpointResult result = await new SearchUserEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                userId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No user enrollment progress was found when searching by course codes.");
            }
        }

        [TestMethod]
        public async Task TestSearchUserEnrollmentProgressBySectionIds()
        {
            int userId = 430;

            List<ContentParameter> contentParameters = SearchUserEnrollmentProgressEndpoint.GetContentParameters(new List<int>()
            {
                41686,
            });

            EndpointResult result = await new SearchUserEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                userId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No user enrollment progress was found when searching by section identifiers.");
            }
        }

        [TestMethod]
        public async Task TestSearchUserEnrollmentProgressByCourseCodesAndSectionIds()
        {
            int userId = 430;

            List<ContentParameter> contentParameters = SearchUserEnrollmentProgressEndpoint.GetContentParameters(
                new List<string>()
                {
                    "CFS105",
                },
                new List<int>()
                {
                    41686,
                    41747
                });

            EndpointResult result = await new SearchUserEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                userId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No user enrollment progress was found when searching by course codes and section identifiers.");
            }
        }

        [TestMethod]
        public async Task TestSearchUserEnrollmentProgressActiveOnly()
        {
            int userId = 430;

            List<ContentParameter> contentParameters = SearchUserEnrollmentProgressEndpoint.GetContentParameters(true);

            EndpointResult result = await new SearchUserEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                userId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No user enrollment progress was found when searching by only active enrollments.");
            }
        }

        [TestMethod]
        public async Task TestSearchUserEnrollmentProgressInactiveOnly()
        {
            int userId = 430;

            List<ContentParameter> contentParameters = SearchUserEnrollmentProgressEndpoint.GetContentParameters(false);

            EndpointResult result = await new SearchUserEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                userId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No user enrollment progress was found when searching by only inactive enrollments.");
            }
        }

        [TestMethod]
        public async Task TestSearchUserEnrollmentProgressActiveAsOfDateOnly()
        {
            int userId = 430;

            List<ContentParameter> contentParameters = SearchUserEnrollmentProgressEndpoint.GetContentParameters(DateTime.UtcNow);

            EndpointResult result = await new SearchUserEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                userId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No user enrollment progress was found when searching by only active (as of date) enrollments.");
            }
        }

        [TestMethod]
        public async Task TestSearchUserEnrollmentProgressAll()
        {
            int userId = 430;

            List<ContentParameter> contentParameters = new List<ContentParameter>();

            EndpointResult result = await new SearchUserEnrollmentProgressEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                userId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            JsonArray json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No user enrollment progress was found when searching for all enrollments.");
            }
        }

        [TestMethod]
        public async Task TestUpdateUserByExeterId()
        {
            Assert.IsTrue((DefaultUserIdSet?.UserId ?? default(int)) != default(int));

            string guid = Guid.NewGuid().ToString();

            List<ContentParameter> contentParameters = UpdateUserBaseEndpoint.GetUpdateUserEmailAddressContentParameters($"{guid}@d.codercamps.com");

            EndpointResult result = await new UpdateUserByExeterIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultUserIdSet.UserId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestUpdateUserByIntegrationId()
        {
            Assert.IsTrue((DefaultUserIdSet?.IntegrationIds?.Count ?? 0) > 0);

            for (int i = 0; i < DefaultUserIdSet.IntegrationIds.Count; i++)
            {
                IntegrationId integrationId = DefaultUserIdSet.IntegrationIds[i];

                List<ContentParameter> contentParameters = UpdateUserBaseEndpoint.GetUpdateUserCompanyContentParameters($"Coder Camps {i}");

                EndpointResult result = await new UpdateUserByIntegrationIdEndpoint(
                    Environment.BASE_URI,
                    Environment.AUTH_TOKEN,
                    integrationId.idType,
                    integrationId.idValue).CallEndpoint(contentParameters, null).ConfigureAwait(false);

                Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
            }
        }

        [TestMethod]
        public async Task TestUpdateUserOrigin()
        {
            Assert.IsTrue((DefaultUserIdSet?.UserId ?? default(int)) != default(int));

            List<ContentParameter> contentParameters = UpdateUserBaseEndpoint.GetContentParametersWithOrigin(OriginType.Client);

            EndpointResult result = await new UpdateUserByExeterIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultUserIdSet.UserId)
                .CallEndpoint(contentParameters, null, false)
                .ConfigureAwait(false);

            // we are not allowed to update the origin of a user
            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.BadRequest, result.StatusCode);
        }

        [TestMethod]
        public async Task TestUpdateUserCampaign()
        {
            Assert.IsTrue((DefaultUserIdSet?.UserId ?? default(int)) != default(int));

            List<ContentParameter> contentParameters = UpdateUserBaseEndpoint.GetContentParametersWithCampaign("western front");

            EndpointResult result = await new UpdateUserByExeterIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultUserIdSet.UserId)
                .CallEndpoint(contentParameters, null, false)
                .ConfigureAwait(false);

            // we are not allowed to update the origin of a user
            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.BadRequest, result.StatusCode);
        }

        [TestMethod]
        public async Task TestUpdateUserComments()
        {
            Assert.IsTrue((DefaultUserIdSet?.UserId ?? default(int)) != default(int));

            string comments = "This is a comment.";

            List<ContentParameter> contentParameters = UpdateUserBaseEndpoint.GetContentParametersWithComments(comments);

            EndpointResult result = await new UpdateUserByExeterIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultUserIdSet.UserId)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result?.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);
            Assert.IsNotNull(result?.TransactionMetadata?.Resource);

            UserMetadata userMetadata = UserMetadata.Load(result.TransactionMetadata.Resource);

            Assert.AreEqual(comments, userMetadata.Comments);
        }

        [TestMethod]
        public async Task TestUpdateUserIntegrationIds()
        {
            // create a new user
            UserIdSet userIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);

            Assert.IsTrue((userIdSet?.UserId ?? default(int)) != default(int));
            Assert.IsTrue((userIdSet?.IntegrationIds?.Count ?? 0) > 0);

            // generate the collections of integration IDs for various update operations
            List<IntegrationId> updatedIds = new List<IntegrationId>();
            List<IntegrationId> removedIds = new List<IntegrationId>();

            foreach (IntegrationId id in userIdSet.IntegrationIds)
            {
                string updatedIdValue = $"{id.idValue}_UPDATED";

                updatedIds.Add(new IntegrationId(id.idType, updatedIdValue));
                removedIds.Add(new IntegrationId(id.idType, string.Empty));
            }

            // update the IDs
            Console.WriteLine($"Updating the integration identifiers for user with Exeter ID {userIdSet.UserId}...");

            EndpointResult result = await new UpdateUserIntegrationIdsEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                userIdSet.UserId).CallEndpoint(updatedIds, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

            Console.WriteLine($"Updated the integration identifiers for user with Exeter ID {userIdSet.UserId}.");

            // remove the IDs
            Console.WriteLine($"Removing the integration identifiers for user with Exeter ID {userIdSet.UserId}...");

            result = await new UpdateUserIntegrationIdsEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                userIdSet.UserId).CallEndpoint(removedIds, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

            Console.WriteLine($"Removed the integration identifiers for user with Exeter ID {userIdSet.UserId}.");

            // add the updated IDs
            Console.WriteLine($"Adding the updated integration identifiers for user with Exeter ID {userIdSet.UserId}...");

            result = await new UpdateUserIntegrationIdsEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                userIdSet.UserId).CallEndpoint(updatedIds, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

            Console.WriteLine($"Added the updated integration identifiers for user with Exeter ID {userIdSet.UserId}.");
        }

        [TestMethod]
        public async Task TestRetrieveUserByExeterId()
        {
            Assert.IsTrue((DefaultUserIdSet?.UserId ?? default(int)) != default(int));

            EndpointResult result = await new RetrieveUserByExeterIdEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN, DefaultUserIdSet.UserId).CallEndpoint(null, null).ConfigureAwait(false);

            JsonObject json = result.ResponseBody as JsonObject;

            Assert.IsTrue(json != null);
        }

        [TestMethod]
        public async Task TestRetrieveUserByIntegrationIds()
        {
            Assert.IsTrue((DefaultUserIdSet?.IntegrationIds?.Count ?? 0) > 0);

            foreach (IntegrationId integrationId in DefaultUserIdSet.IntegrationIds)
            {
                EndpointResult result = await new RetrieveUserByIntegrationIdEndpoint(
                    Environment.BASE_URI,
                    Environment.AUTH_TOKEN,
                    integrationId.idType,
                    integrationId.idValue).CallEndpoint(null, null).ConfigureAwait(false);

                JsonObject json = result.ResponseBody as JsonObject;

                Assert.IsTrue(json != null);
            }
        }

        [TestMethod]
        public async Task TestRetrieveUserCreatedWithOriginCampaignComments()
        {
            // build the request
            int number1 = new Random().Next(0, 9999);
            int number2 = new Random().Next(0, 9999);
            string guid = Guid.NewGuid().ToString();

            string firstName = $"Integration_{number1}";
            string lastName = $"Test_{number2}";
            string personalId = $"{firstName}.{lastName}.{guid}";
            string emailAddress = $"{personalId}@d.codercamps.com";
            OriginType origin = OriginType.Platform;
            string campaign = "western front";
            string comments = "can't stop, won't stop";

            List<ContentParameter> contentParameters = CreateUserEndpoint.GetContentParametersWithOriginCampaignComments(
                firstName,
                lastName,
                emailAddress,
                origin,
                campaign,
                comments);

            // call the endpoint
            EndpointResult result = await new CreateUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result?.TransactionMetadata);
            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
            Assert.IsNotNull(result?.TransactionMetadata?.Resource);

            // deserialize the results
            UserMetadata userMetadata = UserMetadata.Load(result.TransactionMetadata.Resource);

            // verify origin is client
            Assert.AreEqual(OriginType.Client, userMetadata.Origin);

            // verify campaign and comments are as provided
            Assert.AreEqual(campaign, userMetadata.Campaign);
            Assert.AreEqual(comments, userMetadata.Comments);

            // retrieve the created user and verify that the new fields are returned
            result = await new RetrieveUserByExeterIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                userMetadata.ExeterId)
                .CallEndpoint(null, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.ResponseBody);

            JsonObject json = result.ResponseBody as JsonObject;

            Assert.IsNotNull(json);

            userMetadata = UserMetadata.Load(json);

            // verify origin is client
            Assert.AreEqual(OriginType.Client, userMetadata.Origin);

            // verify campaign and comments are as provided
            Assert.AreEqual(campaign, userMetadata.Campaign);
            Assert.AreEqual(comments, userMetadata.Comments);
        }

        [TestMethod]
        public async Task TestCreateUserAdvisorshipByExeterId()
        {
            UserIdSet advisorUserIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);
            UserIdSet studentUserIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);
            DateTime utcNowDate = DateTime.UtcNow.Date;
            DateTime utcNowDatePlusSevenDays = utcNowDate + TimeSpan.FromDays(7);

            List<ContentParameter> contentParameters = CreateUserAdvisorshipByExeterIdEndpoint.GetContentParametersWithLastMeetingDate(
                studentUserIdSet.UserId,
                utcNowDate,
                utcNowDatePlusSevenDays,
                AdvisorRole.Academic);

            EndpointResult result = await new CreateUserAdvisorshipByExeterIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                advisorUserIdSet.UserId)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);

            AdvisorAssignmentMetadata advisorAssignmentMetadata = AdvisorAssignmentMetadata.Load(result.TransactionMetadata.Resource);

            // test that a new advisor assignment was created
            Assert.IsNotNull(advisorAssignmentMetadata);
            Assert.IsTrue(advisorAssignmentMetadata.AdvisorAssignmentId > 0);
            Assert.AreNotEqual(DefaultUserAdvisorship.AdvisorAssignmentId, advisorAssignmentMetadata.AdvisorAssignmentId);
            Assert.AreEqual(studentUserIdSet.UserId, advisorAssignmentMetadata.StudentExeterId);

            // test that the correct values were set
            Assert.AreEqual(utcNowDate, advisorAssignmentMetadata.AssignmentDateUTC.Date);
            Assert.IsTrue(advisorAssignmentMetadata.LastMeetingDateUTC.HasValue);
            Assert.AreEqual(utcNowDatePlusSevenDays, advisorAssignmentMetadata.LastMeetingDateUTC.Value.Date);
            Assert.AreEqual(AdvisorRole.Academic, advisorAssignmentMetadata.AdvisorRole);
        }

        [TestMethod]
        public async Task TestCreateUserAdvisorshipByExeterIdAlreadyExists()
        {
            DateTime utcNowPlusThirtyDays = DateTime.UtcNow + TimeSpan.FromDays(30);

            List<ContentParameter> contentParameters = CreateUserAdvisorshipByExeterIdEndpoint.GetContentParametersWithLastMeetingDate(
                DefaultUserAdvisorship.StudentExeterId,
                DefaultUserAdvisorship.AssignmentDateUTC,
                utcNowPlusThirtyDays,
                DefaultUserAdvisorship.AdvisorRole);

            EndpointResult result = await new CreateUserAdvisorshipByExeterIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultAdvisorUserIdSet.UserId)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);

            AdvisorAssignmentMetadata advisorAssignmentMetadata = AdvisorAssignmentMetadata.Load(result.TransactionMetadata.Resource);

            // test that a new advisor assignment was not created
            Assert.IsNotNull(advisorAssignmentMetadata);
            Assert.AreEqual(DefaultUserAdvisorship.AdvisorAssignmentId, advisorAssignmentMetadata.AdvisorAssignmentId);
            Assert.AreEqual(DefaultStudentUserIdSet.UserId, advisorAssignmentMetadata.StudentExeterId);
            Assert.AreEqual(DefaultUserAdvisorship.AdvisorId, advisorAssignmentMetadata.AdvisorId);

            // test that the last meeting date of the existing advisor assignment was updated
            Assert.IsTrue(advisorAssignmentMetadata.LastMeetingDateUTC.HasValue);
            Assert.AreEqual(utcNowPlusThirtyDays.Date, advisorAssignmentMetadata.LastMeetingDateUTC.Value.Date);
        }

        [TestMethod]
        public async Task TestCreateUserAdvisorshipByIntegrationIdWithoutLastMeetingDate()
        {
            UserIdSet advisorUserIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);
            UserIdSet studentUserIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);
            DateTime utcNowDate = DateTime.UtcNow.Date;

            List<ContentParameter> contentParameters = CreateUserAdvisorshipByIntegrationIdEndpoint.GetContentParameters(
                studentUserIdSet.IntegrationIds[0].idType,
                studentUserIdSet.IntegrationIds[0].idValue,
                utcNowDate,
                AdvisorRole.Financial);

            EndpointResult result = await new CreateUserAdvisorshipByIntegrationIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                advisorUserIdSet.IntegrationIds[0].idType,
                advisorUserIdSet.IntegrationIds[0].idValue)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);

            AdvisorAssignmentMetadata advisorAssignmentMetadata = AdvisorAssignmentMetadata.Load(result.TransactionMetadata.Resource);

            // test that a new advisor assignment was created
            Assert.IsNotNull(advisorAssignmentMetadata);
            Assert.IsTrue(advisorAssignmentMetadata.AdvisorAssignmentId > 0);
            Assert.AreNotEqual(DefaultUserAdvisorship.AdvisorAssignmentId, advisorAssignmentMetadata.AdvisorAssignmentId);
            Assert.AreEqual(studentUserIdSet.UserId, advisorAssignmentMetadata.StudentExeterId);

            // test that the correct values were set
            Assert.AreEqual(utcNowDate, advisorAssignmentMetadata.AssignmentDateUTC.Date);
            Assert.IsFalse(advisorAssignmentMetadata.LastMeetingDateUTC.HasValue);
            Assert.AreEqual(AdvisorRole.Financial, advisorAssignmentMetadata.AdvisorRole);
        }

        [TestMethod]
        public async Task TestCreateUserAdvisorshipByIntegrationIdWithLastMeetingDateFromDefault()
        {
            DateTime utcNowDatePlusEightDays = DateTime.UtcNow.Date + TimeSpan.FromDays(8);
            AdvisorRole vacantRole = Enum.GetValues(typeof(AdvisorRole))
                .Cast<AdvisorRole>()
                .Where(x => x != DefaultUserAdvisorship.AdvisorRole && x != AdvisorRole.Unknown)
                .First();

            List<ContentParameter> contentParameters = CreateUserAdvisorshipByExeterIdEndpoint.GetContentParametersWithLastMeetingDate(
                DefaultUserAdvisorship.StudentExeterId,
                DefaultUserAdvisorship.AssignmentDateUTC,
                utcNowDatePlusEightDays,
                vacantRole);

            EndpointResult result = await new CreateUserAdvisorshipByIntegrationIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultAdvisorUserIdSet.IntegrationIds[0].idType,
                DefaultAdvisorUserIdSet.IntegrationIds[0].idValue)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);

            AdvisorAssignmentMetadata advisorAssignmentMetadata = AdvisorAssignmentMetadata.Load(result.TransactionMetadata.Resource);

            // test that a new advisor assignment was created
            Assert.IsNotNull(advisorAssignmentMetadata);
            Assert.IsTrue(advisorAssignmentMetadata.AdvisorAssignmentId > 0);
            Assert.AreNotEqual(DefaultUserAdvisorship.AdvisorAssignmentId, advisorAssignmentMetadata.AdvisorAssignmentId);
            Assert.AreEqual(DefaultStudentUserIdSet.UserId, advisorAssignmentMetadata.StudentExeterId);
            Assert.AreEqual(DefaultUserAdvisorship.AdvisorId, advisorAssignmentMetadata.AdvisorId);

            // test that the correct values were set
            Assert.AreEqual(DefaultUserAdvisorship.AssignmentDateUTC.Date, advisorAssignmentMetadata.AssignmentDateUTC.Date);
            Assert.IsTrue(advisorAssignmentMetadata.LastMeetingDateUTC.HasValue);
            Assert.AreEqual(utcNowDatePlusEightDays, advisorAssignmentMetadata.LastMeetingDateUTC.Value.Date);
            Assert.AreEqual(vacantRole, advisorAssignmentMetadata.AdvisorRole);
        }

        [TestMethod]
        public async Task TestCreateUserAdvisorshipByIntegrationIdAlreadyExists()
        {
            DateTime utcNowDatePlusTenDays = DateTime.UtcNow.Date + TimeSpan.FromDays(10);
            DateTime? originalLastMeetingDateUTC = DefaultUserAdvisorship.LastMeetingDateUTC;

            List<ContentParameter> contentParameters = CreateUserAdvisorshipByIntegrationIdEndpoint.GetContentParametersWithLastMeetingDate(
                DefaultStudentUserIdSet.IntegrationIds[0].idType,
                DefaultStudentUserIdSet.IntegrationIds[0].idValue,
                DefaultUserAdvisorship.AssignmentDateUTC,
                utcNowDatePlusTenDays,
                DefaultUserAdvisorship.AdvisorRole);

            EndpointResult result = await new CreateUserAdvisorshipByIntegrationIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultAdvisorUserIdSet.IntegrationIds[0].idType,
                DefaultAdvisorUserIdSet.IntegrationIds[0].idValue)
                .CallEndpoint(contentParameters, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.TransactionMetadata);
            Assert.AreEqual(TransactionStatus.Succeeded, result.TransactionMetadata.Status);

            AdvisorAssignmentMetadata advisorAssignmentMetadata = AdvisorAssignmentMetadata.Load(result.TransactionMetadata.Resource);

            // test that a new entity was not created
            Assert.IsNotNull(advisorAssignmentMetadata);
            Assert.AreEqual(DefaultUserAdvisorship.AdvisorAssignmentId, advisorAssignmentMetadata.AdvisorAssignmentId);
            Assert.AreEqual(DefaultStudentUserIdSet.UserId, advisorAssignmentMetadata.StudentExeterId);
            Assert.AreEqual(DefaultUserAdvisorship.AdvisorId, advisorAssignmentMetadata.AdvisorId);

            // test that the last meeting date was updated
            Assert.IsTrue(advisorAssignmentMetadata.LastMeetingDateUTC.HasValue);
            Assert.AreEqual(utcNowDatePlusTenDays, advisorAssignmentMetadata.LastMeetingDateUTC.Value);
            Assert.AreNotEqual(originalLastMeetingDateUTC ?? default(DateTime), advisorAssignmentMetadata.LastMeetingDateUTC.Value);
        }

        [TestMethod]
        public async Task TestRetrieveUserAdvisorshipsByExeterId()
        {
            EndpointResult result = await new RetrieveUserAdvisorshipsByExeterIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultAdvisorUserIdSet.UserId)
                .CallEndpoint(null, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.ResponseBody as JsonArray);

            JsonArray jsonArray = result.ResponseBody as JsonArray;

            if (jsonArray.Count == 0)
            {
                Assert.Inconclusive("No user advisorships were returned.");
            }
            else
            {
                Assert.IsTrue(jsonArray
                    .Select(x => AdvisorAssignmentMetadata.Load(x as JsonObject))
                    .All(x => x.AdvisorAssignmentId > 0 && x.AdvisorId == DefaultUserAdvisorship.AdvisorId));
            }
        }

        [TestMethod]
        public async Task TestRetrieveUserAdvisorshipsByIntegrationId()
        {
            EndpointResult result = await new RetrieveUserAdvisorshipsByIntegrationIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultAdvisorUserIdSet.IntegrationIds[0].idType,
                DefaultAdvisorUserIdSet.IntegrationIds[0].idValue)
                .CallEndpoint(null, null)
                .ConfigureAwait(false);

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.ResponseBody as JsonArray);

            JsonArray jsonArray = result.ResponseBody as JsonArray;

            if (jsonArray.Count == 0)
            {
                Assert.Inconclusive("No user advisorships were returned.");
            }
            else
            {
                Assert.IsTrue(jsonArray
                    .Select(x => AdvisorAssignmentMetadata.Load(x as JsonObject))
                    .All(x => x.AdvisorAssignmentId > 0 && x.AdvisorId == DefaultUserAdvisorship.AdvisorId));
            }
        }

        private static async Task InitializeDefaultUser()
        {
            DefaultUserIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);
        }

        private static async Task InitializeDefaultUserAdvisorship()
        {
            DefaultAdvisorUserIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);
            DefaultStudentUserIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);
            DefaultUserAdvisorship = await TestHelpers.CreateNewUserAdvisorship(
                DefaultAdvisorUserIdSet.UserId,
                DefaultStudentUserIdSet.UserId).ConfigureAwait(false);
        }
    }
}
