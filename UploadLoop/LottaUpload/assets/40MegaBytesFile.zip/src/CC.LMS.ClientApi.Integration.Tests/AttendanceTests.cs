﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Json;
    using System.Threading.Tasks;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Attendance;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class AttendanceTests
    {
        [ClassInitialize]
        public static void ClassInitialize(TestContext testContext)
        {
            if (!Environment.ENABLE_ENDPOINT_TESTS)
            {
                Assert.Inconclusive("Endpoint tests are currently disabled.  Endpoint tests may be enabled via the runsettings configuration.");
            }
        }

        [TestMethod]
        public async Task TestSearchAttendanceByCourseCodes()
        {
            List<ContentParameter> contentParameters = SearchAttendanceEndpoint.GetSearchAttendanceByCourseCodesContentParameters(
                new DateTime(2018, 7, 26),
                new List<string>()
                {
                    "DOW100",
                });

            EndpointResult result = await new SearchAttendanceEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            var json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No attendance records were found when searching by course codes.");
            }
        }

        [TestMethod]
        [ExpectedException(typeof(AssertInconclusiveException))]
        public async Task TestSearchAttendanceByIntegrationIdsNoResults()
        {
            List<ContentParameter> contentParameters = SearchAttendanceEndpoint.GetSearchAttendanceByIntegrationIdsContentParameters(
                new DateTime(2017, 10, 6),
                new List<IntegrationId>()
                {
                    new IntegrationId(1, $"DNE_{Guid.NewGuid().ToString()}"),
                });

            EndpointResult result = await new SearchAttendanceEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            // verify that the response is valid JSON
            var json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No attendance records were found when searching by integration IDs.");
            }
        }
    }
}
