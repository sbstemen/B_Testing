﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
//
// Copyright (c) 2016-18
// Project:      CC.LMS Client API Tests
// *************************************************************

namespace CC.LMS.ClientApi.Integration.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Json;
    using System.Threading.Tasks;
    using CC.LMS.ClientApi.Integration.Tests.Common;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints;
    using CC.LMS.ClientApi.Integration.Tests.Endpoints.Cohorts;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class CohortsTests
    {
        private static int DefaultCohortId { get; set; }

        private static UserIdSet DefaultUserIdSet { get; set; }

        [ClassInitialize]
        public static async Task ClassInitialize(TestContext testContext)
        {
            if (!Environment.ENABLE_ENDPOINT_TESTS)
            {
                Assert.Inconclusive("Endpoint tests are currently disabled.  Endpoint tests may be enabled via the runsettings configuration.");
            }

            await Task.WhenAll(InitializeDefaultCohort(), InitializeDefaultUser());
        }

        [TestMethod]
        public async Task TestCreateCohort()
        {
            int number1 = new Random().Next(0, 999);
            string cohortName = $"Cohort_{number1:D3}";
            string cohortDescription = $"This is the description for cohort {cohortName}.";
            DateTime endDateUTC = DateTime.UtcNow.Add(TimeSpan.FromDays(5));
            DateTime startDateUTC = endDateUTC.Subtract(TimeSpan.FromDays(10));

            List<ContentParameter> contentParameters = CreateCohortEndpoint.GetCreateCohortContentParameters(
                cohortName,
                cohortDescription,
                startDateUTC,
                endDateUTC);

            EndpointResult result = await new CreateCohortEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestUpdateCohort()
        {
            List<ContentParameter> contentParameters = UpdateCohortEndpoint.GetUpdateCohortDescriptionContentParameters(Guid.NewGuid().ToString());

            EndpointResult result = await new UpdateCohortEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultCohortId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestRetrieveCohortByCohortId()
        {
            Assert.IsTrue(DefaultCohortId != default(int));

            EndpointResult result = await new RetrieveCohortByCohortIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultCohortId).CallEndpoint(null, null).ConfigureAwait(false);

            JsonObject json = result.ResponseBody as JsonObject;

            Assert.IsTrue(json != null);
        }

        [TestMethod]
        public async Task TestSearchCohortsByCohortId()
        {
            List<QueryParameter> queryParameters = SearchCohortsEndpoint.GetSearchCohortsByCohortIdQueryParameters(DefaultCohortId);

            EndpointResult result = await new SearchCohortsEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN).CallEndpoint(null, queryParameters).ConfigureAwait(false);

            // verify that the request is valid JSON
            var json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No cohorts were found when searching by cohort ID.");
            }
        }

        [TestMethod]
        public async Task TestSearchCohortsByName()
        {
            List<QueryParameter> queryParameters = SearchCohortsEndpoint.GetSearchCohortsByNameQueryParameters("Great Bananas");

            EndpointResult result = await new SearchCohortsEndpoint(Environment.BASE_URI, Environment.AUTH_TOKEN).CallEndpoint(null, queryParameters).ConfigureAwait(false);

            // verify that the request is valid JSON
            var json = result.ResponseBody as JsonArray;

            Assert.IsTrue(json != null);

            if (json.Count == 0)
            {
                Assert.Inconclusive("No cohorts were found when searching by name.");
            }
        }

        [TestMethod]
        public async Task TestCreateRetrieveDeleteCohortUserByExeterId()
        {
            Assert.IsTrue(DefaultCohortId != default(int));
            Assert.IsTrue((DefaultUserIdSet?.UserId ?? default(int)) != default(int));

            // create cohort user by Exeter ID
            List<ContentParameter> contentParameters = CreateCohortUserEndpoint.GetCreateCohortUserContentParameters(DefaultUserIdSet.UserId);

            EndpointResult result = await new CreateCohortUserEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultCohortId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

            // retrieve all cohort users
            result = await new RetrieveAllCohortUsersEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultCohortId).CallEndpoint(null, null).ConfigureAwait(false);

            JsonArray jsonArray = result.ResponseBody as JsonArray;

            Assert.IsTrue(jsonArray != null);

            // delete cohort user by Exeter ID
            result = await new DeleteCohortUserByExeterIdEndpoint(
                Environment.BASE_URI,
                Environment.AUTH_TOKEN,
                DefaultCohortId,
                DefaultUserIdSet.UserId).CallEndpoint(null, null).ConfigureAwait(false);

            Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
        }

        [TestMethod]
        public async Task TestCreateRetrieveDeleteCohortUserByIntegrationId()
        {
            Assert.IsTrue(DefaultCohortId != default(int));
            Assert.IsTrue((DefaultUserIdSet?.IntegrationIds?.Count ?? 0) > 0);

            foreach (IntegrationId integrationId in DefaultUserIdSet.IntegrationIds)
            {
                // create cohort user by integration ID
                List<ContentParameter> contentParameters = CreateCohortUserEndpoint.GetCreateCohortUserContentParameters(integrationId.idType, integrationId.idValue);

                EndpointResult result = await new CreateCohortUserEndpoint(
                    Environment.BASE_URI,
                    Environment.AUTH_TOKEN,
                    DefaultCohortId).CallEndpoint(contentParameters, null).ConfigureAwait(false);

                Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);

                // retrieve all cohort users
                result = await new RetrieveAllCohortUsersEndpoint(
                    Environment.BASE_URI,
                    Environment.AUTH_TOKEN,
                    DefaultCohortId).CallEndpoint(null, null).ConfigureAwait(false);

                JsonArray jsonArray = result.ResponseBody as JsonArray;

                Assert.IsTrue(jsonArray != null);

                // delete cohort user by integration ID
                result = await new DeleteCohortUserByIntegrationIdEndpoint(
                    Environment.BASE_URI,
                    Environment.AUTH_TOKEN,
                    DefaultCohortId,
                    integrationId.idType,
                    integrationId.idValue).CallEndpoint(null, null).ConfigureAwait(false);

                Assert.IsTrue(result.TransactionMetadata.Status == TransactionStatus.Succeeded);
            }
        }

        private static async Task InitializeDefaultCohort()
        {
            DefaultCohortId = await TestHelpers.CreateDefaultCohort().ConfigureAwait(false);
        }

        private static async Task InitializeDefaultUser()
        {
            DefaultUserIdSet = await TestHelpers.CreateDefaultUser().ConfigureAwait(false);
        }
    }
}
