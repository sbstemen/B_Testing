﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
// -- SBS ~ 20180314
// Copyright (c) 2016-18
// PROJECT:  CC.LMS.Student.ProfileTest
// FILE:  ProfileTests.cs ~ Test entry point, calls process file
// *************************************************************

namespace CC.LMS.Profile
{
  using System;
  using System.IO;
  using Microsoft.VisualStudio.TestTools.UnitTesting;
  using OpenQA.Selenium;
  using OpenQA.Selenium.Chrome;

  using Utility;

  /// <summary>
  /// Resets a student Profilie, then updates Profile, then validates.
  /// </summary>
  [TestClass]
  public class ProfileTests
  {
    private static string chromePath = Directory.GetCurrentDirectory() + "\\assets\\";
    private static string testName = Properties.Settings.Default.Testname;
    private static string logPath = Properties.Settings.Default.LogPath +
    Properties.Settings.Default.Testname + DateTime.Now.ToString("-MM-dd-HHmm");

    private UserData usrData = new UserData();
    private Utilities utils = new Utilities(logPath);
    private ProfileTestProcess changeProfile = new ProfileTestProcess();

    /// <summary>
    /// Initializes a student for WOZ to a starting point.
    /// </summary>
    [TestInitialize]
    public void TestUser()
    {
      this.utils.UDataFiller(this.usrData);
      this.usrData.ClientUrl = Properties.Settings.Default.WZURL;
      this.usrData.LogInAlias = Properties.Settings.Default.WZStudent;
      this.usrData.Password = Properties.Settings.Default.password;
      this.utils.CleanUserData(this.usrData);
    }

    /// <summary>
    /// Updates a student profile page then validates the updated data.
    /// </summary>
    [TestMethod]
    public void BasicProfileTest()
    {
      int passCount = 0;
      int failCount = 0;

      using (IWebDriver webDriver = new ChromeDriver(chromePath))
      {
        this.changeProfile.SignIn(webDriver, this.utils, this.usrData, ref passCount, ref failCount);

        this.changeProfile.Picture(webDriver, this.utils, this.usrData, ref passCount, ref failCount);

        this.changeProfile.UpdateData(webDriver, this.utils, this.usrData, ref passCount, ref failCount);

        this.changeProfile.LoggingOff(webDriver, this.utils, this.usrData, ref passCount, ref failCount);

        this.utils.RandomPause(6);
      }

      using (IWebDriver webDriver = new ChromeDriver(chromePath))
      {
        this.changeProfile.SignIn(webDriver, this.utils, this.usrData, ref passCount, ref failCount);

        this.changeProfile.ValidateUpdates(webDriver, this.utils, this.usrData, ref passCount, ref failCount);

        this.changeProfile.LoggingOff(webDriver, this.utils, this.usrData, ref passCount, ref failCount);

        this.utils.RandomPause(1);
      }
    }
  }
}
