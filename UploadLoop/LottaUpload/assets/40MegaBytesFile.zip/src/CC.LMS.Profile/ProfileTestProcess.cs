﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
// -- SBS ~ 20180314
// Copyright (c) 2016-18
// Project:      CC.Student.Basic
// *************************************************************

namespace CC.LMS.Profile
{
  using System;
  using System.Drawing;
  using System.IO;
  using AutoIt;
  using Microsoft.VisualStudio.TestTools.UnitTesting;
  using OpenQA.Selenium;
  using Utility;

  /// <summary>
  /// Does the work of changing the student Profile Data.
  /// </summary>
  internal class ProfileTestProcess
  {
    /// <summary>
    /// Signs the in.
    /// </summary>
    /// <param name="webDriver">The web driver.</param>
    /// <param name="utils">The utils.</param>
    /// <param name="usrData">The usr data.</param>
    /// <param name="passCount">The pass count.</param>
    /// <param name="failCount">The fail count.</param>
    /// <returns>IWebDriver</returns>
    public IWebDriver SignIn(IWebDriver webDriver, Utilities utils, UserData usrData, ref int passCount, ref int failCount)
    {
      Size browserSize = new Size(1616, 900);
      string pageText = string.Empty;
      string searchText = string.Empty;
      string startPage = @"https://www.google.com/";
      webDriver.Navigate().GoToUrl(startPage);
      utils.RandomPause(1);
      webDriver.Manage().Window.Size = browserSize;
      webDriver.Navigate().GoToUrl(usrData.ClientUrl);
      utils.RandomPause(2);
      webDriver.FindElement(By.Id("Username")).SendKeys(usrData.LogInAlias);
      webDriver.FindElement(By.Id("Password")).SendKeys(usrData.Password);
      utils.RandomPause(2);
      webDriver.FindElement(By.ClassName("cc-btn-sign-in")).Click();
      utils.RandomPause(5); // Update to wait for code needs to be 5 minimum.
      pageText = webDriver.PageSource.ToString();

      searchText = "My Dashboard";

      try
      {
        Assert.IsTrue(pageText.Contains(searchText));
        {
          utils.MakeLogEntry("Student shows a dashboard");
          utils.RandomPause(2);
          passCount = ++passCount;
          searchText = string.Empty;
        }
      }
      catch (Exception expText)
      {
        searchText = "Graded Assignments";
        if (pageText.Contains(searchText))
        {
          utils.MakeLogEntry("FAILED FAILED Either last user wasn't logged out, or wrong client details.");
        }
        else
        {
          utils.MakeLogEntry("FAILED FAILED Tried to authenticate as a student something went really wrong");
        }

        utils.MakeLogEntry("Log On Failed for client " + usrData.LogInAlias);
        utils.MakeLogEntry("Exception Code" + expText);
        failCount = failCount++;
        Assert.Fail();
      }

      return webDriver;
    }

    /// <summary>
    /// Pictures the specified web driver.
    /// </summary>
    /// <param name="webDriver">The web driver.</param>
    /// <param name="utils">The utils.</param>
    /// <param name="usrData">The usr data.</param>
    /// <param name="passCount">The pass count.</param>
    /// <param name="failCount">The fail count.</param>
    /// <returns>IWebDriver</returns>
    public IWebDriver Picture(IWebDriver webDriver, Utilities utils, UserData usrData, ref int passCount, ref int failCount)
    {
      string imageName = Directory.GetCurrentDirectory() + "\\assets\\" + utils.ImageRandomizer();

      utils.RandomPause(2);

      webDriver.FindElement(By.CssSelector(".nav.navbar-nav.navbar-right>li:last-child>a")).Click();

      utils.RandomPause(1);

      webDriver.FindElement(By.Id("qa-dropdown-profile")).Click();

      utils.RandomPause(1);

      webDriver.FindElement(By.ClassName("cc-image-uploader-save-btn")).Click();

      utils.RandomPause(2);

      webDriver.FindElement(By.CssSelector(".cc-file-input-container > label:nth-child(2)")).Click();

      utils.RandomPause(1);

      AutoItX.WinWaitActive("Open");
      AutoItX.ControlGetFocus("ComboBox1");
      AutoItX.Send(imageName);
      AutoItX.ControlGetFocus("Button1");
      AutoItX.Send("{ENTER}");

      utils.RandomPause(1);

      var findPoint = webDriver.FindElements(
          By.CssSelector("div[style=\"display: block;\"].modal button.cc-image-uploader-save-btn"));

      ((IJavaScriptExecutor)webDriver).ExecuteScript("arguments[0].scrollIntoView(true);", findPoint[0]);

      utils.RandomPause(1);

      findPoint[0].Click();

      utils.RandomPause(2);

      return webDriver;
    }

    /// <summary>
    /// Updates the data.
    /// </summary>
    /// <param name="webDriver">The web driver.</param>
    /// <param name="utils">The utils.</param>
    /// <param name="usrData">The usr data.</param>
    /// <param name="passCount">The pass count.</param>
    /// <param name="failCount">The fail count.</param>
    /// <returns>IWebDriver</returns>
    public IWebDriver UpdateData(IWebDriver webDriver, Utilities utils, UserData usrData, ref int passCount, ref int failCount)
    {
      utils.RandomPause(1);

      var saveButtons = webDriver.FindElements(By.ClassName("cc-profile-form-save-btn"));

      utils.RandomPause(3);

      // Company
      webDriver.FindElement(By.Id("company")).Clear();
      utils.RandomPause(2);
      webDriver.FindElement(By.Id("company")).SendKeys(usrData.Company);
      utils.RandomPause(4);

      // Title
      webDriver.FindElement(By.Id("jobTitle")).Clear();
      utils.RandomPause(2);
      webDriver.FindElement(By.Id("jobTitle")).SendKeys(usrData.Title);
      utils.RandomPause(4);

      // Educational
      webDriver.FindElement(By.Id("educationHistory")).Clear();
      utils.RandomPause(2);
      webDriver.FindElement(By.Id("educationHistory")).SendKeys(usrData.EducationHistoryText);
      utils.RandomPause(4);

      // Employment
      webDriver.FindElement(By.Id("employmentHistory")).Clear();
      utils.RandomPause(2);
      webDriver.FindElement(By.Id("employmentHistory")).SendKeys(usrData.EmploymentHistoryText);
      utils.RandomPause(4);

      // Bio
      webDriver.FindElement(By.Id("bio")).Clear();
      utils.RandomPause(2);
      webDriver.FindElement(By.Id("bio")).SendKeys(usrData.BioText);
      utils.RandomPause(4);

      // Scroll View
      IWebElement scrollToBio = webDriver.FindElement(By.Id("bio"));
      ((IJavaScriptExecutor)webDriver).ExecuteScript("arguments[0].scrollIntoView(true);", scrollToBio);
      utils.RandomPause(2);
      saveButtons[1].Click();
      utils.RandomPause(2);

      // LinkedIN
      webDriver.FindElement(By.Id("linkedInUrl")).Clear();
      utils.RandomPause(2);
      webDriver.FindElement(By.Id("linkedInUrl")).SendKeys(usrData.LinkedIn);
      utils.RandomPause(4);

      // Blog URL
      webDriver.FindElement(By.Id("blogUrl")).Clear();
      utils.RandomPause(2);
      webDriver.FindElement(By.Id("blogUrl")).SendKeys(usrData.BlogUrl);
      utils.RandomPause(4);

      // Twitter
      webDriver.FindElement(By.Id("twitterHandle")).Clear();
      utils.RandomPause(2);
      webDriver.FindElement(By.Id("twitterHandle")).SendKeys(usrData.TwitterName);
      utils.RandomPause(4);

      // GitHub
      webDriver.FindElement(By.Id("gitHubUrl")).Clear();
      utils.RandomPause(2);
      webDriver.FindElement(By.Id("gitHubUrl")).SendKeys(usrData.GitHubUrl);
      utils.RandomPause(4);

      // Scroll View
      IWebElement scrollToGitHub = webDriver.FindElement(By.Id("gitHubUrl"));
      ((IJavaScriptExecutor)webDriver).ExecuteScript("arguments[0].scrollIntoView(true);", scrollToGitHub);
      utils.RandomPause(1);

      saveButtons[2].Click();

      return webDriver;
    }

    /// <summary>
    /// Validates the updates.
    /// </summary>
    /// <param name="webDriver">The web driver.</param>
    /// <param name="utils">The utils.</param>
    /// <param name="usrData">The usr data.</param>
    /// <param name="passCount">The pass count.</param>
    /// <param name="failCount">The fail count.</param>
    /// <returns>IWebDriver</returns>
    public IWebDriver ValidateUpdates(IWebDriver webDriver, Utilities utils, UserData usrData, ref int passCount, ref int failCount)
    {
      utils.RandomPause(1);

      webDriver.FindElement(By.CssSelector(".nav.navbar-nav.navbar-right>li:last-child>a")).Click();

      utils.RandomPause(1);

      webDriver.FindElement(By.Id("qa-dropdown-profile")).Click();

      utils.RandomPause(1);

      string gitHubFromPage = webDriver.FindElement(By.Id("gitHubUrl")).GetAttribute("value");
      string gitHubEntered = usrData.GitHubUrl;

      try
      {
        Assert.IsTrue(gitHubFromPage.Contains(gitHubEntered));
        utils.MakeLogEntry("User update test pass:: Git matched = " + gitHubEntered);
        utils.MakeLogEntry("Time of user creation == " + usrData.CreatedAt.ToString());
        utils.MakeLogEntry("Epoch UTC ticks at creation == " + usrData.EpochTicks);
      }
      catch (AssertFailedException exText)
      {
        utils.MakeLogEntry("Failed the update check time of user creation == " + usrData.CreatedAt.ToString());
        utils.MakeLogEntry("Failed the update check, Epoch UTC ticks at creation == " + usrData.EpochTicks);
        Assert.Fail("Failed the update check" + Environment.NewLine + exText);
      }

      return webDriver;
    }

    /// <summary>
    /// Loggings the off.
    /// </summary>
    /// <param name="webDriver">The web driver.</param>
    /// <param name="utils">The utils.</param>
    /// <param name="usrData">The usr data.</param>
    /// <param name="passCount">The pass count.</param>
    /// <param name="failCount">The fail count.</param>
    /// <returns>IWebDriver</returns>
    public IWebDriver LoggingOff(IWebDriver webDriver, Utilities utils, UserData usrData, ref int passCount, ref int failCount)
    {
      utils.RandomPause(1);

      IJavaScriptExecutor javaExecution = (IJavaScriptExecutor)webDriver;

      javaExecution.ExecuteScript(
          "window.scrollTo(0, Math.max(document.documentElement.scrollHeight, document.body.scrollHeight, document.documentElement.clientHeight));");

      webDriver.FindElement(By.ClassName("qa-logout-button")).Click();

      utils.RandomPause(1);

      return webDriver;
    }
  }
}
