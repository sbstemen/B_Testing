﻿// *************************************************************
// Coder Camps
// 8444 N. 90th Street St. 110
// Scottsdale, AZ
// -- SBS ~ 201800607
// Copyright (c) 2016-18
// PROJECT:  CC.LMS Authentication and Log On Tests
// FILE:  Authentication.cs ~ Test entry point, calls process file
// *************************************************************

namespace CC.LMS.Authentication
{
  using System;
  using Microsoft.VisualStudio.TestTools.UnitTesting;
  using Utility;

  /// <summary>
  /// Performs the Login an Authentication tests for all clients students and Admin accounts.
  /// </summary>
  [TestClass]
  public class Authentications
  {
    /// <summary>
    /// The password can be changed in the Settins.Settins file
    /// </summary>
    private static string passWord = Properties.Settings.Default.Password;  /*y*/
    private static string testName = Properties.Settings.Default.TestName;
    private static string runDateTime = DateTime.Now.ToString("-MM-dd-HHmm");
    private static string logPath = Properties.Settings.Default.LogPath + testName + runDateTime;
    private Utilities utility = new Utilities(logPath);
    private PassFailCount results = new PassFailCount();
    private AuthenticationsProcess logIn = new AuthenticationsProcess();

    /// <summary>
    /// Initializes the pass fail object and sets one pass count.
    /// </summary>
    [TestInitialize]
    public void TestCount()
    {
      results.PassCount = results.PassCount + 1;
    }

    /// <summary>
    /// Authentication WOZ University (WOZ) Admin Account.
    /// </summary>
    [TestMethod]
    public void AuthenticationWOZadm()
    {
      bool passed = false;
      var newLine = Environment.NewLine;
      string subTest = "WOZUniversity_Logon";
      string searchText = Properties.Settings.Default.WOZUniversityIconSearch;
      string targetUrl = Properties.Settings.Default.WOZUnversityURL;
      string userAlias = Properties.Settings.Default.WOZAdmin;

      passed = logIn.LogOnOff(utility, logPath, subTest, searchText, targetUrl, userAlias, passWord);

      if (passed)
      {
        utility.MakeLogEntry("All Login worked for = " + newLine + userAlias);
        results.PassCount = results.PassCount + 1;
      }
      else
      {
        utility.MakeLogEntry("Something failed " + newLine + userAlias);
        results.FailCount = results.FailCount + 1;
      }
    }

    /// <summary>
    /// Authentication WOZ University (WOZ) Student Account.
    /// </summary>
    [TestMethod]
    public void AuthenticationWOZstd()
    {
      bool passed = false;
      var newLine = Environment.NewLine;
      string subTest = "WOZ_Student_Logon";
      string searchText = Properties.Settings.Default.WOZUniversityIconSearch;
      string targetUrl = Properties.Settings.Default.WOZUnversityURL;
      string userAlias = Properties.Settings.Default.WZStudent;

      passed = logIn.LogOnOff(utility, logPath, subTest, searchText, targetUrl, userAlias, passWord);

      if (passed)
      {
        utility.MakeLogEntry("All Login worked for = " + newLine + userAlias);
        results.PassCount = results.PassCount + 1;
      }
      else
      {
        utility.MakeLogEntry("Something failed " + newLine + userAlias);
        results.FailCount = results.FailCount + 1;
      }
    }
  }// EOC
}// EONS
